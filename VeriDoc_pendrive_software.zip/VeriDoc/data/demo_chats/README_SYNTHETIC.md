# Demo chats are synthetic

These six chats are made up for testing and demos. They are not real conversations and must never be presented as real.
