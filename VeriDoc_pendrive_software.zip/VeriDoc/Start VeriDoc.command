#!/bin/bash
# Double-click to start VeriDoc from the pendrive. Keep this window open while you use the app.
cd "$(dirname "$0")"
exec python3 app/veridoc_serve.py --root "$(pwd)" --open
