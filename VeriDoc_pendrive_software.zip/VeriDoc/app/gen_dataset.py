"""Generate labelled VeriDoc training chats from the pendrive's config.

Labels are correct by construction: the generator first decides each term's
true value and status, then renders chat messages from phrase banks, and
records exactly which message and which words carry each term.

    python gen_dataset.py --config <drive>/VeriDoc/config --out <dir>
"""
from __future__ import annotations

import argparse
import datetime as dt
import glob
import hashlib
import json
import os
import random
from collections import Counter


def load(cfg_dir):
    j = lambda n: json.load(open(os.path.join(cfg_dir, n), encoding="utf-8"))
    pbs = {}
    for p in sorted(glob.glob(os.path.join(cfg_dir, "playbooks", "*.json"))):
        pb = json.load(open(p, encoding="utf-8"))
        pbs[pb["id"]] = pb
    schema, lex = j("schema.json"), j("lexicon.json")
    for deal, terms in lex["templates"].items():
        if deal not in pbs:
            raise SystemExit(f"lexicon has templates for unknown deal type {deal}")
        keys = {t["key"] for t in pbs[deal]["terms"]}
        for k, spec in terms.items():
            if k not in keys:
                raise SystemExit(f"lexicon term {deal}.{k} is not in its playbook")
            if "unclear" in spec and spec.get("reason") not in schema["unclear_reasons"]:
                raise SystemExit(f"{deal}.{k}: reason {spec.get('reason')!r} not in schema.unclear_reasons")
    return schema, lex, j("generation.json"), j("prompt.json"), pbs


def build_system_prompt(prompt, pbs):
    lines = [f"- {pid}: " + ", ".join(t["key"] for t in pb["terms"]) for pid, pb in pbs.items()]
    s = prompt["system"].replace("{deal_types}", ", ".join(pbs)).replace("{playbooks}", "\n".join(lines))
    return s + prompt.get("no_think_suffix", "")


def _h(s):
    return int(hashlib.sha256(s.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF


def split_templates(options, frac):
    """Deterministically hold out a fraction of phrasings for the test split only."""
    if len(options) < 2 or frac <= 0:
        return options, []
    ranked = sorted(options, key=_h)
    k = max(1, round(len(options) * frac))
    k = min(k, len(options) - 1)
    return ranked[k:], ranked[:k]


class Gen:
    def __init__(self, schema, lex, gen, pbs, rng):
        self.schema, self.lex, self.gen, self.pbs, self.rng = schema, lex, gen, pbs, rng

    # ---------------------------------------------------------- choice helpers
    def pick_weighted(self, mix):
        keys = list(mix)
        return self.rng.choices(keys, weights=[mix[k] for k in keys])[0]

    def phrases(self, options, split):
        seen, held = split_templates(options, self.gen["holdout_template_fraction"])
        pool = seen if split != "test" else seen + held
        choice = self.rng.choice(pool)
        return choice, choice in held

    def number(self, spec):
        step = self.rng.choice(spec["round_to"])
        lo, hi = -(-spec["min"] // step), spec["max"] // step
        return self.rng.randint(lo, max(lo, hi)) * step

    # ---------------------------------------------------------- rendering
    def money(self, n):
        fmts = []
        for f in self.lex["money_formats"]:
            if "{k}" in f and n % 1000:
                continue
            if "{l}" in f and n % 50000:
                continue
            fmts.append(f)
        f = self.rng.choice(fmts)
        s = str(n)
        last3, rest = s[-3:], s[:-3]
        groups = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        nc = ",".join(([rest] if rest else []) + groups + [last3]) if len(s) > 3 else s
        l = n / 100000
        return f.format(n=n, nc=nc, k=n // 1000, l=(int(l) if l == int(l) else l))

    def date(self, d):
        f = self.rng.choice(self.lex["date_formats"])
        ordv = "th" if 11 <= d.day <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(d.day % 10, "th")
        return f.format(d=d.day, m=d.month, ord=ordv, mon=self.lex["months"][d.month - 1],
                        month=self.lex["months_long"][d.month - 1])

    def render_value(self, ttype, v):
        if ttype == "money":
            return self.money(v)
        if ttype == "date":
            return v["text"]
        return str(v)

    # ---------------------------------------------------------- truth
    def true_values(self, deal, base):
        vals = self.lex["values"][deal]
        pb = self.pbs[deal]
        out = {}
        for t in pb["terms"]:
            k, ty = t["key"], t["type"]
            spec = vals.get(k)
            if ty in ("integer", "money") and isinstance(spec, dict):
                out[k] = self.number(spec)
            elif ty == "date":
                ev = self.gen["date_event_terms"].get(k)
                lang = self._lang
                if ev and self.rng.random() < self.gen["p_date_event"]:
                    out[k] = {"label": ev, "text": self.rng.choice(self.lex["date_events"][ev][lang])}
                else:
                    off = vals["date_offset_days"]
                    d = base + dt.timedelta(days=self.rng.randint(off["min"], off["max"]))
                    out[k] = {"label": f"{d.month:02d}-{d.day:02d}", "date": d}
            elif isinstance(spec, list):
                c = self.rng.choice(spec)
                out[k] = c["v"] if isinstance(c, dict) else c
                if isinstance(c, dict) and "unit" in c:
                    out["_unit"] = c["unit"]
        # derived terms come from their parts
        keys = {t["key"] for t in pb["terms"]}
        for k, parts in self.gen["derived_terms"].items():
            if k not in keys:
                continue
            if k == "advance_amount":
                basis = next(out[p] for p in parts if p in out)
                frac = self.rng.choice(vals["advance_fraction"])
                out[k] = int(round(basis * frac / 10.0)) * 10
            else:
                prod = 1
                for p in parts:
                    prod *= out[p]
                out[k] = prod
        return out

    def statuses(self, deal):
        tpl = self.lex["templates"][deal]
        out = {}
        for t in self.pbs[deal]["terms"]:
            k = t["key"]
            if k in self.gen["always_stated"]:
                out[k] = "stated"
                continue
            while True:
                s = self.pick_weighted(self.gen["term_status_probs"])
                if s == "missing" and k in self.gen["never_missing"]:
                    continue
                if s == "unclear" and "unclear" not in tpl.get(k, {}):
                    continue
                if s == "contradicted" and t["type"] not in self.gen["contradiction_types"]:
                    continue
                if s == "contradicted" and t["type"] == "date" and "date" not in self.truth[k]:
                    continue
                break
            out[k] = s
        return out

    def perturb(self, ttype, v):
        if ttype == "date":
            d = v["date"] + dt.timedelta(days=self.rng.choice([-7, -3, -2, 2, 3, 5, 7]))
            return {"label": f"{d.month:02d}-{d.day:02d}", "date": d}
        step = max(1, v // 10)
        delta = self.rng.choice([-2, -1, 1, 2]) * step
        return max(1, v + delta)

    # ---------------------------------------------------------- one chat
    def sample(self, split):
        g, lex = self.gen, self.lex
        deal = self.pick_weighted(g["deal_type_mix"])
        lang = self._lang = self.pick_weighted(g["language_mix"])
        start = dt.date.fromisoformat(g["base_date_range"]["start"])
        end = dt.date.fromisoformat(g["base_date_range"]["end"])
        base = start + dt.timedelta(days=self.rng.randint(0, (end - start).days))
        a, b = self.rng.sample(lex["people"], 2)
        roles = dict(zip(lex["role_pairs"][deal], [a, b]))
        self.truth = self.true_values(deal, base)
        status = self.statuses(deal)
        tpl = lex["templates"][deal]
        terms_meta = {t["key"]: t for t in self.pbs[deal]["terms"]}
        used_held = False

        segments = []  # (speaker, phrase, [(term_key, quote_text)])
        item_in_qty = False
        for t in self.pbs[deal]["terms"]:
            k, ty = t["key"], t["type"]
            st = status[k]
            if ty == "party" or st == "missing" or k not in tpl:
                continue
            if k == "item" and item_in_qty:
                continue
            spk_role = tpl[k]["speaker"]
            speaker = roles[spk_role] if spk_role in roles else self.rng.choice([a, b])
            mentions = [self.truth[k]]
            if st == "contradicted":
                mentions.append(self.perturb(ty, self.truth[k]))
            for i, val in enumerate(mentions):
                kind = "unclear" if st == "unclear" else "stated"
                if kind == "stated" and ty == "date" and "date" not in val and "event_stated" in tpl[k]:
                    kind = "event_stated"
                phr, held = self.phrases(tpl[k][kind][lang], split)
                used_held |= held
                if ty == "date" and "date" in val:
                    val = dict(val, text=self.date(val["date"]))
                rv = self.render_value(ty, val) if "{v}" in phr else None
                item = self.truth.get("item", "")
                text = phr.replace("{v}", rv or "").replace("{item}", item)
                labels = [(k, text)]
                if k == "quantity" and "{item}" in phr and status.get("item") != "missing":
                    labels.append(("item", item))
                    item_in_qty = True
                if k == "item":
                    labels = [(k, item)]
                sp = speaker if i == 0 else self.rng.choice([a, b])
                segments.append((sp, text, labels, i))
            # item must precede quantity in reading order; nothing to do since playbook order handles it

        # second mentions of contradictions move later in the chat
        firsts = [s for s in segments if s[3] == 0]
        seconds = [s for s in segments if s[3] == 1]
        for s in seconds:
            firsts.insert(self.rng.randint(len(firsts) // 2, len(firsts)), s)
        segments = firsts

        # merge some adjacent segments from the same speaker into one message
        msgs = []  # (speaker, text, labels)
        for sp, text, labels, _ in segments:
            if msgs and msgs[-1][0] == sp and msgs[-1][2] and self.rng.random() < g["p_merge_two_terms"]:
                j = self.rng.choice(lex["joiners"][lang])
                msgs[-1] = (sp, msgs[-1][1] + j + text, msgs[-1][2] + labels)
            else:
                msgs.append((sp, text, list(labels)))
            if self.rng.random() < g["p_ack_after_term"]:
                other = b if sp == a else a
                msgs.append((other, self.rng.choice(lex["acks"][lang]), []))

        # both parties must speak at least once (the other side's ack is part of the deal)
        for who in (a, b):
            if not any(m[0] == who for m in msgs):
                msgs.insert(self.rng.randint(1, len(msgs)), (who, self.rng.choice(lex["acks"][lang]), []))

        # noise that must NOT change labels
        def insert(text, at=None):
            pos = self.rng.randint(0, len(msgs)) if at is None else at
            msgs.insert(pos, (self.rng.choice([a, b]), text, []))

        for _ in range(self.rng.randint(*g["fillers_range"])):
            insert(self.rng.choice(lex["fillers"][lang]))
        for _ in range(self.rng.randint(*g["distractors_range"])):
            nums = {k: self.rng.randint(*r) for k, r in lex["distractor_numbers"].items()}
            insert(self.rng.choice(lex["distractors"][lang]).format(**nums))
        if self.rng.random() < g["p_injection"]:
            insert(self.rng.choice(lex["injections"]))
        if self.rng.random() < g["p_opener"]:
            insert(self.rng.choice(lex["openers"][lang]), at=0)

        # number messages and build the target
        fmt = self.schema["message_format"]
        lines, found = [], {}
        first_by = {}
        for i, (sp, text, labels) in enumerate(msgs, start=1):
            lines.append(fmt.format(index=i, sender=sp, text=text))
            first_by.setdefault(sp, i)
            for k, q in labels:
                found.setdefault(k, []).append((i, q))

        terms = {}
        for t in self.pbs[deal]["terms"]:
            k, ty, st = t["key"], t["type"], status[t["key"]]
            if ty == "party":
                name = roles[k]
                terms[k] = {"status": "stated", "value": name, "quote": [name], "msg": [first_by.get(name, 1)]}
                continue
            if st == "missing" or k not in found:
                terms[k] = {"status": "missing"}
                continue
            hits = found[k]
            obj = {"status": st, "value": None, "quote": [q for _, q in hits], "msg": [i for i, _ in hits]}
            if st == "stated":
                v = self.truth[k]
                obj["value"] = v["label"] if ty == "date" else v
            if st == "unclear":
                obj["reason"] = tpl[k]["reason"]
            terms[k] = obj

        chat = "\n".join(lines)
        target = {"deal_type": deal, "terms": terms}
        meta = {"deal_type": deal, "lang": lang, "heldout_phrasing": used_held,
                "has_injection": any(m[1] in lex["injections"] for m in msgs),
                "statuses": dict(Counter(v["status"] for v in terms.values()))}
        return chat, target, meta


def grounding_ok(chat, target, schema):
    lines = chat.split("\n")
    for k, v in target["terms"].items():
        for q, m in zip(v.get("quote", []), v.get("msg", [])):
            if q not in lines[m - 1]:
                return f"{k}: quote {q!r} not in message {m}"
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    schema, lex, gen, prompt, pbs = load(args.config)
    system = build_system_prompt(prompt, pbs)
    rng = random.Random(gen["seed"])
    G = Gen(schema, lex, gen, pbs, rng)
    os.makedirs(args.out, exist_ok=True)
    seen = set()
    report = {}
    for split in ("test", "valid", "train"):  # test first so its chats are reserved
        n, rows, metas, dupes = gen["splits"][split], [], [], 0
        while len(rows) < n:
            chat, target, meta = G.sample(split)
            key = hashlib.sha256(chat.encode()).hexdigest()
            if key in seen:
                dupes += 1
                if dupes > n * 20:
                    raise SystemExit(f"{split}: phrase banks too small for {n} unique chats")
                continue
            err = grounding_ok(chat, target, schema)
            if err:
                raise SystemExit(f"generator bug, grounding failed: {err}\n{chat}")
            seen.add(key)
            rows.append({"messages": [{"role": "system", "content": system},
                                      {"role": "user", "content": chat},
                                      {"role": "assistant", "content": json.dumps(target, ensure_ascii=False, separators=(",", ":"))}]})
            metas.append(meta)
        with open(os.path.join(args.out, f"{split}.jsonl"), "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        with open(os.path.join(args.out, f"{split}.meta.jsonl"), "w", encoding="utf-8") as f:
            for m in metas:
                f.write(json.dumps(m, ensure_ascii=False) + "\n")
        st = Counter()
        for m in metas:
            st.update(m["statuses"])
        report[split] = {"chats": n, "duplicates_skipped": dupes,
                         "langs": dict(Counter(m["lang"] for m in metas)),
                         "deals": dict(Counter(m["deal_type"] for m in metas)),
                         "term_statuses": dict(st),
                         "with_injection": sum(m["has_injection"] for m in metas),
                         "heldout_phrasing": sum(m["heldout_phrasing"] for m in metas)}
    json.dump(report, open(os.path.join(args.out, "report.json"), "w"), indent=1)
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
