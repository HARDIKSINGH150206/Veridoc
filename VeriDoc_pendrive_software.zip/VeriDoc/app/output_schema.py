"""Build the JSON schema that constrains the model's answer (llama.cpp grammar-constrained decoding).

Everything comes from config: deal types and term keys from playbooks/, statuses and unclear
reasons from schema.json, and the length limits from schema.json -> output_constraints. The
property order matches the training answers (deal_type, terms; status, value, quote, msg, reason),
so the grammar never fights what the model learned.

    from output_schema import response_format
    body["response_format"] = response_format(schema, pbs)   # None when disabled in config
"""


def output_schema(schema, pbs):
    oc = schema["output_constraints"]
    text = {"type": "string", "maxLength": oc["max_string_chars"]}
    term = {
        "type": "object",
        "properties": {
            "status": {"enum": list(schema["statuses"])},
            "value": {"anyOf": [text, {"type": "integer"}, {"type": "null"}]},
            "quote": {"type": "array", "items": text, "maxItems": oc["max_list_items"]},
            "msg": {"type": "array", "items": {"type": "integer"}, "maxItems": oc["max_list_items"]},
            "reason": {"enum": list(schema["unclear_reasons"])},
        },
        "required": ["status"],
        "additionalProperties": False,
    }
    deals = []
    for pid, pb in pbs.items():
        keys = [t["key"] for t in pb["terms"]]
        deals.append({
            "type": "object",
            "properties": {
                "deal_type": {"const": pid},
                "terms": {"type": "object", "properties": {k: term for k in keys}, "required": keys,
                          "additionalProperties": False},
            },
            "required": ["deal_type", "terms"],
            "additionalProperties": False,
        })
    return {"anyOf": deals} if len(deals) > 1 else deals[0]


def response_format(schema, pbs):
    """The llama-server request field, or None when constrained decoding is off in schema.json."""
    oc = schema.get("output_constraints") or {}
    if not oc.get("enabled"):
        return None
    return {"type": "json_schema", "json_schema": {"name": oc.get("name", "veridoc_terms"), "schema": output_schema(schema, pbs)}}
