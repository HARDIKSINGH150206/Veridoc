"""VeriDoc rules engine: deterministic checks on the model's answer.

The model only suggests. Each term it returns is checked here against the
actual chat text; anything that fails a check is marked needs_review with the
reason, so a wrong answer shows up as a question instead of a confident error.
All vocabulary comes from config/rules.json; term types from the playbooks.

    from rules import Rules
    R = Rules(cfg_dir)
    report = R.check(pred_json, messages, deal_type)
"""
import datetime as dt, glob, json, os, re


class Rules:
    def __init__(self, cfg_dir):
        j = lambda n: json.load(open(os.path.join(cfg_dir, n), encoding="utf-8"))
        self.c = j("rules.json")
        self.schema = j("schema.json")
        self.pbs = {}
        for p in sorted(glob.glob(os.path.join(cfg_dir, "playbooks", "*.json"))):
            pb = json.load(open(p, encoding="utf-8"))
            self.pbs[pb["id"]] = {t["key"]: t for t in pb["terms"]}
        mult = sorted(self.c["multipliers"], key=len, reverse=True)
        mult_re = "|".join(re.escape(m) for m in mult)
        words = sorted(self.c["number_words"], key=len, reverse=True)
        self._num = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{2,3})+|\d+(?:\.\d+)?)(?:\s?(" + mult_re + r"))?(?![a-z])", re.I)
        self._word_mult = re.compile(r"\b(" + "|".join(map(re.escape, words)) + r")\s+(" + mult_re + r")\b", re.I)
        self._word = re.compile(r"\b(" + "|".join(map(re.escape, words)) + r")\b", re.I)
        months = sorted(self.c["months"], key=len, reverse=True)
        mre = "|".join(map(re.escape, months))
        # ASCII-only boundaries so Devanagari month names (which end in vowel signs) still match
        self._d_m = re.compile(r"(?<!\d)(\d{1,2})(?:st|nd|rd|th)?\s*(?:of\s+)?(" + mre + r")(?![A-Za-z])", re.I)
        self._m_d = re.compile(r"(?<![A-Za-z])(" + mre + r")\s+(\d{1,2})(?:st|nd|rd|th)?(?!\d)", re.I)
        self._slash = re.compile(r"(?<![\d/])(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?(?![\d/])")

    # ------------------------------------------------------------ extraction
    def amounts(self, text):
        """All money/quantity values written in the text, in rupees/units."""
        out, t = [], text.lower()
        for m in self._num.finditer(t):
            n = float(m.group(1).replace(",", ""))
            mul = m.group(2)
            if mul:
                n *= self.c["multipliers"][mul.lower()]
            out.append(int(round(n)))
        for m in self._word_mult.finditer(t):
            out.append(int(round(self.c["number_words"][m.group(1).lower()] * self.c["multipliers"][m.group(2).lower()])))
        return out

    def integers(self, text):
        out = self.amounts(text)
        excl = set(self.c["standalone_number_words_exclude"])
        for m in self._word.finditer(text.lower()):
            w = m.group(1).lower()
            v = self.c["number_words"][w]
            if w not in excl and v == int(v):
                out.append(int(v))
        return out

    def dates(self, text):
        """Absolute day-month mentions as 'MM-DD' strings."""
        out, t = [], text.lower()
        for m in self._d_m.finditer(t):
            d, mo = int(m.group(1)), self.c["months"][m.group(2).lower()]
            if 1 <= d <= 31:
                out.append(f"{mo:02d}-{d:02d}")
        for m in self._m_d.finditer(t):
            mo, d = self.c["months"][m.group(1).lower()], int(m.group(2))
            if 1 <= d <= 31:
                out.append(f"{mo:02d}-{d:02d}")
        units = tuple(self.c.get("duration_units", []))
        for m in self._slash.finditer(t):
            nxt = t[m.end():].lstrip().split(" ", 1)[0].strip(".,!?")
            if nxt in units:
                continue  # "4-5 days" is a duration range, not a date
            a, b = int(m.group(1)), int(m.group(2))
            d, mo = (a, b) if self.schema.get("date_order", "dmy") == "dmy" else (b, a)
            if 1 <= d <= 31 and 1 <= mo <= 12:
                out.append(f"{mo:02d}-{d:02d}")
        return out

    def vague(self, text, kind):
        t = " " + text.lower() + " "
        hits = [w for w in self.c["vague_markers"].get(kind, []) if w in t]
        for pat in self.c.get("range_patterns", {}).get(kind, []):
            if re.search(pat, t):
                hits.append("range")
        return hits

    def has_fraction(self, text):
        t = text.lower()
        return any(re.search(r"\b" + re.escape(w) + r"\b", t) for w in self.c["fraction_words"])

    def suggest_date(self, text, ts):
        """For a relative date and the message's timestamp, propose a calendar date (never applied automatically)."""
        if not ts:
            return None
        base = dt.datetime.fromisoformat(ts).date()
        t = text.lower()
        for w, days in sorted(self.c["relative_week_words"].items(), key=lambda x: -len(x[0])):
            if w in t:
                d = base + dt.timedelta(days=days)
                return f"{d.month:02d}-{d.day:02d}"
        for w, days in sorted(self.c["relative_day_words"].items(), key=lambda x: -len(x[0])):
            if re.search(r"\b" + re.escape(w) + r"\b", t):
                d = base + dt.timedelta(days=days)
                return f"{d.month:02d}-{d.day:02d}"
        for w, wd in sorted(self.c["weekdays"].items(), key=lambda x: -len(x[0])):
            if re.search(r"\b" + re.escape(w) + r"\b", t):
                ahead = (wd - base.weekday()) % 7 or 7
                d = base + dt.timedelta(days=ahead)
                return f"{d.month:02d}-{d.day:02d}"
        return None

    # ------------------------------------------------------------ checks
    def check_term(self, key, ttype, obj, msgs):
        chk, flags, extra = self.c["checks"], [], {}
        status = obj.get("status")
        quotes, nums = obj.get("quote") or [], obj.get("msg") or []
        texts = [m["text"] for m in msgs]
        senders = {m["sender"] for m in msgs}
        if status not in self.schema["statuses"]:
            return ["unknown_status"], extra
        if status == "missing":
            return flags, extra
        if chk["grounding"]:
            if not quotes or len(quotes) != len(nums):
                flags.append("quote_or_msg_missing")
            for q, n in zip(quotes, nums):
                ok = isinstance(n, int) and 1 <= n <= len(texts) and isinstance(q, str) and (
                    q in texts[n - 1] or (ttype == "party" and q == msgs[n - 1]["sender"]))
                if not ok:
                    flags.append("quote_not_in_message")
                    break
        joined = " ".join(q for q in quotes if isinstance(q, str))
        kind = {"money": "amount", "integer": "amount", "date": "date"}.get(ttype, "timing")
        val = obj.get("value")
        if status == "stated":
            if ttype == "party" and chk["party_is_sender"] and val not in senders:
                flags.append("party_not_a_sender")
            if ttype in ("money", "integer") and chk["value_in_quote"]:
                found = self.amounts(joined) if ttype == "money" else self.integers(joined)
                if not isinstance(val, (int, float)) or int(val) not in found:
                    flags.append("value_not_in_quote")
                    if found:
                        extra["quote_values"] = sorted(set(found))
            if ttype == "date" and chk["value_in_quote"]:
                if isinstance(val, str) and re.fullmatch(r"\d{2}-\d{2}", val):
                    if val not in self.dates(joined):
                        flags.append("date_not_in_quote")
                elif isinstance(val, str) and val in self.c["event_cues"]:
                    if not any(cue in joined.lower() for cue in self.c["event_cues"][val]):
                        flags.append("event_not_in_quote")
                else:
                    flags.append("bad_date_value")
            if ttype == "text" and chk["value_in_quote"]:
                vt = {w for w in re.findall(r"\w+", str(val).lower()) if len(w) > 2}
                qt = set(re.findall(r"\w+", joined.lower()))
                if vt and not (vt & qt):
                    flags.append("value_not_in_quote")
            if chk["stated_but_vague"] and ttype in ("money", "integer", "date") and self.vague(joined, kind):
                flags.append("vague_wording")
            if chk["multi_value_stated"] and ttype in ("money", "integer") and len(set(nums)) > 1:
                per_msg = [set(self.amounts(q)) for q in quotes if isinstance(q, str)]
                if len({frozenset(s) for s in per_msg if s}) > 1:
                    flags.append("possible_contradiction")
        if status == "unclear" and chk["unclear_but_explicit"]:
            if ttype in ("money", "integer"):
                found = self.amounts(joined) if ttype == "money" else self.integers(joined)
                if ttype == "money":  # a bare '16' meaning 16k has no clear unit, so unclear is fine
                    found = [v for v in found if v >= self.c.get("shorthand_amount_max", 0)]
                # exactly one clear figure and no vague wording means the term was really stated
                if len(set(found)) == 1 and not self.vague(joined, kind) and not self.has_fraction(joined):
                    flags.append("explicit_value_marked_unclear")
            if ttype == "date" and self.dates(joined) and not self.vague(joined, "date"):
                flags.append("explicit_date_marked_unclear")
            if ttype == "date":
                for n in nums:
                    if isinstance(n, int) and 1 <= n <= len(msgs):
                        s = self.suggest_date(texts[n - 1], msgs[n - 1].get("ts"))
                        if s:
                            extra["suggested_date"] = s
                            break
        return flags, extra

    def check(self, pred, msgs, deal_type=None):
        """pred: parsed model JSON. msgs: list of {sender,text,ts?}. Returns per-term review info."""
        deal = deal_type or (pred or {}).get("deal_type")
        if deal not in self.pbs:
            return {"deal_type_ok": False, "terms": {}}
        terms = (pred or {}).get("terms") or {}
        out = {"deal_type_ok": True, "terms": {}}
        for key, meta in self.pbs[deal].items():
            obj = terms.get(key)
            if not isinstance(obj, dict):
                out["terms"][key] = {"needs_review": True, "flags": ["term_absent_from_answer"]}
                continue
            flags, extra = self.check_term(key, meta["type"], obj, msgs)
            out["terms"][key] = dict({"needs_review": bool(flags), "flags": flags}, **extra)
        if self.c["checks"].get("unused_mentions"):
            out["unused_mentions"] = self.unused_mentions(terms, msgs, deal)
        return out

    def unused_mentions(self, terms, msgs, deal):
        """Figures and dates in the chat that no term uses, shown when a money or date term is marked
        missing. A term the model wrongly called missing has no quote to check, so this deal-level
        list is the only way to surface it. Settings: rules.json -> unused_mentions."""
        cfg = self.c["unused_mentions"]
        types = {k: t["type"] for k, t in self.pbs[deal].items()}
        used_amounts, used_dates, cited = set(), set(), set()
        for obj in terms.values():
            if isinstance(obj, dict) and obj.get("status") != "missing":
                for q, n in zip(obj.get("quote") or [], obj.get("msg") or []):
                    if isinstance(q, str):
                        used_amounts.update(self.amounts(q))
                        used_dates.update(self.dates(q))
                    cited.add(n)

        def missing(kind):
            return any(ty == kind and (not isinstance(terms.get(k), dict) or terms[k].get("status") == "missing")
                       for k, ty in types.items())

        want_money = missing("money") or not cfg.get("only_when_term_missing")
        want_date = missing("date") or not cfg.get("only_when_term_missing")
        near = cfg.get("near_used_fraction", 0)
        out = []
        for i, m in enumerate(msgs, 1):
            if cfg.get("skip_cited_messages") and i in cited:
                continue
            amounts = {v for v in self.amounts(m["text"]) if v >= cfg["min_amount"]} - used_amounts if want_money else set()
            amounts = {v for v in amounts if not any(u and abs(v - u) <= near * u for u in used_amounts)}
            dates = set(self.dates(m["text"])) - used_dates if want_date else set()
            if amounts or dates:
                out.append({"msg": i, "amounts": sorted(amounts), "dates": sorted(dates)})
        return out


    # ------------------------------------------------------------ repair
    def repair(self, pred, msgs, deal_type=None):
        """Fix only the clear-cut mistakes the checks can prove from the quoted text, and record each fix.
        Returns (repaired_pred, repairs). A repaired term still needs human confirmation like any other.
        Enabled per rule in rules.json -> repair."""
        cfg = self.c.get("repair") or {}
        if not cfg.get("enabled") or not isinstance(pred, dict):
            return pred, []
        deal = deal_type or pred.get("deal_type")
        if deal not in self.pbs or not isinstance(pred.get("terms"), dict):
            return pred, []
        out = json.loads(json.dumps(pred))
        repairs = []
        texts = [m["text"] for m in msgs]
        for key, meta in self.pbs[deal].items():
            obj = out["terms"].get(key)
            if not isinstance(obj, dict):
                continue
            ttype, status = meta["type"], obj.get("status")
            quotes = [q for q in (obj.get("quote") or []) if isinstance(q, str)]
            nums = obj.get("msg") or []
            grounded = quotes and len(quotes) == len(nums) and all(
                isinstance(n, int) and 1 <= n <= len(texts) and q in texts[n - 1] for q, n in zip(quotes, nums))
            if not grounded or len(set(nums)) != 1:
                continue  # only single-message, grounded terms are safe to repair
            q = " ".join(quotes)
            kind = {"money": "amount", "integer": "amount", "date": "date"}.get(ttype)
            fix = None
            if ttype in ("money", "integer") and kind:
                found = set(self.amounts(q) if ttype == "money" else self.integers(q))
                single = next(iter(found)) if len(found) == 1 else None
                if ttype == "money" and single is not None and single < self.c.get("shorthand_amount_max", 0):
                    single = None  # "16" could mean 16k: leave it unclear
                clear = single is not None and not self.vague(q, kind) and not self.has_fraction(q)
                if status == "unclear" and clear and cfg.get("unclear_with_explicit_value"):
                    fix = ("explicit_value_marked_unclear", {"status": "stated", "value": single})
                elif status == "stated" and clear and obj.get("value") != single and cfg.get("value_from_quote"):
                    fix = ("value_not_in_quote", {"status": "stated", "value": single})
            elif ttype == "date":
                dates = sorted(set(self.dates(q)))
                vague = self.vague(q, "date")
                events = [e for e, cues in (cfg.get("event_cues") or {}).items() if any(c in q.lower() for c in cues)]
                if len(dates) == 1 and not vague:
                    if status == "unclear" and cfg.get("unclear_with_explicit_date"):
                        fix = ("explicit_date_marked_unclear", {"status": "stated", "value": dates[0]})
                    elif status == "stated" and obj.get("value") != dates[0] and cfg.get("value_from_quote"):
                        fix = ("date_not_in_quote", {"status": "stated", "value": dates[0]})
                elif not dates and len(events) == 1 and not vague and not re.search(r"\d", q) \
                        and not any(c in q.lower() for c in cfg.get("split_payment_cues", [])) and status == "unclear" and cfg.get("unclear_with_event"):
                    fix = ("event_marked_unclear", {"status": "stated", "value": events[0]})
            if fix:
                reason, new = fix
                before = {"status": status, "value": obj.get("value")}
                obj.update(new)
                obj.pop("reason", None)
                repairs.append({"term": key, "rule": reason, "before": before, "after": new})
        return out, repairs


def messages_from_numbered(chat):
    """Rebuild message dicts from the numbered model input (no timestamps)."""
    out = []
    for line in chat.split("\n"):
        m = re.match(r"^\[(\d+)\] ([^:]+): (.*)$", line)
        if m:
            out.append({"sender": m.group(2), "text": m.group(3), "ts": None})
    return out
