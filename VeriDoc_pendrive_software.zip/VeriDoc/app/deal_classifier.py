"""Deal-type classifier learned from the training chats (presence-only naive Bayes over words).

Only the words present in the chat vote (log-odds of appearing in one deal type vs the other);
absent words and class priors are ignored, which keeps it robust when training chats (mostly
template) and real chats use different vocabularies.

The small model picks the deal type from the first token it writes, and when it picks wrong
every term in the chat is wrong. This classifier reads the whole chat and, when it is
confident (log-odds margin >= rules.json -> deal_classifier.override_margin), the model is
constrained to that deal type's schema. Below the margin the model decides as before.

Nothing is hand-written: the word statistics come from the training split only.

    python3 deal_classifier.py --config <config dir> --train data_mix/train.jsonl [more.jsonl ...]
    from deal_classifier import DealClassifier; DealClassifier.load(cfg).predict(chat_text)
"""
import argparse, json, math, os, re
from collections import Counter

PREFIX = re.compile(r"^\[\d+\] [^:]*: ", re.M)  # "[3] Name: " is dropped so names do not leak into the decision
WORD = re.compile(r"[^\W\d_]+")


def words(chat):
    return set(WORD.findall(PREFIX.sub("", chat).lower()))


class DealClassifier:
    def __init__(self, docs, counts, margin):
        self.docs, self.counts, self.margin = docs, counts, margin
        self.vocab = set().union(*[set(c) for c in counts.values()]) if counts else set()

    @classmethod
    def settings(cls, cfg_dir):
        rules = json.load(open(os.path.join(cfg_dir, "rules.json"), encoding="utf-8"))
        return rules.get("deal_classifier") or {}

    @classmethod
    def load(cls, cfg_dir):
        """None when disabled in rules.json or not trained yet."""
        s = cls.settings(cfg_dir)
        path = os.path.join(cfg_dir, s.get("file", "deal_classifier.json"))
        if not s.get("enabled") or not os.path.exists(path):
            return None
        m = json.load(open(path, encoding="utf-8"))
        return cls(m["docs"], m["counts"], s.get("override_margin", 1.0))

    def scores(self, chat):
        ws = [w for w in words(chat) if w in self.vocab]
        out = {}
        for d, n in self.docs.items():
            c = self.counts[d]
            out[d] = sum(math.log((c.get(w, 0) + 1) / (n + 2)) - math.log((n - c.get(w, 0) + 1) / (n + 2)) for w in ws)
        return out

    def predict(self, chat):
        """(deal_type, margin, confident)."""
        ranked = sorted(self.scores(chat).items(), key=lambda x: -x[1])
        if len(ranked) < 2:
            return (ranked[0][0] if ranked else None), 0.0, False
        margin = ranked[0][1] - ranked[1][1]
        return ranked[0][0], round(margin, 2), margin >= self.margin


def train(files, min_count):
    docs, counts = Counter(), {}
    for f in files:
        for line in open(f, encoding="utf-8"):
            r = json.loads(line)
            d = json.loads(r["messages"][2]["content"])["deal_type"]
            docs[d] += 1
            counts.setdefault(d, Counter()).update(words(r["messages"][1]["content"]))
    total = Counter()
    for c in counts.values():
        total.update(c)
    keep = {w for w, n in total.items() if n >= min_count}
    return {"docs": dict(docs), "counts": {d: {w: n for w, n in c.items() if w in keep} for d, c in counts.items()},
            "trained_on": [os.path.basename(f) for f in files]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--train", nargs="+", required=True, help="training .jsonl files (never the test split)")
    ap.add_argument("--check", help="optional .jsonl to report accuracy on")
    a = ap.parse_args()
    s = DealClassifier.settings(a.config)
    m = train(a.train, s.get("min_word_count", 2))
    path = os.path.join(a.config, s.get("file", "deal_classifier.json"))
    json.dump(m, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    print("saved", path, "| chats per deal:", m["docs"], "| words:", len(set().union(*[set(c) for c in m["counts"].values()])))
    if a.check:
        clf = DealClassifier(m["docs"], m["counts"], s.get("override_margin", 1.0))
        n = ok = conf = conf_ok = 0
        for line in open(a.check, encoding="utf-8"):
            r = json.loads(line)
            gold = json.loads(r["messages"][2]["content"])["deal_type"]
            d, _m, c = clf.predict(r["messages"][1]["content"])
            n += 1
            ok += d == gold
            conf += c
            conf_ok += c and d == gold
        print("check: %d/%d right; confident on %d, of which %d right" % (ok, n, conf, conf_ok))


if __name__ == "__main__":
    main()
