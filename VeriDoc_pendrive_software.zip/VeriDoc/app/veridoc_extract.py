"""VeriDoc demo: WhatsApp export in, checked deal sheet out. Runs fully offline from the pendrive.

    python3 veridoc_extract.py --root /Volumes/VERIDOC/VeriDoc --chat "WhatsApp Chat.txt" [--transcripts <folder>] [--tier small] [--json]

Everything is read from <root>: the engine (runtime/bin), the model (manifest.json), the
context size (config/models.json), the prompt and playbooks (config/), the export format
(config/whatsapp.json) and the checks (config/rules.json). Works with the Mac's built-in python3.
"""
import argparse, json, os, platform, socket, subprocess, sys, time, urllib.error, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from gen_dataset import load, build_system_prompt  # noqa: E402
from wa_parse import parse_export, to_model_input, load_transcripts  # noqa: E402
from rules import Rules  # noqa: E402
from output_schema import response_format  # noqa: E402
from deal_classifier import DealClassifier  # noqa: E402


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def physical_cores():
    if platform.system() == "Darwin":
        for key in ("hw.perflevel0.physicalcpu", "hw.physicalcpu"):
            out = subprocess.run(["sysctl", "-n", key], capture_output=True, text=True).stdout.strip()
            if out.isdigit():
                return int(out)
    return os.cpu_count() or 1


def post_chat(base, body):
    """POST to llama-server; if this build rejects response_format, retry with its native json_schema field."""
    def send(b):
        req = urllib.request.Request(base + "/v1/chat/completions", json.dumps(b).encode(), {"Content-Type": "application/json"})
        return json.load(urllib.request.urlopen(req, timeout=600))
    try:
        return send(body)
    except urllib.error.HTTPError as e:
        if e.code == 400 and "response_format" in body:
            b = dict(body)
            b["json_schema"] = b.pop("response_format")["json_schema"]["schema"]
            return send(b)
        raise


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="the VeriDoc folder on the pendrive")
    src = ap.add_mutually_exclusive_group()
    src.add_argument("--chat", help="WhatsApp export file (WhatsApp Chat.txt), or a text file of 'Name: message' lines")
    src.add_argument("--paste", action="store_true", help="read the chat from the clipboard (copy it first)")
    ap.add_argument("--transcripts", help="folder with <voice file>.txt transcripts (default: the chat's folder)")
    ap.add_argument("--tier", default=None, help="model entry in manifest.json (default: first tier in models.json that is installed)")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    cfg = os.path.join(a.root, "config")
    schema, lex, gen, prompt, pbs = load(cfg)
    wa = json.load(open(os.path.join(cfg, "whatsapp.json"), encoding="utf-8"))
    models = json.load(open(os.path.join(cfg, "models.json"), encoding="utf-8"))
    manifest = json.load(open(os.path.join(a.root, "manifest.json"), encoding="utf-8"))
    tier = a.tier or next(t["name"] for t in models["tiers"] if t["name"] in manifest["models"])
    entry = manifest["models"][tier]
    ctx = next((t["ctx"] for t in models["tiers"] if t["name"] == tier), None) or next(t["ctx"] for t in models["tiers"] if tier.startswith(t["name"]))
    exe = os.path.join(a.root, manifest["runtime"]["dir"], "llama-server")

    if a.chat:
        text = open(a.chat, encoding="utf-8").read()
        tr_dir = a.transcripts or os.path.dirname(os.path.abspath(a.chat))
    elif a.paste:
        text = subprocess.run(["pbpaste"] if platform.system() == "Darwin" else ["powershell", "-command", "Get-Clipboard"],
                              capture_output=True, text=True).stdout
        tr_dir = a.transcripts
    else:
        print("Type or paste the chat, one message per line as  Name: message")
        print("Press Enter on an empty line twice to finish.\n")
        lines, blanks = [], 0
        while blanks < 2:
            try:
                line = input()
            except EOFError:
                break
            blanks = blanks + 1 if not line.strip() else 0
            lines.append(line)
        text, tr_dir = "\n".join(lines), a.transcripts
    msgs = parse_export(text, wa, load_transcripts(tr_dir))
    if not msgs:
        sys.exit("No messages found. Each line should look like  Name: message")
    chat = to_model_input(msgs, schema)

    port = free_port()
    log = open(os.path.join(a.root, "logs", "veridoc_extract.log"), "w")
    proc = subprocess.Popen([exe, "-m", os.path.join(a.root, entry["path"]), "-c", str(ctx), "-t", str(physical_cores()),
                             "-ngl", "999", "--host", "127.0.0.1", "--port", str(port)], stdout=log, stderr=subprocess.STDOUT)
    base = "http://127.0.0.1:%d" % port
    try:
        for _ in range(240):
            try:
                with urllib.request.urlopen(base + "/health", timeout=2) as r:
                    if json.load(r).get("status") == "ok":
                        break
            except Exception:
                time.sleep(0.5)
        body = {"messages": [{"role": "system", "content": build_system_prompt(prompt, pbs)}, {"role": "user", "content": chat}],
                "temperature": 0, "chat_template_kwargs": {"enable_thinking": False}}
        clf = DealClassifier.load(cfg)
        hint = clf.predict(chat) if clf else None
        # a confident deal-type reading from the whole chat narrows the schema to that deal type
        rf = response_format(schema, {hint[0]: pbs[hint[0]]} if hint and hint[2] and hint[0] in pbs else pbs)
        if rf:
            body["response_format"] = rf  # grammar-constrained: the answer is always valid JSON in the trained shape
        t0 = time.time()
        r = post_chat(base, body)
        secs = time.time() - t0
    finally:
        proc.terminate()
        log.close()
    out = r["choices"][0]["message"]["content"]
    try:
        pred = json.loads(out[out.index("{"): out.rindex("}") + 1])
    except ValueError:
        sys.exit("model did not return JSON:\n" + out)
    rules = Rules(cfg)
    pred, repairs = rules.repair(pred, msgs, pred.get("deal_type"))
    review = rules.check(pred, msgs, pred.get("deal_type"))
    if a.json:
        print(json.dumps({"chat": chat, "prediction": pred, "repairs": repairs, "review": review}, ensure_ascii=False, indent=1))
        return
    dp = os.path.join(cfg, "display.json")
    disp = json.load(open(dp, encoding="utf-8")) if os.path.exists(dp) else {}
    tags = disp.get("status_tags") or {}
    fixed = {x["term"]: x["rule"] for x in repairs}
    print(chat, "\n")
    deal = pred.get("deal_type")
    print("DEAL TYPE:", deal, "| model:", os.path.basename(entry["path"]), "| %.1fs" % secs)
    pterms = pred.get("terms") or {}
    found, miss_req, miss_opt = [], [], []
    for t in pbs.get(deal, {"terms": []})["terms"]:
        st = (pterms.get(t["key"]) or {}).get("status", "missing")
        if st == "missing":
            (miss_req if t.get("required") else miss_opt).append(t["key"])
        else:
            found.append(t)
    deal_terms = [t for t in found if t["type"] != "party"]
    if len(deal_terms) < disp.get("deal_needs_non_party_terms", 1):
        print("\n" + disp.get("no_deal_message", "No deal found in this chat."))
        return
    print("\n" + disp.get("found_heading", "Found in the chat:"))
    for t in found:
        k = t["key"]
        p, rv = pterms.get(k) or {}, review["terms"].get(k, {})
        st = p.get("status")
        line = "  [%s] %-22s" % (tags.get(st, st), k)
        if st == "stated":
            line += " %s" % p.get("value")
        if p.get("quote"):
            line += "   <- msg %s: \"%s\"" % (",".join(map(str, p.get("msg") or [])), " | ".join(p["quote"]))
        if st == "unclear" and p.get("reason"):
            line += "  (%s)" % p["reason"]
        if k in fixed:
            line += "  [" + disp.get("repaired_note", "fixed by rules: %s") % fixed[k] + "]"
        if rv.get("suggested_date"):
            line += "  [suggest: %s]" % rv["suggested_date"]
        if rv.get("needs_review"):
            line += "   !! NEEDS REVIEW: %s" % ", ".join(rv["flags"])
            if rv.get("quote_values"):
                line += " (chat says %s)" % rv["quote_values"]
        print(line)
    if miss_req:
        print("\n" + disp.get("missing_required_heading", "Not in the chat yet:"), ", ".join(miss_req))
    if miss_opt:
        print(disp.get("missing_optional_heading", "Not mentioned (optional):"), ", ".join(miss_opt))
    unused = review.get("unused_mentions") or []
    if unused:
        print("\n  !! CHECK: figures or dates in the chat that no term uses (a term may be wrongly marked missing):")
        for u in unused:
            bits = ["%s" % v for v in u["amounts"]] + ["date %s" % d for d in u["dates"]]
            print("     msg %d: %s" % (u["msg"], ", ".join(bits)))


if __name__ == "__main__":
    main()
