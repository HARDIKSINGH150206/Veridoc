"""VeriDoc local server: the frontend plus the pendrive model, on this computer only.

    python3 veridoc_serve.py --root /Volumes/VERIDOC/VeriDoc [--port 8765] [--open]

It starts llama-server once with the model named in manifest.json, serves the frontend from
<root>/web, and answers the app on http://127.0.0.1:<port>/api/...:

    GET  /api/health    model, tier and whether the engine is ready
    POST /api/analyse   {"text": chat export or "Name: message" lines, "me": name, "deal_type": optional}
                        -> a deal in the shapes of packages/contracts (participants, messages, terms, flags,
                           suggestions, handshake questions, score weights) plus "analysis" details

The model's answer goes through the rules engine (repair, then check) before it is returned, and every
term comes back unconfirmed: a person confirms each one in the app. Nothing is written to a vault here.
Only 127.0.0.1 is used; requests from other hosts or web pages are refused. Message content is never logged.
Works with the Mac's built-in python3 (3.9+), standard library only.
"""
import argparse, hashlib, http.server, json, os, re, socket, subprocess, sys, threading, time, urllib.request, uuid, webbrowser
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from gen_dataset import load, build_system_prompt  # noqa: E402
from wa_parse import parse_export, to_model_input  # noqa: E402
from rules import Rules  # noqa: E402
from output_schema import response_format  # noqa: E402
from veridoc_extract import free_port, physical_cores, post_chat  # noqa: E402
try:
    from deal_classifier import DealClassifier  # noqa: E402
except ImportError:  # older pendrive without the classifier
    DealClassifier = None

MAX_BODY = 5 * 1024 * 1024
PARTIES = ("party",)
RE_MD = re.compile(r"^(\d{2})-(\d{2})$")
RE_YMD = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class Engine:
    """Owns llama-server and the config. One analysis at a time (the model is single-stream)."""

    def __init__(self, root, tier=None, engine_url=None):
        self.root = root
        self.cfg = os.path.join(root, "config")
        self.schema, _lex, _gen, self.prompt, self.pbs = load(self.cfg)
        self.wa = json.load(open(os.path.join(self.cfg, "whatsapp.json"), encoding="utf-8"))
        self.sugg = json.load(open(os.path.join(self.cfg, "suggestions.json"), encoding="utf-8"))
        self.rules = Rules(self.cfg)
        self.clf = DealClassifier.load(self.cfg) if DealClassifier else None
        models = json.load(open(os.path.join(self.cfg, "models.json"), encoding="utf-8"))
        manifest = json.load(open(os.path.join(root, "manifest.json"), encoding="utf-8"))
        self.tier = tier or next(t["name"] for t in models["tiers"] if t["name"] in manifest["models"])
        self.entry = manifest["models"][self.tier]
        self.model_name = os.path.basename(self.entry["path"])
        self.ctx = next((t["ctx"] for t in models["tiers"] if self.tier.startswith(t["name"])), 4096)
        self.exe = os.path.join(root, manifest["runtime"]["dir"], "llama-server")
        self.base, self.proc, self.state, self.error = engine_url, None, "starting", None
        self.lock = threading.Lock()

    def start(self):
        try:
            if not self.base:
                port = free_port()
                logs = os.path.join(self.root, "logs")
                os.makedirs(logs, exist_ok=True)
                self.log = open(os.path.join(logs, "veridoc_serve_engine.log"), "w")
                self.proc = subprocess.Popen([self.exe, "-m", os.path.join(self.root, self.entry["path"]), "-c", str(self.ctx),
                                              "-t", str(physical_cores()), "-ngl", "999", "--host", "127.0.0.1", "--port", str(port)],
                                             stdout=self.log, stderr=subprocess.STDOUT)
                self.base = "http://127.0.0.1:%d" % port
            for _ in range(480):
                if self.proc and self.proc.poll() is not None:
                    raise RuntimeError("llama-server stopped; see logs/veridoc_serve_engine.log")
                try:
                    with urllib.request.urlopen(self.base + "/health", timeout=2) as r:
                        if json.load(r).get("status") == "ok":
                            self.state = "ready"
                            return
                except Exception:
                    pass
                time.sleep(0.5)
            raise RuntimeError("the model did not finish loading in 4 minutes")
        except Exception as e:  # reported through /api/health; the app shows rules-only wording
            self.state, self.error = "failed", str(e)

    def stop(self):
        if self.proc:
            self.proc.terminate()

    # ---------------------------------------------------------------- analysis
    def analyse(self, text, me=None, deal_type=None, messages=None):
        if messages:  # the app re-sends its own message list (e.g. after typing a simulator message)
            msgs = [{"sender": str(m.get("sender") or "?")[:80], "text": str(m.get("text") or ""), "kind": "text",
                     "ts": m.get("ts"), "file": None, "edited": False} for m in messages if str(m.get("text") or "").strip()]
            text = "\n".join("%s: %s" % (m["sender"], m["text"]) for m in msgs)
        else:
            msgs = parse_export(text, self.wa, {})
        if not msgs:
            raise ValueError("No messages found. Each line should look like a WhatsApp export line, or  Name: message")
        chat = to_model_input(msgs, self.schema)
        hint = None
        if deal_type in self.pbs:
            hint = [deal_type, None, True, "chosen in the app"]
        elif self.clf:
            d, margin, conf = self.clf.predict(chat)
            hint = [d, margin, conf, "classifier"]
        pbs = {hint[0]: self.pbs[hint[0]]} if hint and hint[2] and hint[0] in self.pbs else self.pbs
        body = {"messages": [{"role": "system", "content": build_system_prompt(self.prompt, self.pbs)}, {"role": "user", "content": chat}],
                "temperature": 0, "chat_template_kwargs": {"enable_thinking": False}}
        rf = response_format(self.schema, pbs)
        if rf:
            body["response_format"] = rf
        with self.lock:
            t0 = time.time()
            r = post_chat(self.base, body)
            secs = time.time() - t0
        out = r["choices"][0]["message"]["content"]
        pred = json.loads(out[out.index("{"): out.rindex("}") + 1])
        pred, repairs = self.rules.repair(pred, msgs, pred.get("deal_type"))
        review = self.rules.check(pred, msgs, pred.get("deal_type"))
        deal = self.to_deal(pred, repairs, review, msgs, me, text)
        deal["analysis"] = {"model": self.model_name, "tier": self.tier, "seconds": round(secs, 1), "deal_hint": hint,
                            "repairs": repairs, "unused_mentions": review.get("unused_mentions") or [],
                            "analysed_at": datetime.now().isoformat(timespec="seconds")}
        return deal

    # ------------------------------------------------- model answer -> contract shapes
    def value(self, ttype, key, v):
        if v is None:
            return None
        if ttype == "money" and isinstance(v, (int, float)):
            return {"kind": "money", "paise": str(int(round(v * 100)))}
        if ttype == "integer" and isinstance(v, int):
            return {"kind": "quantity", "amount": str(v), "unit": None} if key == "quantity" else {"kind": "integer", "value": v}
        if ttype == "date" and isinstance(v, str):
            if RE_MD.match(v):
                return {"kind": "partial_date", "month_day": "--" + v}
            if RE_YMD.match(v):
                return {"kind": "date", "date": v}
            if v in self.rules.c.get("event_cues", {}):
                return {"kind": "event", "event": v}
        return {"kind": "text", "text": str(v)}

    def quote_value(self, ttype, key, q):
        if ttype == "money":
            a = self.rules.amounts(q)
            return self.value(ttype, key, a[0]) if len(set(a)) == 1 else None
        if ttype == "integer":
            a = self.rules.integers(q)
            return self.value(ttype, key, a[0]) if len(set(a)) == 1 else None
        if ttype == "date":
            d = self.rules.dates(q)
            return self.value(ttype, key, d[0]) if len(set(d)) == 1 else None
        return None

    def to_deal(self, pred, repairs, review, msgs, me, text):
        dt_key = pred.get("deal_type")
        pb = next((p for p in self._playbooks() if p["id"] == dt_key), None)
        if pb is None:
            raise ValueError("The model did not return a known deal type.")
        senders = []
        for m in msgs:
            if m["sender"] not in senders:
                senders.append(m["sender"])
        me = me if me in senders else senders[0]
        pid = {s: "p%d" % i for i, s in enumerate(senders, 1)}
        participants = [{"id": pid[s], "display_name": s, "role": "party", "is_me": s == me} for s in senders]
        other = next((s for s in senders if s != me), "there")
        messages = [{"id": "m%d" % i, "seq": i, "sender_id": pid[m["sender"]], "ts": m.get("ts"), "text": m["text"],
                     "origin": "export", "kind": m.get("kind", "text"), "is_system": False} for i, m in enumerate(msgs, 1)]
        fixed = {x["term"]: x["rule"] for x in repairs}
        terms, flags = [], []
        pterms = pred.get("terms") or {}
        for t in pb["terms"]:
            key, ttype = t["key"], t["type"]
            o = pterms.get(key) if isinstance(pterms.get(key), dict) else {"status": "missing"}
            state = o.get("status", "missing")
            srcs = []
            for q, n in zip(o.get("quote") or [], o.get("msg") or []):
                if isinstance(n, int) and 1 <= n <= len(msgs) and isinstance(q, str):
                    srcs.append({"kind": "message", "message_id": "m%d" % n, "quote": q})
            alts = []
            if state == "contradicted":
                for s in srcs:
                    v = self.quote_value(ttype, key, s["quote"]) or {"kind": "text", "text": s["quote"]}
                    alts.append({"value": v, "origin": "ai", "sources": [s]})
            rv = review["terms"].get(key, {})
            terms.append({"id": str(uuid.uuid4()), "key": key, "value": self.value(ttype, key, o.get("value")) if state == "stated" else None,
                          "raw": None, "state": state, "unclear_reason": o.get("reason") if state == "unclear" else None,
                          "origin": "rules" if key in fixed else "ai", "repaired_by_rules": fixed.get(key),
                          "confidence": None, "needs_review": bool(rv.get("needs_review")) and state != "missing",
                          "review_flags": rv.get("flags", []), "suggested_date": rv.get("suggested_date"),
                          "sources": srcs, "alternatives": alts, "confirmed_at": None, "confirmed_by": None, "acknowledged_by_other": False})
            n0 = srcs[0]["message_id"][1:] if srcs else None
            if state == "unclear":
                flags.append(self._flag("ambiguous", key, o.get("reason") or "unclear", {"phrase": srcs[0]["quote"] if srcs else "", "message": n0}, srcs))
            elif state == "contradicted":
                flags.append(self._flag("contradiction", key, "value_changed", {"first": n0, "second": srcs[-1]["message_id"][1:] if srcs else None}, srcs))
            elif state == "missing" and t.get("required"):
                flags.append(self._flag("missing", key, "term_missing", {"term": key}, []))
            if rv.get("needs_review") and state != "missing":
                flags.append(self._flag("needs_review", key, "rules_check", {"checks": ", ".join(rv.get("flags", []))}, srcs))
        for u in review.get("unused_mentions") or []:
            vals = ["₹{:,}".format(a) for a in u["amounts"]] + [d for d in u["dates"]]
            flags.append(self._flag("needs_review", None, "unused_figure", {"message": str(u["msg"]), "values": ", ".join(vals)}, []))
        weights = [{"term_key": t["key"], "weight": t["weight"], "present": False, "clear": False, "acknowledged": False, "points": 0.0} for t in pb["terms"]]
        return {
            "description": "Analysed on this device by the local model. Every term needs a person to confirm it.",
            "playbook": {"key": dt_key, "version": 1}, "participants": participants, "messages": messages,
            "terms": terms, "flags": flags, "score": {"total": 0, "breakdown": weights},
            "suggestions": self.suggestions(terms, pb, other), "handshake_questions": self.handshake(pb),
            "voice_notes": [], "transcripts": [], "sealed_answers": [], "handshake_reveals": [], "recaps": [], "confirmations": [],
            "versions": [], "version_diffs": [], "receipts": [], "verify_results": [], "dispute_packs": [],
            "import_records": [{"file_name": None, "message_count": len(msgs), "imported_at": datetime.now().isoformat(timespec="seconds"),
                                "export_digest": hashlib.sha256(text.encode("utf-8")).hexdigest()}],
        }

    def _playbooks(self):
        out = []
        import glob
        for p in sorted(glob.glob(os.path.join(self.cfg, "playbooks", "*.json"))):
            out.append(json.load(open(p, encoding="utf-8")))
        return out

    @staticmethod
    def _flag(kind, key, code, params, srcs):
        return {"id": str(uuid.uuid4()), "kind": kind, "rule_id": code, "term_key": key, "reason_code": code,
                "reason_params": params, "sources": srcs, "created_at": datetime.now().isoformat(timespec="seconds"), "resolved_at": None}

    def suggestions(self, terms, pb, other):
        s = self.sugg
        req = {t["key"]: t for t in pb["terms"]}
        open_terms = [t for t in terms if t["state"] in ("unclear", "contradicted") and req[t["key"]]["type"] not in PARTIES]
        open_terms += [t for t in terms if t["state"] == "missing" and (req[t["key"]].get("required") or not s.get("only_required_missing"))]
        open_terms.sort(key=lambda t: (t["state"] == "missing", -req[t["key"]]["weight"]))
        open_terms = open_terms[: s["max_terms"]]
        if not open_terms:
            return []
        asks = []
        for t in open_terms:
            lab = s["labels"].get(t["key"], t["key"].replace("_", " "))
            quote = t["sources"][0]["quote"] if t["sources"] else ""
            if t["state"] == "contradicted" and len(t["alternatives"]) >= 2:
                f = lambda a: a["value"].get("paise") and "₹{:,}".format(int(a["value"]["paise"]) // 100) or a["sources"][0]["quote"]
                asks.append(s["asks"]["contradicted"].format(label=lab, a=f(t["alternatives"][0]), b=f(t["alternatives"][-1])))
            elif t["state"] == "unclear":
                tpl = s["asks_by_reason"].get(t["unclear_reason"] or "", s["asks"]["unclear"])
                asks.append(tpl.format(label=lab, quote=quote))
            else:
                asks.append(s["asks"]["missing"].format(label=lab))
        out = []
        for tone, tt in s["tones"].items():
            body = tt["join"].join(tt["bullet"] + a for a in asks) if len(asks) > 1 else asks[0]
            text = tt["join"].join(x for x in [tt["open"].format(name=other), body, tt["close"]] if x)
            out.append({"id": str(uuid.uuid4()), "target_term_keys": [t["key"] for t in open_terms], "tone": tone, "language": "en",
                        "text": text, "origin": "template", "created_at": datetime.now().isoformat(timespec="seconds"), "copied_at": None})
        return out

    def handshake(self, pb):
        s = self.sugg
        kinds = {"money": "money", "date": "date", "integer": "integer"}
        return [{"term_key": t["key"], "prompt": s["handshake_question"].format(label=s["labels"].get(t["key"], t["key"])),
                 "language": "en", "value_kind": kinds[t["type"]]}
                for t in pb["terms"] if t.get("required") and t["type"] in s["handshake_types"]]


class Handler(http.server.SimpleHTTPRequestHandler):
    engine = None
    port = None

    def log_message(self, fmt, *args):  # path and status only; never bodies (no message content in logs)
        sys.stderr.write("%s %s\n" % (self.command, self.path.split("?")[0]))

    def _local_only(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        origin = self.headers.get("Origin")
        ok_hosts = ("127.0.0.1", "localhost")
        if host not in ok_hosts:
            return False
        if origin and origin not in ("http://127.0.0.1:%d" % self.port, "http://localhost:%d" % self.port):
            return False
        return True

    def _json(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if not self._local_only():
            return self._json(403, {"error": "Only this computer can use VeriDoc."})
        if self.path.startswith("/api/health"):
            e = self.engine
            return self._json(200, {"state": e.state, "error": e.error, "model": e.model_name, "tier": e.tier,
                                    "classifier": bool(e.clf), "deal_types": list(e.pbs)})
        return super().do_GET()

    def do_POST(self):
        if not self._local_only():
            return self._json(403, {"error": "Only this computer can use VeriDoc."})
        if not self.path.startswith("/api/analyse"):
            return self._json(404, {"error": "Unknown address."})
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_BODY:
            return self._json(413, {"error": "The chat is empty or larger than 5 MB."})
        if self.engine.state != "ready":
            return self._json(503, {"error": "The AI helper is unavailable: %s" % (self.engine.error or "the model is still loading")})
        try:
            req = json.loads(self.rfile.read(n).decode("utf-8"))
            msgs = req.get("messages") if isinstance(req.get("messages"), list) else None
            deal = self.engine.analyse(req.get("text") or "", req.get("me"), req.get("deal_type"), msgs)
            return self._json(200, deal)
        except ValueError as e:
            return self._json(422, {"error": str(e)})
        except Exception as e:  # the app shows this and keeps the chat
            return self._json(500, {"error": "The AI helper failed on this chat (%s)." % type(e).__name__})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="the VeriDoc folder on the pendrive")
    ap.add_argument("--web", help="frontend folder (default: <root>/web)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--tier", help="model entry in manifest.json (default: first installed tier in models.json)")
    ap.add_argument("--engine-url", help="use an llama-server that is already running instead of starting one")
    ap.add_argument("--open", action="store_true", help="open the app in the browser")
    a = ap.parse_args()
    web = a.web or os.path.join(a.root, "web")
    if not os.path.exists(os.path.join(web, "app.html")):
        sys.exit("Frontend not found in %s (expected app.html)." % web)
    eng = Engine(a.root, a.tier, a.engine_url)
    threading.Thread(target=eng.start, daemon=True).start()
    Handler.engine, Handler.port = eng, a.port
    handler = lambda *x, **k: Handler(*x, directory=web, **k)
    try:
        srv = http.server.ThreadingHTTPServer(("127.0.0.1", a.port), handler)
    except OSError:
        sys.exit("Port %d is busy. Start with --port 8766 (or close the other VeriDoc window)." % a.port)
    url = "http://127.0.0.1:%d/app.html" % a.port
    print("VeriDoc is running at %s  (model: %s, loading in the background)" % (url, eng.model_name))
    print("Keep this window open. Press Ctrl+C to stop.")
    if a.open:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        eng.stop()


if __name__ == "__main__":
    main()
