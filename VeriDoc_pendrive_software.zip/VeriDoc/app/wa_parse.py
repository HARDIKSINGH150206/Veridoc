"""Parse a WhatsApp chat export (Android or iPhone) into VeriDoc messages.

Every pattern comes from config/whatsapp.json. Output messages keep their
timestamp and kind so the rules engine can resolve relative dates later, and
`to_model_input` renders them in the numbered format the model was trained on.

    python wa_parse.py --config <VeriDoc/config> --chat "WhatsApp Chat.txt" [--transcripts <dir>]
"""
import argparse, datetime as dt, json, os, re


def load_cfg(cfg_dir):
    with open(os.path.join(cfg_dir, "whatsapp.json"), encoding="utf-8") as f:
        wa = json.load(f)
    with open(os.path.join(cfg_dir, "schema.json"), encoding="utf-8") as f:
        schema = json.load(f)
    return wa, schema


def _clean(s, wa):
    for ch in wa["invisible_chars"]:
        s = s.replace(ch, "")
    return s.strip()


def _parse_ts(date_s, time_s, wa):
    parts = [int(p) for p in date_s.split("/")]
    order = wa["date_order"]
    d, m, y = (parts[0], parts[1], parts[2]) if order == "dmy" else (parts[1], parts[0], parts[2])
    if y < 100:
        y += 2000
    t = time_s.replace(" ", " ").replace(".", "").strip().lower()
    ampm = None
    if t.endswith("am") or t.endswith("pm"):
        ampm, t = t[-2:], t[:-2].strip()
    hms = [int(p) for p in t.split(":")]
    h, mi, ss = hms[0], hms[1], (hms[2] if len(hms) > 2 else 0)
    if ampm == "pm" and h != 12:
        h += 12
    if ampm == "am" and h == 12:
        h = 0
    return dt.datetime(y, m, d, h, mi, ss)


def parse_export(text, wa, transcripts=None):
    """Return a list of dicts: {sender, text, kind, ts, file}. System lines are dropped."""
    transcripts = transcripts or {}
    pats = [re.compile(p["regex"]) for p in wa["line_patterns"]]
    voice_pats = [re.compile(p) for p in wa["voice_patterns"]]
    sep, norm = wa["sender_separator"], wa["normalised"]
    system = {_clean(s, wa) for s in wa["system_lines"]}
    msgs = []
    for raw in text.splitlines():
        line = raw.rstrip("\n")
        stripped = _clean(line, wa) if line else ""
        m = None
        for p in pats:
            m = p.match(stripped)
            if m:
                break
        if not m:
            if msgs and stripped:  # continuation of a multi-line message
                if msgs[-1]["kind"] == "text":
                    msgs[-1]["text"] += norm["multiline_joiner"] + stripped
            continue
        rest = m.group("rest")
        if sep not in rest:
            continue  # system line without a sender (e.g. encryption notice, "X added Y")
        sender, body = rest.split(sep, 1)
        sender, body = _clean(sender, wa), _clean(body, wa)
        if body in system:
            continue
        ts = _parse_ts(m.group("date"), m.group("time"), wa)
        kind, file = "text", None
        if body in wa["media_placeholders"]:
            kind, body = "media", norm["media"]
        elif body in wa["deleted_markers"]:
            kind, body = "deleted", norm["deleted"]
        else:
            for vp in voice_pats:
                vm = vp.match(body)
                if vm:
                    kind = "voice"
                    file = vm.groupdict().get("file")
                    tr = transcripts.get(file) if file else None
                    body = norm["voice_prefix"] + tr.strip() if tr else norm["voice_no_transcript"]
                    break
        edited = False
        if kind == "text" and wa["edited_marker"] in body:
            body = body.replace(wa["edited_marker"], "").strip() + norm["edited_suffix"]
            edited = True
        msgs.append({"sender": sender, "text": body, "kind": kind, "ts": ts.isoformat(), "file": file, "edited": edited})
    if not msgs and wa.get("plain_line_pattern"):
        msgs = parse_plain(text, wa)
    return msgs


def parse_plain(text, wa):
    """Typed or pasted chat without export headers: one 'Name: message' per line; other lines continue the previous message."""
    pat = re.compile(wa["plain_line_pattern"])
    norm = wa["normalised"]
    msgs = []
    for raw in text.splitlines():
        line = _clean(raw, wa)
        if not line:
            continue
        m = pat.match(line)
        if m:
            msgs.append({"sender": m.group("sender").strip(), "text": m.group("text").strip(), "kind": "text",
                         "ts": None, "file": None, "edited": False})
        elif msgs:
            msgs[-1]["text"] += norm["multiline_joiner"] + line
    return msgs


def to_model_input(msgs, schema):
    fmt = schema["message_format"]
    return "\n".join(fmt.format(index=i, sender=m["sender"], text=m["text"]) for i, m in enumerate(msgs, 1))


def load_transcripts(folder):
    out = {}
    if folder and os.path.isdir(folder):
        for name in os.listdir(folder):
            if name.endswith(".txt"):
                with open(os.path.join(folder, name), encoding="utf-8") as f:
                    out[name[:-4]] = f.read()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--chat", required=True)
    ap.add_argument("--transcripts", help="folder of <audio filename>.txt transcripts")
    ap.add_argument("--json", action="store_true", help="print parsed messages as JSON")
    a = ap.parse_args()
    wa, schema = load_cfg(a.config)
    with open(a.chat, encoding="utf-8") as f:
        msgs = parse_export(f.read(), wa, load_transcripts(a.transcripts))
    print(json.dumps(msgs, ensure_ascii=False, indent=1) if a.json else to_model_input(msgs, schema))


if __name__ == "__main__":
    main()
