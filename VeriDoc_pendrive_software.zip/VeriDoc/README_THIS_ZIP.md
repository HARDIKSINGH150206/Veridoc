# VeriDoc pendrive: software copy

This zip has the VeriDoc pendrive's software: the app code (`app/`), the configuration (`config/`), the frontend (`web/`), the synthetic demo chats (`data/demo_chats/`) and the launcher (`Start VeriDoc.command`).

## Not included in this zip

These live only on the pendrive itself and were not reachable when this zip was made:

| Path | What it is |
|---|---|
| `models/*.gguf` | The model files: veridoc-small (v3, active), veridoc-small-v2, veridoc-small-v1, Qwen3-0.6B base. About 600 MB each. |
| `runtime/bin/` | The llama.cpp engine (llama-server, build b11869) for macOS. |
| `manifest.json` | Which model file each tier uses, with checksums. |
| `config/models.json`, `config/training.json` | Model tiers and the training recipe. |
| `config/deal_classifier.json` | Created only after you train the deal-type classifier (update 5). |
| `logs/` | Run logs. |

The files in `app/` and `config/` are the latest versions from the updates (u4, u5, u6). `app/gen_dataset.py` is the workspace copy; if you trimmed the pendrive's copy by hand, keep yours.

## Full copy including the models

Run this on the Mac with the pendrive plugged in:

    cd /Volumes/VERIDOC && zip -r -y ~/Desktop/VeriDoc_pendrive_full.zip VeriDoc -x "*.DS_Store" "*/._*" "*/.Spotlight-V100/*" "*/.Trashes/*" "*/.fseventsd/*"

Do not commit model files or this full zip to the repository.
