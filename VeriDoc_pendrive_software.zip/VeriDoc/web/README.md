# VeriDoc frontend (glass theme)

A static frontend for VeriDoc in a macOS glass style: a landing page, the app (screens S1–S8, S10–S12) and the standalone verify page (S9).
It is plain HTML, CSS and JavaScript, with no build step, no framework, no CDN and no network calls, as the repo's frontend rules require.

## Open it

- In VS Code: open this folder, then open `index.html` in a browser. Double-clicking the file works, and so does the Live Server extension.
- Or from a terminal in this folder: `python3 -m http.server 8080`, then go to http://localhost:8080

## Files

| File | What it is |
|---|---|
| `index.html` | Landing page: glass nav, spotlight hero with a live chat demo, features grid, how it works, honest limits, FAQ, call to action |
| `app.html` | The app window: sidebar, toolbar and every screen (hash routes like `#/workspace/ambiguous`) |
| `verify.html` | S9 verify page as one self-contained file (styles and script inline, system fonts) |
| `assets/css/tokens.css` | Every colour, radius, blur and font stack, for light and dark |
| `assets/css/glass.css` | Shared pieces: glass surfaces, window chrome, buttons, segmented controls, switches, status pills, notices |
| `assets/css/landing.css`, `assets/css/app.css` | Page-specific layout |
| `assets/css/fonts.css`, `assets/fonts/` | Bundled Noto Sans (Latin, Devanagari, Kannada), OFL licence |
| `assets/js/core.js` | Strings (LIMITS wording), value formatting (paise → ₹, partial dates), the FR-SCO-001 score, icons, theme, toast |
| `assets/js/fixtures.js` | Mock data: the three made-up deals from `packages/contracts/fixtures`, copied as-is |
| `assets/js/app.js` | Router and all app screens |
| `assets/js/landing.js` | Hero demo and scroll reveal |

## Screens

| Route | Screen |
|---|---|
| `#/deals` | S1 Deals: search, filters, evidence strength, conflicts sorted first |
| `#/import` | S2 Import: WhatsApp export (.txt is read in the browser), paste, simulator, sample chats, "which one is you", deal type |
| `#/workspace/<deal>` | S3 Workspace: chat with highlighted terms and voice transcripts, evidence strength with "Why?", terms, flags, suggested message |
| `#/workspace/<deal>/term/<key>` | S4 Term detail sheet: source and neighbours, conflict choices, exact value, confirm or reject |
| `#/handshake/<deal>` | S5 Blind Handshake: ask, seal, reveal |
| `#/recap/<deal>` | S6 Recap and echo code, reply check, plus S12 (what the other person sees in WhatsApp) |
| `#/versions/<deal>` | S7 Versions and diff |
| `#/receipt/<deal>` | S8 Receipt: chain, commitment, anchor status |
| `#/pack/<deal>` | S10 Dispute pack |
| `#/settings` | S11 Settings: vault, language, appearance, models, safe mode, all limits L1–L14 |

The sample deals are `clean`, `ambiguous` and `contradictory`.

## What is real and what is mocked

- Real in the browser: the score formula (FR-SCO-001, it reproduces the fixture totals 100, 55 and 37), confirming and rejecting terms, reading a .txt WhatsApp export, the echo-code reply check, theme and safe-mode switches.
- Mocked: no backend is connected. Analysis of an imported chat, saving a recap, exporting the receipt bundle or dispute pack, and the verify engine all show a plain message saying they need the local VeriDoc service, rather than faking a result. The handshake seal on a new deal is a browser preview hash, labelled as such.
- When `apps/api` is ready, replace the reads from `window.VD_FIXTURES` in `app.js` with calls to the local API. The data shapes already match `packages/contracts`.

## Rules followed

- Every status shows a symbol and a word: ✓ Clear · ! Ambiguous · ○ Missing · ⚠ Conflict.
- The wording comes from `docs/LIMITS.md`: "tamper-evident", "court-ready evidence package", "Drafting aid, not legal advice". No accuracy figures appear in the UI.
- Light and dark mode follow the system; the toggle is remembered per browser.
- Keyboard: visible focus, the sheet traps focus and closes with Esc. Respects reduced motion.

## Repo note

In the repo, `apps/web` and `apps/verify` belong to Area 4. Hand this to the Area 4 owner to merge into their screen folders, instead of committing it from another area.

## Running it with the pendrive model

`veridoc_serve.py` (on the pendrive, in `app/`) starts the model, serves this folder from `<pendrive>/VeriDoc/web`, and answers the app on `http://127.0.0.1:8765`. When the app is opened through that address it:

- shows "Local model ready" in the toolbar once the model has loaded;
- sends an imported or pasted chat to `/api/analyse`, and fills the workspace with the model's terms after the rules engine has repaired and checked them (every term still starts unconfirmed);
- re-analyses after you type a simulator message, keeping the terms you already confirmed;
- drafts the suggested message from `config/suggestions.json` templates, not from the model.

Opened as a plain file (double-click `app.html`), it works on the sample deals only.
