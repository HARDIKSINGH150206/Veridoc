/* Shared helpers: UI strings, value formatting (contract value kinds), icons, theme, toast.
   Wording follows docs/LIMITS.md. No network calls anywhere in this frontend. */
(function () {
  "use strict";

  const STR = {
    status: { stated: ["clear", "Clear"], unclear: ["ambiguous", "Ambiguous"], missing: ["missing", "Missing"], contradicted: ["conflict", "Conflict"] },
    terms: {
      buyer: "Buyer", seller: "Seller", item: "Item", quantity: "Quantity", unit_price: "Price per unit",
      total_amount: "Total amount", advance_amount: "Advance", delivery_date: "Delivery date",
      balance_payment_date: "Final payment", late_penalty: "Late penalty", quality_spec: "Quality",
      client: "Client", freelancer: "Freelancer", scope: "Scope", fee: "Fee", deadline: "Deadline",
      revisions: "Revisions", payment_date: "Payment date", ownership_transfer: "Ownership"
    },
    events: { on_delivery: "on delivery", on_completion: "on completion", on_signing: "on signing" },
    reasons: {
      relative_date: (p) => `"${p.phrase || "this date"}" is relative. Which exact date is meant?`,
      term_missing: (p) => `${label(p.term)} is not in the chat yet.`,
      value_changed: (p) => `The value changes between message #${p.first} and message #${p.second}.`,
      text_vs_voice: (p) => `The voice note says something different from the text in message #${p.message}.`,
      low_voice_confidence: () => "The voice transcript is unsure here. Listen to that moment before confirming.",
      unclear: (p) => `"${p.phrase || "This"}" is not exact enough to confirm.`,
      approximate_amount: (p) => `"${p.phrase || "This amount"}" is approximate. What is the exact amount?`,
      vague_timing: (p) => `"${p.phrase || "This"}" does not give a date.`,
      conditional: (p) => `"${p.phrase || "This"}" depends on something else happening.`,
      unspecified_unit: (p) => `"${p.phrase || "This figure"}" has no unit. Is it rupees, thousands or a count?`,
      unconfirmed: (p) => `"${p.phrase || "This"}" was proposed but not agreed by the other side.`,
      vague_spec: (p) => `"${p.phrase || "This"}" is too vague to check later.`,
      rules_check: (p) => `The rules engine could not confirm the AI helper's answer against the chat (${p.checks || "check failed"}).`,
      unused_figure: (p) => `Message #${p.message} mentions ${p.values} but no term uses it. A term may be wrongly marked missing.`
    },
    limits: [
      ["L1", "Drafting aid, not legal advice."],
      ["L2", "VeriDoc does not predict how a court or council will decide."],
      ["L3", "This checks that the record was not changed after it was saved. It cannot prove that the original chat export was genuine."],
      ["L4", "VeriDoc does not replace documents that the law requires to be written, stamped or registered. Ask a lawyer if your deal may need one."],
      ["L5", "The AI helper is weaker on Hinglish and Kannada-English. Please check every term before you confirm it."],
      ["L6", "The time shown comes from this device's clock. It can be wrong until the record is anchored."],
      ["L7", "The confirmation code relies on the chat export being genuine. It does not show who typed the reply."],
      ["L8", "VeriDoc processes the other person's messages on your device. A lawyer should review data-protection duties before public launch."],
      ["L9", "The certificate is an unsigned draft and must be completed by the person responsible for the device."],
      ["L10", "If you lose both the passphrase and the recovery key, the data cannot be opened."],
      ["L11", "Accuracy figures are targets until a trust report shows measured results."],
      ["L13", "Exported files are not encrypted. Share them only with people you trust."],
      ["L14", "Safe mode: rules only. The AI helper is off."]
    ]
  };

  function label(key) { return STR.terms[key] || String(key || "").replace(/_/g, " "); }

  const inr = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 });
  function money(paise) {
    if (paise == null) return "";
    const n = Number(BigInt(paise)) / 100; // money arrives as paise strings (contracts)
    return "₹" + inr.format(n);
  }
  function date(iso) {
    if (!iso) return "";
    if (iso.startsWith("--")) { // PartialDateValue: --MM-DD (year not stated)
      const [m, d] = iso.slice(2).split("-").map(Number);
      return new Date(2000, m - 1, d).toLocaleDateString("en-IN", { day: "numeric", month: "short" }) + " (year not stated)";
    }
    return new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  }
  function time(ts) {
    if (!ts) return "";
    return new Date(ts).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
  }
  function clock(ts) { return ts ? new Date(ts).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" }) : ""; }
  function value(v) {
    if (!v) return "";
    switch (v.kind) {
      case "text": return v.text;
      case "money": return money(v.paise);
      case "quantity": return `${v.amount} ${v.unit || ""}`.trim();
      case "date": return date(v.date);
      case "partial_date": return date(v.month_day);
      case "event": return STR.events[v.event] || v.event.replace(/_/g, " ");
      case "duration": return `${v.amount} ${v.unit}`;
      case "integer": return String(v.value ?? v.amount);
      default: return JSON.stringify(v);
    }
  }
  function statusPill(state, extra) {
    const [cls, word] = STR.status[state] || ["neutral", state];
    return `<span class="status ${cls}">${extra || word}</span>`;
  }
  function short(h, n) { return h ? h.slice(0, n || 8) : ""; }
  function esc(s) { return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

  /* Score: PRD FR-SCO-001. Only user-confirmed terms count as present. */
  function score(terms, weights, bothInChat) {
    let total = 0;
    const rows = Object.entries(weights).map(([key, w]) => {
      const t = terms.find((x) => x.key === key);
      const confirmed = !!(t && t.confirmed_at);
      const present = confirmed && t.state !== "missing";
      const clear = present && t.state === "stated";
      const ack = present && (t.acknowledged_by_other || (bothInChat && (key === "buyer" || key === "seller" || key === "client" || key === "freelancer")));
      const pts = w * (0.4 * present + 0.3 * clear + 0.3 * ack);
      total += pts;
      return { term_key: key, weight: w, present, clear, acknowledged: !!ack, points: Math.round(pts * 10) / 10 };
    });
    return { total: Math.round(total), breakdown: rows };
  }

  /* Icons: simple line drawings in the SF Symbols spirit (drawn here, no icon font, no CDN). */
  const P = {
    deals: '<path d="M4 6h16M4 12h16M4 18h10"/>',
    import: '<path d="M12 3v12m0 0-4-4m4 4 4-4M5 21h14"/>',
    workspace: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M10 4v16"/>',
    handshake: '<path d="M3 12l4-4 4 3 3-3 7 6"/><path d="M7 16l3 3 4-4"/>',
    recap: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/>',
    versions: '<circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="12" r="2.5"/><path d="M6 8.5v7M8.3 7.2 15.7 11M8.3 16.8l7.4-3.8"/>',
    receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
    pack: '<path d="M3 7l9-4 9 4-9 4z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    verify: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    offline: '<path d="M2 8.5a15 15 0 0 1 20 0M5.5 12a10 10 0 0 1 13 0M9 15.5a5 5 0 0 1 6 0"/><circle cx="12" cy="19" r="1"/><path d="M3 3l18 18"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    send: '<path d="M4 12l16-8-6 16-2.5-6.5z"/>',
    play: '<path d="M8 5v14l11-7z"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    chevron: '<path d="M9 6l6 6-6 6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    sparkle: '<path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/>',
    file: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/>',
    chat: '<path d="M4 5h16v11H9l-5 4z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    hash: '<path d="M5 9h14M5 15h14M10 3 8 21M16 3l-2 18"/>',
    pendrive: '<rect x="7" y="9" width="10" height="13" rx="2"/><path d="M9 9V3h6v6M11 5h0M13 5h0"/>'
  };
  function icon(name, cls) {
    return `<svg class="${cls || "ic"}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || ""}</svg>`;
  }

  /* Theme: system by default; the toggle stores the choice for this viewer only. */
  function getTheme() { try { return localStorage.getItem("vd-theme"); } catch (e) { return null; } }
  function applyTheme(t) {
    if (t) document.documentElement.setAttribute("data-theme", t); else document.documentElement.removeAttribute("data-theme");
  }
  function toggleTheme() {
    const dark = document.documentElement.getAttribute("data-theme") === "dark" ||
      (!document.documentElement.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches);
    const next = dark ? "light" : "dark";
    applyTheme(next);
    try { localStorage.setItem("vd-theme", next); } catch (e) { /* storage unavailable: theme lasts this visit */ }
  }
  applyTheme(getTheme());

  let toastTimer;
  function toast(msg) {
    let el = document.querySelector(".toast");
    if (!el) { el = document.createElement("div"); el.className = "toast"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
  }
  async function copy(text, msg) {
    try { await navigator.clipboard.writeText(text); toast(msg || "Copied"); }
    catch (e) {
      const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); toast(msg || "Copied"); } catch (e2) { toast("Copy failed: select the text and copy it"); }
      ta.remove();
    }
  }

  window.VD = { STR, label, money, date, time, clock, value, statusPill, short, esc, score, icon, toggleTheme, toast, copy };
})();
