/* Landing page: hero demo built from the ambiguous sample deal, scroll reveal, theme toggle. */
(function () {
  "use strict";
  const { esc, value, statusPill, label, clock, icon, toggleTheme } = window.VD;
  const deal = window.VD_FIXTURES.ambiguous;
  const me = deal.participants.find((p) => p.is_me);

  // theme button
  document.querySelectorAll("[data-theme-toggle]").forEach((b) => {
    const paint = () => {
      const dark = document.documentElement.getAttribute("data-theme") === "dark" ||
        (!document.documentElement.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches);
      b.innerHTML = icon(dark ? "sun" : "moon");
    };
    paint();
    b.addEventListener("click", () => { toggleTheme(); paint(); });
  });

  // scroll reveal
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach((el) => io.observe(el));

  // hero demo: messages arrive, then the terms they produce appear
  const chatEl = document.getElementById("demoChat");
  const termsEl = document.getElementById("demoTerms");
  const scoreEl = document.getElementById("demoScore");
  const meterEl = document.getElementById("demoMeter");
  const suggestEl = document.getElementById("demoSuggest");
  const byMsg = {};
  deal.terms.forEach((t) => t.sources.forEach((s) => { if (s.message_id) (byMsg[s.message_id] = byMsg[s.message_id] || []).push(t); }));
  const show = ["quantity", "unit_price", "delivery_date", "advance_amount"];

  function highlight(text, terms) {
    let h = esc(text);
    terms.forEach((t) => t.sources.forEach((s) => {
      if (!s.quote || !text.includes(s.quote) || s.quote.length < 3) return;
      h = h.replace(esc(s.quote), `<mark class="${t.state === "stated" ? "ok" : ""}">${esc(s.quote)}</mark>`);
    }));
    return h;
  }

  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  let shown = 0;
  function run() {
    chatEl.innerHTML = ""; termsEl.innerHTML = ""; suggestEl.hidden = true; shown = 0;
    scoreEl.textContent = "–"; meterEl.style.width = "0%";
    deal.messages.forEach((m, i) => {
      setTimeout(() => {
        const ts = byMsg[m.id] || [];
        const div = document.createElement("div");
        div.className = "msg " + (m.sender_id === me.id ? "out" : "in");
        div.innerHTML = `<span class="n">#${m.seq}</span>${highlight(m.text, ts)}<small>${clock(m.ts)}</small>`;
        chatEl.appendChild(div);
        ts.filter((t) => show.includes(t.key) && !termsEl.querySelector(`[data-k="${t.key}"]`)).forEach((t) => {
          const li = document.createElement("li");
          li.dataset.k = t.key;
          li.innerHTML = `<span class="k">${esc(label(t.key))}</span>${statusPill(t.state)}<span class="v">${esc(t.state === "stated" ? value(t.value) : '"' + (t.sources[0] && t.sources[0].quote || "") + '"')}</span>`;
          termsEl.appendChild(li);
          shown++;
        });
        if (i === deal.messages.length - 1) {
          scoreEl.textContent = deal.score.total; meterEl.style.width = deal.score.total + "%"; // score from FR-SCO-001 (fixture)
          const li = document.createElement("li");
          li.innerHTML = `<span class="k">${label("balance_payment_date")}</span>${statusPill("missing")}<span class="v faint">not in the chat yet</span>`;
          termsEl.appendChild(li);
          setTimeout(() => { suggestEl.hidden = false; }, reduced ? 0 : 700);
        }
      }, reduced ? 0 : 700 + i * 1100);
    });
  }
  const heroIo = new IntersectionObserver((es) => { if (es[0].isIntersecting) { run(); heroIo.disconnect(); } }, { threshold: 0.3 });
  heroIo.observe(chatEl);
})();
