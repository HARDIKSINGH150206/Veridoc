/* VeriDoc app: hash router and screens S1–S8, S10–S12 (S9 is the standalone verify.html).
   Built against mock data shaped like packages/contracts (assets/js/fixtures.js).
   Nothing here talks to a network. Actions that need the local API say so instead of pretending. */
(function () {
  "use strict";
  const { STR, label, money, date, time, clock, value, statusPill, short, esc, score, icon, toggleTheme, toast, copy } = window.VD;

  /* ======================= state ======================= */
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const S = {
    deals: {},
    order: [],
    locked: false,
    safeMode: false,
    noticeL5: true,
    tone: "polite",
    lang: "en",
    sealed: {},     // deal -> my sealed handshake record (this session only)
    imported: 0
  };
  for (const [k, d] of Object.entries(window.VD_FIXTURES)) addDeal(k, clone(d));

  function addDeal(key, d) {
    d.key = key;
    d.audit = d.audit || [];
    d.weights = Object.fromEntries((d.score ? d.score.breakdown : []).map((b) => [b.term_key, b.weight]));
    S.deals[key] = d;
    S.order.push(key);
  }
  const me = (d) => d.participants.find((p) => p.is_me) || d.participants[0];
  const other = (d) => d.participants.find((p) => !p.is_me) || d.participants[1] || { display_name: "the other party" };
  const nameOf = (d, id) => (d.participants.find((p) => p.id === id) || {}).display_name || "Unknown";
  const msg = (d, id) => d.messages.find((m) => m.id === id);
  const seq = (d, id) => (msg(d, id) || {}).seq;
  const term = (d, key) => d.terms.find((t) => t.key === key);
  function dealTitle(d) {
    const item = term(d, "item") || term(d, "scope");
    return `${me(d).display_name} ↔ ${other(d).display_name}` + (item && item.value ? ` · ${value(item.value)}` : "");
  }
  function liveScore(d) {
    if (!d.weights || !Object.keys(d.weights).length) return { total: 0, breakdown: [] };
    return score(d.terms, d.weights, d.participants.length >= 2); // FR-SCO-001
  }
  function dealState(d) {
    const conflicts = d.flags.filter((f) => f.kind === "contradiction" && !f.resolved_at).length;
    const gaps = d.flags.filter((f) => (f.kind === "missing" || f.kind === "ambiguous") && !f.resolved_at).length;
    const vn = d.versions.length ? d.versions[d.versions.length - 1].version_n : null;
    const conf = d.confirmations.filter((c) => c.version_n === vn);
    let status;
    if (vn && conf.length >= 2 && conf.every((c) => c.state === "confirmed")) status = ["clear", `Confirmed v${vn}`];
    else if (d.recaps.length) status = ["pending", `Awaiting ${other(d).display_name}`];
    else if (d.suggestions.length && !conflicts) status = ["pending", "Awaiting reply"];
    else status = ["neutral", "Draft"];
    const del = term(d, "delivery_date") || term(d, "deadline");
    const next = del && del.state === "stated" && del.value ? value(del.value) : "—";
    return { conflicts, gaps, status, next, attention: conflicts > 0 || gaps > 0 };
  }

  /* ======================= router ======================= */
  const view = document.getElementById("view");
  const routes = {
    deals: renderDeals, import: renderImport, workspace: renderWorkspace, handshake: renderHandshake,
    recap: renderRecap, versions: renderVersions, receipt: renderReceipt, pack: renderPack, settings: renderSettings
  };
  let current = { name: "deals", deal: null };
  function parse() {
    const parts = (location.hash.replace(/^#\/?/, "") || "deals").split("/");
    const name = routes[parts[0]] ? parts[0] : "deals";
    const deal = parts[1] && S.deals[parts[1]] ? parts[1] : null;
    return { name, deal, sub: parts[2], subId: parts[3] };
  }
  function go(h) { location.hash = h; }
  function render() {
    const r = parse();
    const needsDeal = !["deals", "import", "settings"].includes(r.name);
    if (needsDeal && !r.deal) { go(`#/${r.name}/${current.deal || S.order[1] || S.order[0]}`); return; }
    if (r.deal) current.deal = r.deal;
    current.name = r.name;
    closeSheet(true);
    renderChrome(r);
    view.innerHTML = "";
    routes[r.name](r.deal ? S.deals[r.deal] : null, r);
    view.scrollTop = 0;
    if (r.sub === "term" && r.subId) openTerm(S.deals[r.deal], r.subId);
    document.querySelector(".sidebar").classList.remove("open");
  }
  window.addEventListener("hashchange", render);

  /* ======================= chrome ======================= */
  function renderChrome(r) {
    const d = current.deal ? S.deals[current.deal] : null;
    const nav = document.getElementById("sideNav");
    const item = (route, ic, text, count) => {
      const href = ["deals", "import", "settings"].includes(route) ? `#/${route}` : `#/${route}/${current.deal}`;
      return `<a class="side-item" href="${href}" ${r.name === route ? 'aria-current="page"' : ""}>${icon(ic)}<span>${text}</span>${count != null ? `<span class="count">${count}</span>` : ""}</a>`;
    };
    const st = d ? dealState(d) : null;
    nav.innerHTML = `
      <div class="side-group">
        ${item("deals", "deals", "Deals", S.order.length)}
        ${item("import", "import", "New deal")}
      </div>
      ${d ? `<div class="side-group">
        <div class="side-label">This deal</div>
        <div class="deal-switch"><label class="sr-only" for="dealSel">Choose deal</label>
          <select class="select" id="dealSel">${S.order.map((k) => `<option value="${k}" ${k === current.deal ? "selected" : ""}>${esc(dealTitle(S.deals[k]))}</option>`).join("")}</select></div>
        ${item("workspace", "workspace", "Workspace", st.conflicts + st.gaps || null)}
        ${item("handshake", "handshake", "Blind Handshake")}
        ${item("recap", "recap", "Recap and confirm")}
        ${item("versions", "versions", "Versions", d.versions.length || null)}
        ${item("receipt", "receipt", "Receipt")}
        ${item("pack", "pack", "Dispute pack")}
      </div>` : ""}
      <div class="side-group">
        <div class="side-label">VeriDoc</div>
        <a class="side-item" href="verify.html">${icon("verify")}<span>Verify page</span></a>
        ${item("settings", "settings", "Settings")}
      </div>`;
    const sel = document.getElementById("dealSel");
    if (sel) sel.addEventListener("change", () => go(`#/${["deals", "import", "settings"].includes(r.name) ? "workspace" : r.name}/${sel.value}`));
    document.getElementById("sideFoot").innerHTML = `<span>${icon("lock", "ic")} Stored on this device</span><span>Sample deals are made up.</span>`;

    const names = { deals: "Deals", import: "New deal", workspace: "Workspace", handshake: "Blind Handshake", recap: "Recap and confirm", versions: "Versions", receipt: "Receipt", pack: "Dispute pack", settings: "Settings" };
    const crumbs = [`<a href="#/deals">Deals</a>`];
    if (d && !["deals", "import", "settings"].includes(r.name)) crumbs.push(`<span class="sep">›</span><a href="#/workspace/${d.key}">${esc(dealTitle(d))}</a>`);
    if (r.name !== "deals") crumbs.push(`<span class="sep">›</span><b>${names[r.name]}</b>`);
    document.getElementById("crumbs").innerHTML = crumbs.join("");

    document.getElementById("bannerSlot").innerHTML = S.safeMode
      ? `<div class="notice warn" role="status"><span class="sym">!</span><p>${STR.limits.find((l) => l[0] === "L14")[1]}</p></div>` : "";
  }
  function paintThemeBtn() {
    const dark = document.documentElement.getAttribute("data-theme") === "dark" ||
      (!document.documentElement.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches);
    document.getElementById("themeBtn").innerHTML = icon(dark ? "sun" : "moon");
  }
  document.getElementById("themeBtn").addEventListener("click", () => { toggleTheme(); paintThemeBtn(); });
  document.getElementById("lockBtn").innerHTML = `${icon("lock")}<span>Lock vault</span>`;
  document.getElementById("lockBtn").addEventListener("click", lockVault);
  document.getElementById("menuBtn").innerHTML = icon("deals");
  document.getElementById("menuBtn").addEventListener("click", () => document.querySelector(".sidebar").classList.toggle("open"));
  paintThemeBtn();

  /* ======================= local VeriDoc service (pendrive model) ======================= */
  const API = { info: null, get ok() { return !!(this.info && this.info.state === "ready"); } };
  async function checkApi() {
    if (!/^https?:$/.test(location.protocol)) return; // opened as a file: sample data only
    try {
      const r = await fetch("/api/health", { cache: "no-store" });
      API.info = await r.json();
    } catch (e) { API.info = null; }
    paintModelBadge();
    if (API.info && API.info.state === "starting") setTimeout(checkApi, 2000);
    else if (current.name === "settings" || current.name === "workspace") render();
  }
  function paintModelBadge() {
    const b = document.getElementById("modelBadge");
    if (!API.info) { b.hidden = true; return; }
    b.hidden = false;
    const st = API.info.state;
    b.className = "status " + (st === "ready" ? "clear" : st === "starting" ? "pending" : "conflict");
    b.textContent = st === "ready" ? "Local model ready" : st === "starting" ? "Model loading…" : "AI helper unavailable";
    b.title = API.info.model + (API.info.error ? " · " + API.info.error : "");
  }
  async function apiAnalyse(payload) {
    const r = await fetch("/api/analyse", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    let j = {};
    try { j = await r.json(); } catch (e) { /* not JSON */ }
    if (!r.ok) throw new Error(j.error || "The AI helper is unavailable. Showing rules-only results.");
    return j;
  }
  function liveKey() { return "live-" + (++S.imported); }
  /* Re-analyse a deal's current messages, keeping every term the person already confirmed. */
  async function reanalyse(d) {
    const fresh = await apiAnalyse({
      messages: d.messages.map((m) => ({ sender: nameOf(d, m.sender_id), text: m.text, ts: m.ts })),
      me: me(d).display_name, deal_type: d.pendingAnalysis ? undefined : d.playbook.key
    });
    const seqOld = Object.fromEntries(d.messages.map((m) => [m.id, m.seq]));
    const kept = d.terms.filter((t) => t.confirmed_at).map((t) => Object.assign(t, {
      sources: t.sources.map((x) => x.message_id ? Object.assign({}, x, { message_id: "m" + seqOld[x.message_id] }) : x)
    }));
    fresh.terms = fresh.terms.map((t) => kept.find((k) => k.key === t.key) || t);
    fresh.flags = fresh.flags.filter((f) => !kept.some((k) => k.key === f.term_key));
    const keepKeys = ["key", "audit", "recaps", "confirmations", "versions", "version_diffs", "receipts", "dispute_packs", "sealed_answers", "handshake_reveals"];
    keepKeys.forEach((k) => { if (d[k] && (!Array.isArray(d[k]) || d[k].length)) fresh[k] = d[k]; });
    fresh.import_records = d.import_records;
    fresh.weights = Object.fromEntries(fresh.score.breakdown.map((b) => [b.term_key, b.weight]));
    Object.keys(d).forEach((k) => delete d[k]);
    Object.assign(d, fresh);
    d.audit.push({ ts: new Date().toISOString(), what: "Analysed again on this device" });
  }

  function needsApi(what) { toast(`${what} runs in the local VeriDoc service. This build uses sample data.`); }
  const h = (html) => { view.insertAdjacentHTML("beforeend", html); };

  /* ======================= S1 Deals ======================= */
  function renderDeals() {
    const states = S.order.map((k) => [k, dealState(S.deals[k])]);
    const needReply = states.filter(([, s]) => s.status[0] === "pending").length;
    h(`<div class="page-head"><div class="grow"><h1>Deals</h1>
        <p>${S.order.length} deals · ${needReply} ${needReply === 1 ? "needs" : "need"} a reply · stored on this device</p></div>
        <div class="actions"><a class="btn btn-primary" href="#/import">${icon("plus")}New deal</a></div></div>
      <div class="list-tools">
        <div class="search">${icon("search")}<label class="sr-only" for="q">Search deals</label><input class="input" id="q" placeholder="Search by deal or person"></div>
        <div class="segmented" role="tablist" aria-label="Filter">
          ${["All", "Needs attention", "Awaiting confirmation", "Confirmed"].map((f, i) => `<button role="tab" data-f="${i}" aria-selected="${i === 0}">${f}</button>`).join("")}
        </div>
      </div>
      <div class="deal-list" id="dealList"></div>`);
    let filter = 0, q = "";
    const list = document.getElementById("dealList");
    function paint() {
      const rows = states.filter(([k, s]) => {
        const d = S.deals[k];
        if (q && !dealTitle(d).toLowerCase().includes(q) && !d.participants.some((p) => p.display_name.toLowerCase().includes(q))) return false;
        if (filter === 1) return s.attention;
        if (filter === 2) return s.status[0] === "pending";
        if (filter === 3) return s.status[0] === "clear";
        return true;
      }).sort((a, b) => b[1].conflicts - a[1].conflicts);
      if (!rows.length) {
        list.innerHTML = q ? `<div class="empty card"><div class="big" aria-hidden="true">⌕</div><h2>No deals match "${esc(q)}"</h2><p>Search looks at deal names and the people in them.</p></div>`
          : `<div class="empty card"><div class="big" aria-hidden="true">○</div><h2>No deals here yet</h2><p>No deals yet. Start one by importing a chat.</p><div class="actions"><a class="btn btn-primary" href="#/import">New deal</a><a class="btn" href="#/workspace/ambiguous">Try a sample deal</a></div></div>`;
        return;
      }
      list.innerHTML = rows.map(([k, s]) => {
        const d = S.deals[k], sc = liveScore(d);
        const gapsTxt = [s.conflicts ? `⚠ ${s.conflicts} conflict${s.conflicts > 1 ? "s" : ""}` : "", s.gaps ? `${s.gaps} gap${s.gaps > 1 ? "s" : ""}` : ""].filter(Boolean).join(" · ") || "✓ No open gaps";
        return `<div class="deal-row ${s.conflicts ? "attn" : ""}">
          <div><div class="deal-name">${esc(dealTitle(d))}</div><div class="deal-sub">${d.playbook.key === "supply_order" ? "Supply or order" : "Freelance job"} · ${d.messages.length} messages</div></div>
          <div class="strength" title="Evidence strength, 0 to 100"><div class="meter"><span style="width:${sc.total}%"></span></div><span>${sc.total}</span></div>
          <div class="deal-meta">${gapsTxt}</div>
          <div class="deal-meta">Next: ${esc(s.next)}</div>
          <div><span class="status ${s.status[0]}">${esc(s.status[1])}</span></div>
          <a class="btn btn-sm" href="#/workspace/${k}">Open</a>
        </div>`;
      }).join("");
    }
    view.querySelector(".segmented").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      filter = +b.dataset.f;
      view.querySelectorAll(".segmented button").forEach((x) => x.setAttribute("aria-selected", x === b));
      paint();
    });
    document.getElementById("q").addEventListener("input", (e) => { q = e.target.value.trim().toLowerCase(); paint(); });
    paint();
  }

  /* ======================= S2 Import ======================= */
  const LRM = /[‎‏‪-‮⁦-⁩]/g;
  const PATTERNS = [
    /^\[(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:\s?[AaPp]\.?\s?[Mm]\.?)?)\]\s([^:]+):\s?(.*)$/, // iPhone
    /^(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}),?\s+(\d{1,2}:\d{2}(?:\s?[AaPp]\.?\s?[Mm]\.?)?)\s[-–]\s([^:]+):\s?(.*)$/ // Android
  ];
  function parseChat(text) {
    const lines = text.replace(/\r/g, "").replace(/ /g, " ").replace(LRM, "").split("\n");
    const out = []; const bad = [];
    for (const line of lines) {
      if (!line.trim()) continue;
      let m = null;
      for (const p of PATTERNS) { m = line.match(p); if (m) break; }
      if (m) { out.push({ date: m[1], time: m[2], sender: m[3].trim(), text: m[4] }); continue; }
      const plain = line.match(/^([^:\[\]]{1,40}):\s(.+)$/);
      if (plain && !out.some((o) => o.date)) { out.push({ date: null, time: null, sender: plain[1].trim(), text: plain[2] }); continue; }
      if (out.length) out[out.length - 1].text += "\n" + line; else bad.push(line);
    }
    const media = out.filter((o) => /<Media omitted>|omitted|\.opus|\.m4a|\(file attached\)/i.test(o.text)).length;
    const voice = out.filter((o) => /\.opus|\.m4a|audio omitted|PTT-/i.test(o.text)).length;
    const people = [...new Set(out.map((o) => o.sender))];
    const dates = out.map((o) => o.date).filter(Boolean);
    return { messages: out, media, voice, people, first: dates[0], last: dates[dates.length - 1], bad, formatted: dates.length > 0 };
  }
  function renderImport() {
    let src = "export", preview = null, sample = null, meName = null, dealType = null, fileName = "", busy = false;
    h(`<div class="page-head"><div class="grow"><h1>Import chat</h1><p>Bring in a chat and check what VeriDoc understood before it analyses anything.</p></div></div>
      <div class="grid-2">
        <div class="stack">
          <div class="segmented" role="tablist" aria-label="Source">
            <button role="tab" data-s="export" aria-selected="true">WhatsApp export</button>
            <button role="tab" data-s="paste" aria-selected="false">Paste text</button>
            <button role="tab" data-s="sim" aria-selected="false">Simulator</button>
          </div>
          <div id="srcPane" class="stack"></div>
          <div class="card"><div class="card-title">Sample chats</div>
            <div class="chips" id="samples">
              <button class="chip" data-k="clean" aria-pressed="false">Clean</button>
              <button class="chip" data-k="ambiguous" aria-pressed="false">Ambiguous</button>
              <button class="chip" data-k="contradictory" aria-pressed="false">Contradictory</button>
            </div></div>
          <p class="privacy">${icon("lock")}This chat stays on this device. Nothing is uploaded.</p>
        </div>
        <div class="stack" id="previewPane"></div>
      </div>`);
    const pane = document.getElementById("srcPane");
    const pv = document.getElementById("previewPane");
    function paintSrc() {
      if (src === "export") {
        pane.innerHTML = `<label class="drop" id="drop" tabindex="0">
            ${icon("import")}<h3>Drop the exported chat here</h3><p>A <b>.txt</b> or <b>.zip</b> file, or click to choose one.</p>
            <input type="file" accept=".txt,.zip,text/plain,application/zip" hidden id="file"></label>
          <div class="card"><div class="card-title">How to export</div><ol class="howto">
            <li><b>Android:</b> open the chat → ⋮ → More → Export chat → choose “Include media” for voice notes.</li>
            <li><b>iPhone:</b> open the chat → tap the name → Export Chat → Attach Media.</li></ol></div>`;
        const drop = document.getElementById("drop"), file = document.getElementById("file");
        drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); file.click(); } });
        ["dragenter", "dragover"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add("over"); }));
        ["dragleave", "drop"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
        drop.addEventListener("drop", (e) => readFile(e.dataTransfer.files[0]));
        file.addEventListener("change", () => readFile(file.files[0]));
      } else if (src === "paste") {
        pane.innerHTML = `<div class="field"><label for="pasteBox">Paste the chat</label>
          <textarea class="textarea" id="pasteBox" rows="9" placeholder="12/10/26, 10:02 am - Raju: 200 shirts, 480 each ok?&#10;or one message per line as  Name: message"></textarea></div>
          <div class="actions"><button class="btn" id="readPaste">Read text</button></div>`;
        document.getElementById("readPaste").addEventListener("click", () => {
          const t = document.getElementById("pasteBox").value;
          fileName = "Pasted text"; sample = null; preview = parseChat(t); preview.raw = t; paintPreview();
        });
      } else {
        pane.innerHTML = `<div class="card"><div class="card-title">Simulator</div><p class="muted" style="margin:0 0 12px">Start an empty chat and type both sides yourself. Useful for a live demo.</p>
          <div class="grid-2"><div class="field"><label for="simA">You</label><input class="input" id="simA" value="You"></div>
          <div class="field"><label for="simB">Other person</label><input class="input" id="simB" value="Other party"></div></div></div>`;
        const upd = () => {
          const a = document.getElementById("simA").value.trim() || "You", b = document.getElementById("simB").value.trim() || "Other party";
          fileName = "Simulator chat"; sample = null; meName = a;
          preview = { messages: [], media: 0, voice: 0, people: [a, b], first: null, last: null, bad: [], formatted: true, simulator: true };
          paintPreview();
        };
        pane.querySelectorAll("input").forEach((i) => i.addEventListener("input", upd));
        upd();
      }
    }
    function readFile(f) {
      if (!f) return;
      fileName = f.name; sample = null;
      if (/\.zip$/i.test(f.name)) {
        preview = { zip: true }; paintPreview(); return;
      }
      if (f.size > 20 * 1024 * 1024) { preview = { error: "This file is larger than 20 MB. Export the chat without media, or split it." }; paintPreview(); return; }
      const rd = new FileReader();
      rd.onload = () => { preview = parseChat(String(rd.result)); preview.raw = String(rd.result); paintPreview(); };
      rd.onerror = () => { preview = { error: "We could not read this file. Choose the exported .txt or .zip." }; paintPreview(); };
      rd.readAsText(f);
    }
    function paintPreview() {
      if (!preview) {
        pv.innerHTML = `<div class="card empty"><div class="big" aria-hidden="true">○</div><h2>Nothing imported yet</h2><p>Choose a chat export, paste the text, or pick a sample. A preview shows here before anything is analysed.</p></div>`;
        return;
      }
      if (preview.error) { pv.innerHTML = `<div class="notice danger" role="alert"><span class="sym">⚠</span><p>${esc(preview.error)}</p></div>`; return; }
      if (preview.zip) {
        pv.innerHTML = `<div class="notice info"><span class="sym">i</span><p><b>${esc(fileName)}</b>: zip exports (chat plus voice notes) are opened by the local VeriDoc service, which also transcribes the voice notes. This build reads .txt files only. Export the chat as .txt, or start the service.</p></div>`;
        return;
      }
      if (!preview.messages.length && !preview.simulator) {
        pv.innerHTML = `<div class="notice danger" role="alert"><span class="sym">⚠</span><p>We could not read this file. Choose the exported .txt or .zip. Each line should look like <span class="mono">12/10/26, 10:02 am - Name: message</span> or <span class="mono">Name: message</span>.</p></div>`;
        return;
      }
      if (!meName || !preview.people.includes(meName)) meName = null;
      if (dealType === null || (dealType === "" && !API.ok)) dealType = API.ok ? "" : "supply_order";
      pv.innerHTML = `
        ${preview.bad.length ? `<div class="notice warn"><span class="sym">!</span><p>Some lines were not understood and were left out, starting with: <span class="mono">${esc(preview.bad[0].slice(0, 80))}</span></p></div>` : ""}
        <div class="card"><div class="card-title">${icon("file")} Preview</div>
          <dl class="kv">
            <dt>File</dt><dd>${esc(fileName)}</dd>
            <dt>Messages</dt><dd>${preview.messages.length} (${preview.media} media omitted${preview.voice ? `, ${preview.voice} voice notes` : ""})</dd>
            <dt>People</dt><dd>${preview.people.map(esc).join(", ") || "—"}</dd>
            <dt>Dates</dt><dd>${preview.first ? `${esc(preview.first)} to ${esc(preview.last)}` : "No dates in the text"}</dd>
            ${preview.first ? `<dt>Date order</dt><dd>Read as day/month/year.</dd>` : ""}
          </dl></div>
        <div class="card"><div class="card-title">Which one is you? <span class="faint">(required)</span></div>
          <div class="radio-list" id="meList">${preview.people.map((p) => `<label class="radio"><input type="radio" name="me" value="${esc(p)}" ${p === meName ? "checked" : ""}>${esc(p)}</label>`).join("")}</div></div>
        <div class="card"><div class="card-title">Deal type</div>
          <div class="radio-list">
            ${API.ok ? `<label class="radio"><input type="radio" name="dt" value="" ${dealType === "" ? "checked" : ""}>Detect automatically</label>` : ""}
            <label class="radio"><input type="radio" name="dt" value="supply_order" ${dealType === "supply_order" ? "checked" : ""}>Supply or order</label>
            <label class="radio"><input type="radio" name="dt" value="freelance" ${dealType === "freelance" ? "checked" : ""}>Freelance job</label>
            <label class="radio disabled"><input type="radio" name="dt" disabled>Rent and others <span class="tag">Later</span></label>
          </div></div>
        ${API.info && !sample ? (API.ok ? `<p class="privacy">${icon("sparkle")}The local model on your pendrive reads this chat. Nothing leaves this computer.</p>` : `<div class="notice warn"><span class="sym">!</span><p>${API.info.state === "starting" ? "The local model is still loading. Wait a moment, then press Analyse." : "The AI helper is unavailable. The chat will open without analysis."}</p></div>`) : ""}
        <div id="analyseErr"></div>
        <div class="actions" style="justify-content:flex-end">
          <a class="btn" href="#/deals">Cancel</a>
          <button class="btn btn-primary" id="analyse" ${meName ? "" : "disabled"}>${icon("sparkle")}Analyse chat</button>
        </div>`;
      pv.querySelectorAll('input[name="me"]').forEach((i) => i.addEventListener("change", () => { meName = i.value; document.getElementById("analyse").disabled = false; }));
      pv.querySelectorAll('input[name="dt"]').forEach((i) => i.addEventListener("change", () => { dealType = i.value; }));
      document.getElementById("analyse").addEventListener("click", analyse);
    }
    async function analyse() {
      if (sample) { toast("Sample deal opened"); go(`#/workspace/${sample}`); return; }
      if (API.ok && preview.raw && !busy) {
        const btn = document.getElementById("analyse");
        busy = true; btn.disabled = true; btn.innerHTML = `<span class="spin" aria-hidden="true"></span>Reading the chat on this device…`;
        try {
          const d = await apiAnalyse({ text: preview.raw, me: meName, deal_type: dealType || undefined });
          d.import_records[0].file_name = fileName;
          const key = liveKey();
          addDeal(key, d);
          const fixed = (d.analysis.repairs || []).length;
          toast(`Analysed in ${d.analysis.seconds}s${fixed ? ` · ${fixed} fixed by rules` : ""}. Check every term.`);
          go(`#/workspace/${key}`);
        } catch (e) {
          busy = false; btn.disabled = false; btn.innerHTML = `${icon("sparkle")}Try again`;
          document.getElementById("analyseErr").innerHTML = `<div class="notice danger" role="alert"><span class="sym">⚠</span><p>${esc(e.message)} Your chat is still here; nothing was saved.</p></div>`;
        }
        return;
      }
      const key = `import-${++S.imported}`;
      const ids = Object.fromEntries(preview.people.map((p, i) => [p, `p-${key}-${i}`]));
      const d = {
        description: "Imported in this browser session only.", playbook: { key: dealType, version: 1 },
        participants: preview.people.map((p) => ({ id: ids[p], display_name: p, role: "party", is_me: p === meName })),
        messages: preview.messages.map((m, i) => ({ id: `m-${key}-${i + 1}`, seq: i + 1, sender_id: ids[m.sender], ts: null, text: m.text, raw_time: [m.date, m.time].filter(Boolean).join(", "), origin: preview.simulator ? "simulator" : "export" })),
        terms: [], score: { total: 0, breakdown: [] }, flags: [], suggestions: [], recaps: [], confirmations: [], versions: [], version_diffs: [],
        receipts: [], voice_notes: [], transcripts: [], handshake_questions: [], sealed_answers: [], handshake_reveals: [], dispute_packs: [],
        import_records: [{ file_name: fileName, message_count: preview.messages.length, imported_at: new Date().toISOString(), export_digest: null }],
        pendingAnalysis: true
      };
      addDeal(key, d);
      toast("Chat imported. Analysis needs the local service.");
      go(`#/workspace/${key}`);
    }
    view.querySelector(".segmented").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      src = b.dataset.s; view.querySelectorAll(".segmented button").forEach((x) => x.setAttribute("aria-selected", x === b));
      preview = null; paintSrc(); paintPreview();
    });
    document.getElementById("samples").addEventListener("click", (e) => {
      const b = e.target.closest(".chip"); if (!b) return;
      document.querySelectorAll("#samples .chip").forEach((c) => c.setAttribute("aria-pressed", c === b));
      const d = S.deals[b.dataset.k]; sample = b.dataset.k;
      fileName = (d.import_records[0] && d.import_records[0].file_name) || `Sample: ${b.textContent}`;
      const dts = d.messages.map((m) => m.ts).filter(Boolean);
      preview = { messages: d.messages, media: 0, voice: d.voice_notes.length, people: d.participants.map((p) => p.display_name), first: dts.length ? time(dts[0]) : null, last: dts.length ? time(dts[dts.length - 1]) : null, bad: [], formatted: true };
      meName = me(d).display_name; dealType = d.playbook.key;
      paintPreview();
    });
    paintSrc(); paintPreview();
  }

  /* ======================= S3 Workspace ======================= */
  function termsByMessage(d) {
    const map = {};
    d.terms.forEach((t) => {
      const srcs = [...t.sources, ...(t.alternatives || []).flatMap((a) => a.sources)];
      srcs.forEach((s) => { if (s.message_id) (map[s.message_id] = map[s.message_id] || []).push([t, s.quote]); });
    });
    return map;
  }
  function highlight(d, m, map) {
    let html = esc(m.text);
    const seen = new Set();
    (map[m.id] || []).forEach(([t, q]) => {
      if (!q || q.length < 2 || seen.has(q) || !m.text.includes(q) || ["buyer", "seller", "client", "freelancer"].includes(t.key)) return;
      seen.add(q);
      const cls = { stated: "clear", unclear: "ambiguous", contradicted: "conflict" }[t.state] || "clear";
      html = html.replace(esc(q), `<span class="hl ${cls}" data-term="${t.key}" title="${esc(label(t.key))}">${esc(q)}<span class="hl-tag">${esc(label(t.key))}</span></span>`);
    });
    return html;
  }
  function renderWorkspace(d) {
    const meP = me(d), oth = other(d);
    const map = termsByMessage(d);
    const vnByMsg = Object.fromEntries(d.voice_notes.map((v) => [v.message_id, v]));
    let lastDay = "";
    const bubbles = d.messages.map((m) => {
      const day = m.ts ? new Date(m.ts).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" }) : "";
      const dayHtml = day && day !== lastDay ? `<div class="day">${day}</div>` : "";
      lastDay = day || lastDay;
      const vn = vnByMsg[m.id];
      let body;
      if (vn) {
        const tr = d.transcripts.find((t) => t.id === vn.transcript_id);
        body = `<div class="voice"><div class="voice-bar"><button class="play" type="button" disabled title="Audio is not in the sample data" aria-label="Play voice note (not available in sample)">${icon("play")}</button><div class="wave" aria-hidden="true"></div><span class="faint">${Math.round(vn.duration_ms / 1000)}s</span></div>
          ${tr ? `<div class="transcript" aria-label="Transcript">${tr.spans.map((s) => `<div class="span"><span class="t">${(s.start_ms / 1000).toFixed(0)}s</span><span>${esc(s.text)} ${s.confidence < 0.7 ? `<span class="conf-low">! low confidence</span>` : ""}</span></div>`).join("")}</div>` : `<span class="faint">Transcribing…</span>`}</div>`;
      } else body = `<span class="txt">${highlight(d, m, map)}</span>`;
      return `${dayHtml}<div class="bubble ${m.sender_id === meP.id ? "out" : "in"} ${m.origin === "simulator" ? "sim" : ""}" id="msg-${d.key}-${m.seq}">
        <span class="n">#${m.seq}</span>${body}<div class="meta">${m.origin === "simulator" ? "<span>simulator</span>" : ""}<span>${m.ts ? clock(m.ts) : esc(m.raw_time || "")}</span></div></div>`;
    }).join("");

    h(`<div class="workspace">
      <section class="chat-panel" aria-label="Chat">
        <div class="chat-head"><div class="avatar" aria-hidden="true">${esc(oth.display_name.slice(0, 1))}</div>
          <div class="who"><b>${esc(oth.display_name)}</b><span>${d.messages.length} messages · ${d.playbook.key === "supply_order" ? "Supply or order" : "Freelance job"}</span></div>
          <a class="btn btn-sm" href="#/recap/${d.key}">${icon("recap")}Recap</a></div>
        <div class="chat-body" id="chatBody">${bubbles || `<div class="empty"><p>No messages yet. Add one below.</p></div>`}</div>
        <form class="chat-input" id="simForm" autocomplete="off">
          <label class="sr-only" for="simWho">Sender</label>
          <select class="select who-sel" id="simWho">${d.participants.map((p) => `<option value="${p.id}">${esc(p.display_name)}</option>`).join("")}</select>
          <label class="sr-only" for="simText">Add a simulator message</label>
          <input class="input" id="simText" placeholder="Add a simulator message">
          <button class="btn btn-primary btn-sm icon-btn" aria-label="Add message">${icon("send")}</button>
        </form>
      </section>
      <div class="side-col" id="sideCol"></div>
    </div>`);
    document.getElementById("simForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const t = document.getElementById("simText").value.trim();
      if (!t) return;
      d.messages.push({ id: `sim-${d.key}-${d.messages.length + 1}`, seq: d.messages.length + 1, sender_id: document.getElementById("simWho").value, ts: new Date().toISOString(), text: t, origin: "simulator" });
      d.audit.push({ ts: new Date().toISOString(), what: `Simulator message #${d.messages.length} added` });
      if (API.ok) {
        toast("Message added. Analysing again…");
        reanalyse(d).then(() => { toast("Analysis updated. Confirmed terms were kept."); render(); scrollChat(); })
          .catch((err) => toast(err.message));
      } else toast("Message added. Analysis needs the local model (start VeriDoc from the pendrive).");
      render(); scrollChat();
    });
    document.getElementById("chatBody").addEventListener("click", (e) => {
      const hl = e.target.closest(".hl"); if (hl) go(`#/workspace/${d.key}/term/${hl.dataset.term}`);
    });
    paintSide(d);
  }
  function scrollChat() { const b = document.getElementById("chatBody"); if (b) b.scrollTop = b.scrollHeight; }
  function jumpTo(d, n) {
    const el = document.getElementById(`msg-${d.key}-${n}`);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 1400);
  }
  function srcLabel(d, s) {
    if (s.kind === "voice") { const v = d.voice_notes.find((x) => x.id === s.voice_note_id); const m = v && msg(d, v.message_id); return m ? `#${m.seq} 🎤 ${(s.start_ms / 1000).toFixed(0)}s` : "voice"; }
    return s.message_id ? `#${seq(d, s.message_id)}` : "";
  }
  function paintSide(d) {
    const col = document.getElementById("sideCol");
    const sc = liveScore(d);
    const req = sc.breakdown;
    const present = req.filter((b) => b.present).length, clear = req.filter((b) => b.clear).length, ack = req.filter((b) => b.acknowledged).length;
    const order = (d.weights && Object.keys(d.weights).length) ? Object.keys(d.weights) : d.terms.map((t) => t.key);
    const flags = d.flags.filter((f) => !f.resolved_at);
    const sug = d.suggestions.find((s) => s.tone === S.tone);
    const anyAi = d.terms.some((t) => t.origin === "ai");
    col.innerHTML = `
      ${S.noticeL5 ? `<div class="notice info" role="note"><span class="sym">i</span><p>${STR.limits.find((l) => l[0] === "L5")[1]}</p><button class="btn btn-ghost btn-sm icon-btn" id="dismissL5" aria-label="Dismiss">${icon("close")}</button></div>` : ""}
      ${d.pendingAnalysis ? `<div class="notice warn" role="status"><span class="sym">!</span><p>${API.ok ? "This chat has not been analysed yet." : "The chat is imported. Analysis needs the local model: start VeriDoc from the pendrive, then press Analyse."}</p>${API.ok ? `<button class="btn btn-primary btn-sm" data-reanalyse>${icon("sparkle")}Analyse</button>` : ""}</div>` : ""}
      ${d.analysis ? `<div class="notice" role="status"><span class="sym">${icon("sparkle", "ic")}</span><p>Read on this device by <b>${esc(d.analysis.model)}</b> in ${d.analysis.seconds}s${(d.analysis.repairs || []).length ? ` · ${d.analysis.repairs.length} fixed by rules` : ""}${d.analysis.deal_hint && d.analysis.deal_hint[2] ? ` · deal type ${d.analysis.deal_hint[3] === "classifier" ? "detected" : "chosen"}` : ""}. Nothing is added to the record until you confirm it.</p>${API.ok ? `<button class="btn btn-sm" data-reanalyse>Analyse again</button>` : ""}</div>` : ""}
      ${S.safeMode || d.analysis ? "" : anyAi ? `<div class="notice ok"><span class="sym">✓</span><p>Rules result shown first; the AI helper's additions are marked and checked against the quoted message.</p></div>` : ""}
      <section class="card" aria-labelledby="esTitle">
        <div class="card-title" id="esTitle">Evidence strength <span class="spacer"></span><button class="btn btn-ghost btn-sm" id="whyBtn" aria-expanded="false">Why?</button></div>
        <div class="score-big"><b>${sc.total}</b><span>/ 100</span></div>
        <div class="meter" style="margin-top:10px"><span style="width:${sc.total}%"></span></div>
        <div class="score-counts"><span>Present <b>${present} of ${req.length}</b></span><span>Clear <b>${clear} of ${req.length}</b></span><span>Acknowledged by both <b>${ack} of ${req.length}</b></span></div>
        <div class="why" id="why" hidden><table class="table"><thead><tr><th>Term</th><th>Weight</th><th>Present</th><th>Clear</th><th>Both</th><th>Points</th></tr></thead><tbody>
          ${req.map((b) => `<tr><td>${esc(label(b.term_key))}</td><td>${b.weight}</td><td>${b.present ? "✓" : "○"}</td><td>${b.clear ? "✓" : "○"}</td><td>${b.acknowledged ? "✓" : "○"}</td><td>${b.points}</td></tr>`).join("")}
        </tbody></table><p class="faint" style="font-size:12.5px;margin:8px 0 0">Points = weight × (0.4 present + 0.3 clear + 0.3 acknowledged). Only terms you confirmed count.</p></div>
      </section>
      <section class="card" aria-labelledby="tfTitle">
        <div class="card-title" id="tfTitle">Terms found</div>
        ${!d.terms.length ? `<div class="empty" style="padding:20px"><p>No terms found yet. Keep chatting or import more messages.</p></div>` :
        `<ul class="term-list">${order.map((k) => term(d, k)).filter(Boolean).map((t) => {
          const st = t.state;
          const shown = st === "stated" ? esc(value(t.value)) : st === "missing" ? '<span class="faint">Not in the chat yet</span>'
            : st === "contradicted" ? (t.alternatives || []).map((a) => esc(value(a.value))).join(" <span class='faint'>vs</span> ")
            : `<span class="quote">“${esc((t.sources[0] || {}).quote || "")}”</span>`;
          const src = t.sources[0] ? srcLabel(d, t.sources[0]) : "";
          return `<li><button class="term ${st}" data-k="${t.key}" type="button">
            <span class="k">${esc(label(t.key))}${!t.confirmed_at && st !== "missing" ? '<span class="unconf">Found, not confirmed</span>' : ""}${t.needs_review ? '<span class="review">! Needs review</span>' : ""}${t.origin === "ai" ? '<span class="tag">AI</span>' : ""}</span>
            <span class="right">${statusPill(st)}${src ? `<span class="src" data-src="${src.replace(/\D.*$/, "").replace("#", "")}">${esc(src)}</span>` : ""}</span>
            <span class="v ${st === "unclear" ? "quote" : ""}">${shown}</span></button></li>`;
        }).join("")}</ul>`}
      </section>
      <section class="card" aria-labelledby="flTitle">
        <div class="card-title" id="flTitle">${icon("flag", "ic")} Flags <span class="spacer"></span><span class="faint">${flags.length}</span></div>
        ${flags.length ? `<ul class="flag-list">${flags.map((f) => {
          const kind = { contradiction: "conflict", ambiguous: "ambiguous", missing: "missing", needs_review: "ambiguous" }[f.kind] || "neutral";
          const word = { contradiction: "Conflict", ambiguous: "Ambiguous", missing: "Missing", needs_review: "Needs review" }[f.kind] || f.kind;
          const reason = STR.reasons[f.reason_code] ? STR.reasons[f.reason_code](f.reason_params || {}) : f.reason_code;
          return `<li><span class="status ${kind}">${word}</span><span>${f.term_key ? `<b>${esc(label(f.term_key))}.</b> ` : ""}${esc(reason)}</span></li>`;
        }).join("")}</ul>` : `<p class="muted" style="margin:0">✓ No open flags.</p>`}
      </section>
      <section class="card" aria-labelledby="sgTitle">
        <div class="card-title" id="sgTitle">${icon("sparkle", "ic")} Suggested next message</div>
        <div class="segmented" id="tone" aria-label="Tone">${["casual", "polite", "firm"].map((t) => `<button data-t="${t}" aria-pressed="${S.tone === t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join("")}</div>
        ${sug ? `<div class="suggest-text" id="sugText">${esc(sug.text)}</div>
          <p class="closes">Closes: ${sug.target_term_keys.map(label).join(", ")}${sug.origin === "template" ? " · drafted from a template" : ""}</p>
          <div class="actions"><button class="btn" id="editSug">Edit</button><button class="btn btn-primary" id="useSug">${icon("copy")}Use this</button></div>
          <p class="faint" style="font-size:12.5px;margin:10px 0 0">Use this copies the text. You send it yourself in WhatsApp; VeriDoc never sends.</p>`
        : `<p class="muted" style="margin:12px 0 0">${d.pendingAnalysis || !d.terms.length ? "A draft appears here after the chat is analysed." : d.suggestions.length ? `No ${S.tone} draft in the sample data. Try another tone.` : flags.length ? "Drafts come from the local AI helper, which is not connected in this build." : "✓ Nothing left to ask. Send the recap."}</p>`}
      </section>`;
    col.querySelectorAll("[data-reanalyse]").forEach((b) => b.addEventListener("click", async () => {
      b.disabled = true; b.innerHTML = `<span class="spin" aria-hidden="true"></span>Reading…`;
      try { await reanalyse(d); toast("Analysis updated. Confirmed terms were kept."); render(); }
      catch (e) { toast(e.message); b.disabled = false; b.textContent = "Try again"; }
    }));
    const dis = document.getElementById("dismissL5");
    if (dis) dis.addEventListener("click", () => { S.noticeL5 = false; paintSide(d); });
    document.getElementById("whyBtn").addEventListener("click", (e) => {
      const w = document.getElementById("why"); w.hidden = !w.hidden; e.currentTarget.setAttribute("aria-expanded", !w.hidden);
    });
    col.querySelectorAll(".term").forEach((b) => b.addEventListener("click", (e) => {
      const s = e.target.closest(".src");
      if (s && s.dataset.src) { e.stopPropagation(); jumpTo(d, s.dataset.src); return; }
      go(`#/workspace/${d.key}/term/${b.dataset.k}`);
    }));
    document.getElementById("tone").addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; S.tone = b.dataset.t; paintSide(d); });
    const edit = document.getElementById("editSug");
    if (edit) {
      edit.addEventListener("click", () => {
        const t = document.getElementById("sugText"); const on = t.getAttribute("contenteditable") === "true";
        t.setAttribute("contenteditable", on ? "false" : "true"); edit.textContent = on ? "Edit" : "Done"; if (!on) t.focus();
      });
      document.getElementById("useSug").addEventListener("click", () => {
        copy(document.getElementById("sugText").innerText, "Copied. Paste it into WhatsApp.");
        sug.copied_at = new Date().toISOString();
      });
    }
  }

  /* ======================= S4 Term detail (sheet) ======================= */
  const sheet = document.getElementById("sheet"), backdrop = document.getElementById("sheetBackdrop");
  let lastFocus = null;
  function closeSheet(silent) {
    if (sheet.hidden) return;
    sheet.hidden = true; backdrop.hidden = true; sheet.innerHTML = "";
    if (!silent) { const r = parse(); if (r.sub === "term") history.replaceState(null, "", `#/workspace/${r.deal}`); }
    if (lastFocus) lastFocus.focus();
  }
  backdrop.addEventListener("click", () => closeSheet());
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !sheet.hidden) closeSheet();
    if (e.key === "Tab" && !sheet.hidden) { // keep focus inside the sheet
      const f = [...sheet.querySelectorAll("button, input, select, textarea, a[href]")].filter((x) => !x.disabled);
      if (!f.length) return;
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
  });
  function sourceView(d, s) {
    if (!s) return `<div class="source-view"><span class="ctx">No source: this term is not in the chat yet.</span></div>`;
    if (s.kind === "voice") {
      const v = d.voice_notes.find((x) => x.id === s.voice_note_id);
      const tr = v && d.transcripts.find((t) => t.id === v.transcript_id);
      const span = tr && tr.spans.find((x) => x.start_ms === s.start_ms) || {};
      return `<div class="source-view"><span class="ctx">Voice note in message #${v ? seq(d, v.message_id) : "?"} · ${(s.start_ms / 1000).toFixed(0)}s to ${(s.end_ms / 1000).toFixed(0)}s</span>
        <div class="ctx focus">🎤 ${esc(span.text || s.quote || "")}</div>
        <div class="actions"><span class="${span.confidence < 0.7 ? "conf-low" : "faint"}">Transcript confidence: ${span.confidence != null ? Math.round(span.confidence * 100) + "%" : "unknown"}${span.confidence < 0.7 ? " (low)" : ""}</span>
        <button class="btn btn-sm" disabled title="Audio is not in the sample data">${icon("play")}Play the moment</button></div></div>`;
    }
    const m = msg(d, s.message_id); if (!m) return "";
    const i = d.messages.indexOf(m);
    const line = (x, main) => {
      let t = esc(x.text);
      if (main && s.quote && x.text.includes(s.quote)) t = t.replace(esc(s.quote), `<mark>${esc(s.quote)}</mark>`);
      return `<div class="ctx ${main ? "focus" : ""}"><b>#${x.seq} ${esc(nameOf(d, x.sender_id))}:</b> ${t}</div>`;
    };
    return `<div class="source-view">${i > 0 ? line(d.messages[i - 1]) : ""}${line(m, true)}${d.messages[i + 1] ? line(d.messages[i + 1]) : ""}</div>`;
  }
  function inputFor(t, v) {
    const kind = (v && v.kind) || ({ unit_price: "money", total_amount: "money", advance_amount: "money", fee: "money", delivery_date: "date", deadline: "date", quantity: "quantity", revisions: "integer" }[t.key]) || "text";
    if (kind === "money") return `<div class="field"><label for="tv">Amount in rupees</label><input class="input" id="tv" inputmode="decimal" data-kind="money" value="${v && v.paise ? Number(v.paise) / 100 : ""}" placeholder="e.g. 48000"></div>`;
    if (kind === "date" || kind === "partial_date") return `<div class="field"><label for="tv">Exact date</label><input class="input" id="tv" type="date" data-kind="date" value="${v && v.date ? v.date : ""}"></div>`;
    if (kind === "quantity") return `<div class="grid-2"><div class="field"><label for="tv">Quantity</label><input class="input" id="tv" inputmode="numeric" data-kind="quantity" value="${v ? v.amount : ""}"></div><div class="field"><label for="tu">Unit</label><input class="input" id="tu" value="${v ? esc(v.unit || "") : ""}"></div></div>`;
    if (kind === "event") return `<div class="field"><label for="tv">When</label><select class="select" id="tv" data-kind="event">${Object.entries(STR.events).map(([k, l]) => `<option value="${k}" ${v && v.event === k ? "selected" : ""}>${l}</option>`).join("")}</select></div>`;
    if (kind === "integer") return `<div class="field"><label for="tv">Number</label><input class="input" id="tv" inputmode="numeric" data-kind="integer" value="${v ? (v.value ?? "") : ""}"></div>`;
    return `<div class="field"><label for="tv">Value</label><input class="input" id="tv" data-kind="text" value="${v && v.text ? esc(v.text) : ""}"></div>`;
  }
  function readInput() {
    const el = document.getElementById("tv"); const k = el.dataset.kind; const raw = el.value.trim();
    if (!raw) return { err: "Enter a value, or reject the term." };
    if (k === "money") { const n = Number(raw.replace(/[₹,\s]/g, "")); if (!(n > 0)) return { err: "Enter an amount in rupees, like 48000." }; return { v: { kind: "money", paise: String(Math.round(n * 100)) } }; }
    if (k === "date") return { v: { kind: "date", date: raw } };
    if (k === "quantity") { if (!/^\d+$/.test(raw)) return { err: "Enter a whole number." }; return { v: { kind: "quantity", amount: raw, unit: (document.getElementById("tu").value || "").trim() || null } }; }
    if (k === "integer") { if (!/^\d+$/.test(raw)) return { err: "Enter a whole number." }; return { v: { kind: "integer", value: Number(raw) } }; }
    if (k === "event") return { v: { kind: "event", event: raw } };
    return { v: { kind: "text", text: raw } };
  }
  function openTerm(d, key) {
    const t = term(d, key); if (!t) return;
    lastFocus = document.activeElement;
    const flag = d.flags.find((f) => f.term_key === key && f.kind !== "needs_review" && !f.resolved_at);
    const reason = flag && STR.reasons[flag.reason_code] ? STR.reasons[flag.reason_code](flag.reason_params || {}) :
      t.state === "stated" ? "Stated clearly in the chat." : t.state === "missing" ? "Not in the chat yet." : "";
    const review = d.flags.find((f) => f.term_key === key && f.kind === "needs_review");
    const alts = t.alternatives || [];
    sheet.innerHTML = `
      <button class="btn btn-ghost btn-sm icon-btn close" id="sheetClose" aria-label="Close">${icon("close")}</button>
      <div class="stack">
        <h2 id="sheetTitle">${esc(label(key))} ${statusPill(t.state)}</h2>
        ${review ? `<div class="notice warn"><span class="sym">!</span><p><b>Needs review.</b> ${esc(STR.reasons[review.reason_code] ? STR.reasons[review.reason_code]() : "Rules and the AI helper disagree.")}</p></div>` : ""}
        <div><div class="label" style="margin-bottom:6px">Source</div>${t.state === "contradicted" ? alts.map((a) => sourceView(d, a.sources[0])).join("") : sourceView(d, t.sources[0])}</div>
        <dl class="kv"><dt>Value</dt><dd>${t.state === "stated" ? esc(value(t.value)) : t.state === "contradicted" ? "Two different values" : "—"}</dd>
          <dt>Why</dt><dd>${esc(reason)}</dd>
          <dt>Found by</dt><dd>${t.repaired_by_rules ? `AI helper, corrected by rules (${esc(t.repaired_by_rules.replace(/_/g, " "))})` : t.origin === "ai" ? "AI helper, checked by rules" : "Rules"}${t.confidence ? ` · ${esc(t.confidence)} confidence` : ""}</dd>
          ${t.review_flags && t.review_flags.length && t.needs_review ? `<dt>Rules check</dt><dd>${esc(t.review_flags.join(", ").replace(/_/g, " "))}</dd>` : ""}
          ${t.suggested_date ? `<dt>Suggested date</dt><dd>${esc(date(t.suggested_date))} <button class="btn btn-sm" type="button" id="useSuggested">Use</button><br><span class="faint" style="font-size:12.5px">Worked out from the message time. Check it.</span></dd>` : ""}
          ${t.confirmed_at ? `<dt>Confirmed</dt><dd>${esc(time(t.confirmed_at))} by ${esc(nameOf(d, t.confirmed_by))}</dd>` : ""}</dl>
        ${alts.length ? `<div><div class="label" style="margin-bottom:6px">Choose the right value</div><div class="alt-list">${alts.map((a, i) => `<label class="radio"><input type="radio" name="alt" value="${i}">${esc(value(a.value))} <span class="faint">from ${esc(srcLabel(d, a.sources[0]))}${a.origin === "ai" ? " (AI)" : ""}</span></label>`).join("")}</div></div>` : ""}
        <div id="valField">${inputFor(t, t.state === "stated" ? t.value : null)}</div>
        <div class="err" id="valErr" hidden></div>
        <div class="notice"><span class="sym">i</span><p>Every extracted term needs a person to confirm it. Nothing is added to the record automatically. This change is logged.</p></div>
        <div class="actions" style="justify-content:flex-end">
          <button class="btn btn-danger" id="rejectT">Reject term</button>
          <button class="btn btn-primary" id="confirmT">Confirm value</button>
        </div>
      </div>`;
    sheet.hidden = false; backdrop.hidden = false;
    document.getElementById("sheetClose").addEventListener("click", () => closeSheet());
    sheet.querySelectorAll('input[name="alt"]').forEach((r) => r.addEventListener("change", () => {
      const a = alts[+r.value];
      const v = a.value.kind === "partial_date" ? { kind: "date", date: "" } : a.value;
      document.getElementById("valField").innerHTML = inputFor(t, v);
      if (a.value.kind === "partial_date") { // year not stated in the chat: the person must pick the exact date
        const [mm, dd] = a.value.month_day.slice(2).split("-");
        const yr = new Date().getFullYear();
        document.getElementById("tv").value = `${yr}-${mm}-${dd}`;
        document.getElementById("valErr").hidden = false;
        document.getElementById("valErr").textContent = "The chat does not say the year. Check the year before confirming.";
      }
    }));
    if (t.value && t.value.kind === "partial_date") { // the chat gives day and month only
      const [mm, dd] = t.value.month_day.slice(2).split("-");
      const tv = document.getElementById("tv"); if (tv) tv.value = `${new Date().getFullYear()}-${mm}-${dd}`;
      const er = document.getElementById("valErr"); er.hidden = false; er.textContent = "The chat does not say the year. Check the year before confirming.";
    }
    const us = document.getElementById("useSuggested");
    if (us) us.addEventListener("click", () => { const tv = document.getElementById("tv"); if (tv) { tv.value = t.suggested_date; tv.focus(); } });
    setTimeout(() => (document.getElementById("tv") || document.getElementById("sheetClose")).focus(), 50);
    document.getElementById("confirmT").addEventListener("click", () => {
      const r = readInput(); const e = document.getElementById("valErr");
      if (r.err) { e.hidden = false; e.textContent = r.err; return; }
      const before = t.state === "stated" ? value(t.value) : t.state;
      Object.assign(t, { value: r.v, state: "stated", unclear_reason: null, needs_review: false, confirmed_at: new Date().toISOString(), confirmed_by: me(d).id });
      d.flags.forEach((f) => { if (f.term_key === key && !f.resolved_at) f.resolved_at = t.confirmed_at; });
      d.audit.push({ ts: t.confirmed_at, what: `${label(key)} confirmed: ${before} → ${value(r.v)}` });
      closeSheet(); toast(`${label(key)} confirmed. This change is logged.`);
      render();
    });
    document.getElementById("rejectT").addEventListener("click", () => {
      Object.assign(t, { value: null, state: "missing", sources: [], alternatives: [], confirmed_at: null, needs_review: false });
      d.audit.push({ ts: new Date().toISOString(), what: `${label(key)} rejected` });
      closeSheet(); toast(`${label(key)} rejected. This change is logged.`);
      render();
    });
  }

  /* ======================= S5 Blind Handshake ======================= */
  async function sha256(text) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function renderHandshake(d) {
    const qs = d.handshake_questions.length ? d.handshake_questions : (S.deals.ambiguous.handshake_questions || []).filter(() => d.playbook.key === "supply_order");
    const reveal = d.handshake_reveals[0];
    const mySeal = d.sealed_answers.find((a) => a.party_id === me(d).id) || S.sealed[d.key];
    const theirSeal = d.sealed_answers.find((a) => a.party_id !== me(d).id);
    const step = reveal ? 3 : mySeal ? 2 : 1;
    const mode = (theirSeal && theirSeal.mode) || "reply";
    h(`<div class="page-head"><div class="grow"><h1>Blind Handshake</h1><p>Each side answers the same key questions privately. Answers are sealed, then shown side by side.</p></div>
        <div class="actions"><a class="btn" href="#/recap/${d.key}">Skip</a></div></div>
      <ol class="stepper" aria-label="Progress">${["Ask", "Sealed", "Reveal"].map((s, i) => `<li class="${i + 1 < step ? "done" : i + 1 === step ? "now" : ""}" ${i + 1 === step ? 'aria-current="step"' : ""}>${s}</li>`).join("")}</ol>
      <div class="notice info" style="margin-bottom:14px"><span class="sym">i</span><p><b>${mode === "handover" ? "Handover mode" : "Reply mode"}.</b> ${mode === "handover" ? "Neither side could see the other's answers before sealing." : "You saw the other side's reply in WhatsApp before pasting it. Your own answers were sealed first."}</p></div>
      <div id="hsBody"></div>`);
    const body = document.getElementById("hsBody");
    if (!qs.length) { body.innerHTML = `<div class="card empty"><h2>No questions for this deal type yet</h2><p>Questions come from the deal's playbook.</p></div>`; return; }
    const sealRow = (a) => `<div class="seal">${icon("lock")}<span><b>${esc(nameOf(d, a.party_id) || "You")}</b> · Sealed ${esc(time(a.sealed_at))}</span><span class="mono" title="${a.seal_hash}">${short(a.seal_hash, 10)}</span></div>`;
    if (reveal) {
      const word = (r) => r.result === "match" ? `<span class="status clear">Match</span>` :
        `<span class="status conflict">${r.difference_code === "days_apart" ? `${r.difference_params.days} days apart` : "Different terms"}</span>`;
      body.innerHTML = `<div class="stack">
        <div class="grid-2">${d.sealed_answers.map(sealRow).join("")}</div>
        <section class="card"><div class="card-title">Reveal · ${esc(time(reveal.revealed_at))}</div>
          <table class="table"><thead><tr><th>Question</th><th>${esc(nameOf(d, d.sealed_answers[0].party_id))}</th><th>${esc(nameOf(d, d.sealed_answers[1].party_id))}</th><th>Result</th></tr></thead><tbody>
          ${reveal.rows.map((r) => `<tr class="${r.result === "match" ? "" : "emph"}"><td>${esc((qs.find((q) => q.term_key === r.term_key) || {}).prompt || label(r.term_key))}</td><td>${esc(r.first.raw)}</td><td>${esc(r.second.raw)}</td><td>${word(r)}</td></tr>`).join("")}
          </tbody></table></section>
        <div class="actions" style="justify-content:flex-end"><a class="btn" href="#/recap/${d.key}">Go to recap</a><a class="btn btn-primary" href="#/workspace/${d.key}">Resolve mismatches</a></div></div>`;
      return;
    }
    if (mySeal) {
      body.innerHTML = `<div class="stack">${sealRow(mySeal)}
        <section class="card"><div class="card-title">Step 2 · Ask ${esc(other(d).display_name)}</div>
          <p class="muted" style="margin-top:0">Copy the questions into WhatsApp, then paste the reply here.</p>
          <div class="actions"><button class="btn" id="copyQs">${icon("copy")}Copy WhatsApp questions</button></div>
          <div class="field" style="margin-top:12px"><label for="theirReply">Their reply</label><textarea class="textarea" id="theirReply" placeholder="Paste ${esc(other(d).display_name)}'s reply"></textarea></div>
          <div class="actions" style="justify-content:flex-end;margin-top:10px"><button class="btn btn-primary" id="revealBtn">Seal and reveal</button></div>
        </section></div>`;
      document.getElementById("copyQs").addEventListener("click", () => copy(`Hi ${other(d).display_name}, quick check so we both agree:\n` + qs.map((q, i) => `${i + 1}. ${q.prompt}`).join("\n"), "Questions copied"));
      document.getElementById("revealBtn").addEventListener("click", () => {
        if (!document.getElementById("theirReply").value.trim()) { toast("Paste their reply first."); return; }
        needsApi("Reading their answers and comparing them");
      });
      return;
    }
    body.innerHTML = `<form class="card stack" id="hsForm"><div class="card-title">Step 1 · Your answers (${esc(me(d).display_name)})</div>
      ${qs.map((q, i) => `<div class="field"><label for="hq${i}">${esc(q.prompt)}</label><input class="input" id="hq${i}" required></div>`).join("")}
      <div class="field"><label for="theirReply0">${esc(other(d).display_name)}'s reply</label><textarea class="textarea" id="theirReply0" disabled placeholder="Seal your answers first."></textarea></div>
      <div class="actions" style="justify-content:flex-end"><button class="btn btn-primary">${icon("lock")}Seal my answers</button></div>
      <p class="faint" style="font-size:12.5px;margin:0">Preview seal: computed in this browser to show the flow. The real seal comes from the integrity engine.</p></form>`;
    document.getElementById("hsForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const answers = qs.map((q, i) => ({ term_key: q.term_key, raw: document.getElementById(`hq${i}`).value.trim() }));
      S.sealed[d.key] = { party_id: me(d).id, order: 1, mode: "reply", sealed_at: new Date().toISOString(), seal_hash: await sha256(JSON.stringify(answers) + crypto.getRandomValues(new Uint32Array(4)).join("")) };
      d.audit.push({ ts: S.sealed[d.key].sealed_at, what: "Handshake answers sealed" });
      toast("Sealed. Your answers are hidden now.");
      render();
    });
  }

  /* ======================= S6 Recap and confirm + S12 ======================= */
  function draftLines(d) {
    return d.terms.filter((t) => t.confirmed_at && t.state === "stated" && !["buyer", "seller", "client", "freelancer"].includes(t.key))
      .map((t) => ({ term_key: t.key, text: `${label(t.key)}: ${value(t.value)}`, sources: t.sources }));
  }
  function renderRecap(d) {
    const rc = d.recaps.find((r) => r.language === S.lang) || (S.lang === "en" ? null : undefined);
    const anyRecap = d.recaps[0];
    const lines = rc ? rc.lines : draftLines(d);
    const excluded = d.terms.filter((t) => !t.confirmed_at && t.state !== "missing");
    const code = anyRecap && anyRecap.echo_code ? anyRecap.echo_code.code : null;
    const oth = other(d), meP = me(d);
    const vn = anyRecap ? anyRecap.version_n : null;
    const confs = d.confirmations.filter((c) => c.version_n === vn);
    const confOf = (p) => confs.find((c) => c.party_id === p.id);
    const msgText = rc ? rc.text : [`Hi ${oth.display_name}, just confirming what we discussed:`, ...lines.map((l) => l.text), "If all correct, reply: CONFIRM ····"].join("\n");
    const cState = (c) => !c ? `<span class="status pending">Waiting</span>` : c.state === "confirmed" ? `<span class="status clear">Confirmed ${esc(clock(c.reply_ts || c.checked_at))}</span>` : `<span class="status conflict">Not confirmed</span>`;
    h(`<div class="page-head"><div class="grow"><h1>Recap and confirm</h1><p>A short recap built from confirmed terms. ${esc(oth.display_name)} confirms by replying with the code.</p></div>
        <div class="actions"><a class="btn" href="#/versions/${d.key}">${icon("versions")}Versions</a></div></div>
      <div class="recap-layout">
        <div class="stack">
          <div class="notice warn"><span class="sym">!</span><p>Drafting aid, not legal advice. Please read each line before confirming.</p></div>
          <section class="card">
            <div class="card-title">Recap ${vn ? `· version ${vn}` : "· draft"}<span class="spacer"></span>
              <div class="segmented" id="langTabs"><button data-l="en" aria-pressed="${S.lang === "en"}">English</button><button data-l="hi" aria-pressed="${S.lang === "hi"}">हिन्दी</button><button disabled title="Kannada comes after native review">ಕನ್ನಡ <span class="tag">P1</span></button></div></div>
            ${S.lang === "hi" && !rc ? `<p class="muted">No Hindi recap in the sample data. The Hindi recap comes from the Hindi template.</p>` :
            lines.length ? `<ul class="recap-lines">${lines.map((l) => `<li><span>${esc(l.text)}</span>${l.sources && l.sources[0] && l.sources[0].message_id ? `<a class="src" href="#/workspace/${d.key}" data-seq="${seq(d, l.sources[0].message_id)}">#${seq(d, l.sources[0].message_id)}</a>` : ""}</li>`).join("")}</ul>`
            : `<p class="muted">No confirmed terms yet. Confirm terms in the workspace to build the recap.</p>`}
            ${!rc && excluded.length ? `<div class="notice" style="margin-top:12px"><span class="sym">○</span><p>Left out until you confirm them: ${excluded.map((t) => esc(label(t.key))).join(", ")}.</p></div>` : ""}
          </section>
          <section class="card"><div class="card-title">Echo code</div>
            <div class="echo"><div class="echo-code" aria-label="Echo code ${code ? code.split("").join(" ") : "not created yet"}">${code || "····"}</div>
              <p class="muted" style="margin:0;flex:1;min-width:220px">${code ? `${esc(oth.display_name)} replies <span class="mono">CONFIRM ${code}</span> in WhatsApp. The code comes from the recap's fingerprint, so it only matches this exact text.` : "The code is created when the recap is saved. It comes from the recap's fingerprint, so it only matches that exact text."}</p></div>
            <p class="faint" style="font-size:12.5px;margin:10px 0 0">${STR.limits.find((l) => l[0] === "L7")[1]}</p>
            <div class="actions" style="margin-top:12px"><button class="btn ${code ? "btn-primary" : ""}" id="copyRecap" ${lines.length ? "" : "disabled"}>${icon("copy")}Copy WhatsApp message</button>
              ${code ? "" : `<button class="btn btn-primary" id="saveRecap" ${lines.length ? "" : "disabled"}>Save recap and create code</button>`}</div>
          </section>
          <section class="card"><div class="card-title">Confirmations</div>
            <div class="confirm-row"><b>You</b>${cState(confOf(meP))}</div>
            <div class="confirm-row"><b>${esc(oth.display_name)}</b>${cState(confOf(oth))}</div>
            <div class="hr"></div>
            <div class="field" style="margin-top:10px"><label for="replyBox">Paste ${esc(oth.display_name)}'s reply</label><textarea class="textarea" id="replyBox" placeholder="CONFIRM ${code || "XXXX"}"></textarea></div>
            <div id="replyResult" style="margin-top:10px"></div>
            <div class="actions" style="justify-content:flex-end;margin-top:10px"><button class="btn" id="checkReply" ${code ? "" : "disabled"}>Check reply</button></div>
          </section>
        </div>
        <aside aria-label="What ${esc(oth.display_name)} sees in WhatsApp">
          <div class="phone"><div class="phone-screen">
            <div class="phone-top"><div class="avatar" aria-hidden="true">${esc(oth.display_name.slice(0, 1))}</div>${esc(oth.display_name)}</div>
            <div class="phone-body"><div class="wa out">${esc(msgText)}<small>${anyRecap ? esc(clock(anyRecap.created_at)) : "now"} ✓✓</small></div>
              ${confOf(oth) && confOf(oth).reply_text ? `<div class="wa in">${esc(confOf(oth).reply_text)}<small>${esc(clock(confOf(oth).reply_ts))}</small></div>` : ""}</div>
          </div></div>
          <p class="phone-caption">What ${esc(oth.display_name)} sees. No app, link or account needed.</p>
        </aside>
      </div>`);
    document.getElementById("langTabs").addEventListener("click", (e) => { const b = e.target.closest("button[data-l]"); if (!b) return; S.lang = b.dataset.l; render(); });
    document.getElementById("copyRecap").addEventListener("click", () => copy(msgText, "Recap copied. Paste it into WhatsApp."));
    const save = document.getElementById("saveRecap"); if (save) save.addEventListener("click", () => needsApi("Saving the recap and creating its code"));
    view.querySelectorAll(".recap-lines .src").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); go(`#/workspace/${d.key}`); setTimeout(() => jumpTo(d, a.dataset.seq), 120); }));
    document.getElementById("checkReply").addEventListener("click", () => {
      const txt = document.getElementById("replyBox").value; const out = document.getElementById("replyResult");
      const m = txt.match(/CONFIRM\s+([A-Z0-9]{4})/i);
      if (!m) { out.innerHTML = `<div class="notice danger" role="alert"><span class="sym">⚠</span><p>We could not find a CONFIRM code in this reply.</p></div>`; return; }
      if (m[1].toUpperCase() === code) out.innerHTML = `<div class="notice ok" role="status"><span class="sym">✓</span><p>The code matches this recap (version ${vn}).</p></div>`;
      else out.innerHTML = `<div class="notice danger" role="alert"><span class="sym">⚠</span><p>Not confirmed: the code does not match this recap.</p></div>`;
    });
  }

  /* ======================= S7 Versions ======================= */
  function renderVersions(d) {
    const vs = [...d.versions].sort((a, b) => b.version_n - a.version_n);
    const diff = d.version_diffs[d.version_diffs.length - 1];
    const changeWord = { no_change: ["neutral", "No change"], changed: ["ambiguous", "Changed"], added: ["clear", "Added"], removed: ["conflict", "Removed"] };
    h(`<div class="page-head"><div class="grow"><h1>Versions and changes</h1><p>Older versions are never edited, only superseded.</p></div>
      ${vs.length > 1 ? `<div class="actions"><button class="btn" id="shareChange">${icon("copy")}Share change</button><button class="btn btn-primary" id="confirmV">Confirm version ${vs[0].version_n}</button></div>` : ""}</div>`);
    if (!vs.length) { h(`<div class="card empty"><div class="big" aria-hidden="true">○</div><h2>No versions yet</h2><p>A version is saved when the recap is confirmed.</p><a class="btn btn-primary" href="#/recap/${d.key}">Go to recap</a></div>`); return; }
    h(`<div class="grid-2" style="align-items:start">
      <section class="card"><div class="card-title">History</div><div class="stack">
        ${vs.map((v, i) => {
          const conf = d.confirmations.filter((c) => c.version_n === v.version_n && c.state === "confirmed");
          const changed = diff && diff.to_version_n === v.version_n ? diff.rows.filter((r) => r.change !== "no_change").map((r) => `${label(r.term_key)} ${r.change.replace("_", " ")}`).join(", ") : i === vs.length - 1 ? "First version" : "";
          return `<div class="seal">${icon("versions")}<span><b>Version ${v.version_n}${i === 0 ? " (Current)" : ""}</b><br><span class="faint" style="font-size:13px">${esc(time(v.created_at))} · ${esc(changed)}${v.reason_message_id ? ` · reason: <a href="#/workspace/${d.key}">message #${seq(d, v.reason_message_id)}</a>` : ""}</span></span>
            ${conf.length >= 2 ? `<span class="status clear">Both confirmed</span>` : `<span class="status pending">Awaiting confirmation</span>`}</div>`;
        }).join("")}</div></section>
      <section class="card"><div class="card-title">${diff ? `Version ${diff.from_version_n} → ${diff.to_version_n}` : "Changes"}</div>
        ${diff ? `<table class="table"><thead><tr><th>Term</th><th>v${diff.from_version_n}</th><th>v${diff.to_version_n}</th><th>Change</th></tr></thead><tbody>
          ${diff.rows.map((r) => `<tr class="${r.change === "no_change" ? "" : "emph"}"><td>${esc(label(r.term_key))}</td><td>${esc(value(r.before))}</td><td>${esc(value(r.after))}</td><td><span class="status ${changeWord[r.change][0]}">${changeWord[r.change][1]}</span></td></tr>`).join("")}
        </tbody></table>` : `<p class="muted">One version only, so there is no difference to show yet.</p>`}
      </section></div>`);
    const sc = document.getElementById("shareChange");
    if (sc) {
      sc.addEventListener("click", () => copy(`Hi ${other(d).display_name}, one change to what we agreed:\n` + diff.rows.filter((r) => r.change !== "no_change").map((r) => `${label(r.term_key)}: ${value(r.before)} → ${value(r.after)}`).join("\n"), "Change copied. Paste it into WhatsApp."));
      document.getElementById("confirmV").addEventListener("click", () => needsApi(`Confirming version ${vs[0].version_n}`));
    }
  }

  /* ======================= S8 Receipt ======================= */
  function renderReceipt(d) {
    const rc = d.receipts[d.receipts.length - 1];
    const imp = d.import_records[0];
    const confirmed = dealState(d).status[0] === "clear";
    h(`<div class="page-head"><div class="grow"><h1>Receipt</h1><p>The tamper-evident record of this deal.</p></div>
      <div class="actions"><a class="btn" href="verify.html">${icon("verify")}Open verify page</a><a class="btn" href="#/pack/${d.key}">${icon("pack")}Create dispute pack</a><button class="btn btn-primary" id="exportRc" ${rc ? "" : "disabled"}>Export receipt bundle</button></div></div>
      <div class="notice warn" style="margin-bottom:14px"><span class="sym">!</span><p>${STR.limits.find((l) => l[0] === "L3")[1]}</p></div>`);
    if (!rc) { h(`<div class="card empty"><div class="big" aria-hidden="true">○</div><h2>No receipt yet</h2><p>A receipt is recorded when the chat is sealed in the vault.</p></div>`); return; }
    const b = rc.body;
    h(`<div class="stack">
      <section class="card"><div class="card-title">${icon("hash", "ic")} Chain of records</div>
        <div class="chain">
          <div class="node"><b>Chat import</b><span class="mono">${imp && imp.export_digest ? short(imp.export_digest, 12) : "digest TBD"}</span><span class="faint" style="font-size:12px">${imp ? esc(time(imp.imported_at)) : ""}</span></div>
          ${b.chain.map((c) => `<div class="arrow" aria-hidden="true">→</div><div class="node"><b>Agreement v${c.version_n}</b><span class="mono" title="${c.link}">${short(c.link, 12)}</span></div>`).join("")}
          <div class="arrow" aria-hidden="true">→</div><div class="node"><b>${confirmed ? '<span class="status clear">Confirmed</span>' : '<span class="status pending">Pending</span>'}</b><span class="mono" title="${rc.receipt_hash}">${short(rc.receipt_hash, 12)}</span></div>
        </div></section>
      <div class="grid-2" style="align-items:start">
        <section class="card"><div class="card-title">Commitment</div><dl class="kv">
          <dt>Root hash</dt><dd class="mono">${b.root}</dd>
          <dt>Method</dt><dd>SHA-256, Merkle tree, salted</dd>
          <dt>Messages covered</dt><dd>${b.leaf_count}</dd>
          <dt>Recorded at</dt><dd>${esc(time(b.recorded_at))} (device clock)</dd>
          <dt>Spec version</dt><dd>${esc(b.spec_version)}</dd>
          <dt>Receipt hash</dt><dd class="mono">${rc.receipt_hash}</dd></dl></section>
        <section class="card"><div class="card-title">Independent timestamp <span class="tag">P1</span></div>
          <p style="margin:0 0 12px"><span class="status neutral">${b.anchor ? "Anchored" : "Not anchored, device clock only"}</span></p>
          <p class="muted" style="margin:0 0 12px;font-size:14px">${STR.limits.find((l) => l[0] === "L6")[1]}</p>
          <button class="btn" disabled>Anchor now</button></section>
      </div></div>`);
    document.getElementById("exportRc").addEventListener("click", () => needsApi("Exporting the receipt bundle"));
  }

  /* ======================= S10 Dispute pack ======================= */
  function renderPack(d) {
    const dp = d.dispute_packs[0];
    const names = { timeline: "Deal timeline", evidence_index: "Evidence index with hashes", terms_all_versions: "Agreed terms with all versions", certificate_draft: "Draft certificate (electronic record)", verification_guide: "How to verify", receipt_bundle: "Receipt bundle" };
    const parts = dp ? dp.parts : Object.keys(names).map((n) => ({ name: n, included: true }));
    h(`<div class="page-head"><div class="grow"><h1>Dispute pack</h1><p>One export for a lawyer, a CA or the MSME Facilitation Council: a court-ready evidence package.</p></div></div>
      <div class="stack" style="max-width:860px">
        <div class="notice warn"><span class="sym">!</span><p><b>Drafting aid, not legal advice.</b> ${STR.limits.find((l) => l[0] === "L9")[1]}</p></div>
        <div class="group-title">Pack contents</div>
        <div class="group">${parts.map((p, i) => `<label class="group-row"><span class="grow">${esc(names[p.name] || p.name)}</span><span class="switch"><input type="checkbox" ${p.included ? "checked" : ""} data-i="${i}" aria-label="Include ${esc(names[p.name] || p.name)}"><span></span></span></label>`).join("")}
          <div class="group-row"><span class="grow">Share only deal messages <small>Leaves out unrelated chat</small></span><span class="tag">P1</span><span class="switch"><input type="checkbox" disabled aria-label="Share only deal messages (later)"><span></span></span></div></div>
        <div class="group-title">Privacy mask <span class="tag">P1</span></div>
        <div class="group"><div class="group-row"><span class="grow">Mask names and numbers<small>Masked parts still verify against the original receipt. Money amounts and dates are never masked.</small></span><span class="switch"><input type="checkbox" disabled aria-label="Privacy mask (later)"><span></span></span></div></div>
        <div class="notice danger"><span class="sym">⚠</span><p>${STR.limits.find((l) => l[0] === "L13")[1]}</p></div>
        <div class="card"><dl class="kv"><dt>Estimated size</dt><dd>${dp ? (dp.size_bytes / 1048576).toFixed(1) + " MB" : "Shown after the first preview"}</dd><dt>Pages</dt><dd>${dp ? dp.page_count : "—"}</dd><dt>Certificate</dt><dd>Unsigned draft</dd></dl></div>
        <div class="actions" style="justify-content:flex-end"><a class="btn" href="#/receipt/${d.key}">Back to receipt</a><button class="btn" id="previewPdf">Preview PDF</button><button class="btn btn-primary" id="exportPack">Export pack</button></div>
      </div>`);
    view.querySelectorAll(".switch input[data-i]").forEach((c) => c.addEventListener("change", () => { parts[+c.dataset.i].included = c.checked; }));
    document.getElementById("previewPdf").addEventListener("click", () => needsApi("Building the PDF preview"));
    document.getElementById("exportPack").addEventListener("click", () => needsApi("Exporting the dispute pack"));
  }

  /* ======================= S11 Settings ======================= */
  function renderSettings() {
    const theme = document.documentElement.getAttribute("data-theme") || "system";
    h(`<div class="page-head"><div class="grow"><h1>Settings</h1><p>Vault, language, AI models and timestamping.</p></div></div>
      <div class="stack" style="max-width:820px">
        <div class="group-title">Vault and recovery</div>
        <div class="group">
          <div class="group-row">${icon("lock")}<span class="grow">Passphrase<small>Opens the vault on this device</small></span><button class="btn btn-sm" id="chgPass">Change</button></div>
          <div class="group-row">${icon("file")}<span class="grow">Recovery key<small>Shown once at setup. Keep a printed copy somewhere safe.</small></span><button class="btn btn-sm" id="printKey">Print key</button></div>
        </div>
        <div class="notice warn"><span class="sym">!</span><p>${STR.limits.find((l) => l[0] === "L10")[1]}</p></div>
        <div class="group-title">Language and appearance</div>
        <div class="group">
          <div class="group-row"><span class="grow">App language</span><div class="segmented"><button aria-pressed="true">English</button><button id="hiUi">हिन्दी</button></div></div>
          <div class="group-row"><span class="grow">Recap language</span><div class="segmented" id="recapLang"><button data-l="en" aria-pressed="${S.lang === "en"}">English</button><button data-l="hi" aria-pressed="${S.lang === "hi"}">हिन्दी</button><button disabled>ಕನ್ನಡ <span class="tag">P1</span></button></div></div>
          <div class="group-row"><span class="grow">Appearance</span><div class="segmented" id="themeSeg">${[["system", "System"], ["light", "Light"], ["dark", "Dark"]].map(([k, l]) => `<button data-t="${k}" aria-pressed="${theme === k}">${l}</button>`).join("")}</div></div>
        </div>
        <div class="group-title">AI and models</div>
        <div class="group">
          <div class="group-row">${icon("sparkle")}<span class="grow">Extraction model<small>${API.info ? esc(API.info.model) + " · tier " + esc(API.info.tier) + (API.info.classifier ? " · deal-type classifier on" : "") : "Not connected: open VeriDoc with Start VeriDoc on the pendrive"}</small></span>${API.info ? `<span class="status ${API.ok ? "clear" : API.info.state === "starting" ? "pending" : "conflict"}">${API.ok ? "Running on this device" : API.info.state === "starting" ? "Loading" : "Unavailable"}</span>` : `<span class="status neutral">Sample data only</span>`}</div>
          <div class="group-row">${icon("mic")}<span class="grow">Speech to text model<small>Name TBD, pending benchmarks</small></span><span class="status neutral">Hash check not run in this build</span></div>
          <div class="group-row"><span class="grow">Cloud AI<small>Chats never leave this device</small></span><span class="status neutral">Off</span><span class="switch"><input type="checkbox" disabled aria-label="Cloud AI (disabled)"><span></span></span></div>
          <div class="group-row"><span class="grow">Safe mode<small>Rules only. The AI helper is off.</small></span><span class="switch"><input type="checkbox" id="safeMode" ${S.safeMode ? "checked" : ""} aria-label="Safe mode"><span></span></span></div>
        </div>
        <div class="group-title">Timestamping <span class="tag">P1</span></div>
        <div class="group"><div class="group-row"><span class="grow">Anchor receipts when online<small>Sends only a hash, never chat content</small></span><span class="switch"><input type="checkbox" disabled aria-label="Anchor receipts (later)"><span></span></span></div></div>
        <div class="group-title">About and limits</div>
        <div class="group"><ul class="limit-list">${STR.limits.map(([k, t]) => `<li><span class="mono">${k}</span><span>${esc(t)}</span></li>`).join("")}</ul></div>
      </div>`);
    document.getElementById("safeMode").addEventListener("change", (e) => { S.safeMode = e.target.checked; renderChrome(parse()); toast(S.safeMode ? "Safe mode on: rules only" : "Safe mode off"); });
    document.getElementById("themeSeg").addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.t === "system") { document.documentElement.removeAttribute("data-theme"); try { localStorage.removeItem("vd-theme"); } catch (x) { /* ignore */ } }
      else { document.documentElement.setAttribute("data-theme", b.dataset.t); try { localStorage.setItem("vd-theme", b.dataset.t); } catch (x) { /* ignore */ } }
      paintThemeBtn(); render();
    });
    document.getElementById("recapLang").addEventListener("click", (e) => { const b = e.target.closest("button[data-l]"); if (!b) return; S.lang = b.dataset.l; render(); });
    document.getElementById("hiUi").addEventListener("click", () => toast("Hindi UI strings come after native-speaker review."));
    document.getElementById("chgPass").addEventListener("click", () => needsApi("Changing the passphrase"));
    document.getElementById("printKey").addEventListener("click", () => needsApi("Printing the recovery key"));
  }

  /* ======================= Lock screen ======================= */
  const lockEl = document.getElementById("lock");
  function lockVault() {
    S.locked = true;
    lockEl.innerHTML = `<div class="lock-card glass"><div>${icon("lock")}</div><h2>Vault locked</h2><p class="muted" style="margin:0">Enter your passphrase to open your deals.</p>
      <form id="unlockForm"><label class="sr-only" for="pass">Passphrase</label><input class="input" type="password" id="pass" autocomplete="current-password" placeholder="Passphrase">
      <div class="err" id="passErr" hidden></div><button class="btn btn-primary">Unlock</button><button type="button" class="btn btn-ghost btn-sm" id="useRecovery">Use recovery key</button></form>
      <p class="faint" style="font-size:12px;margin:0">Demo build: any passphrase opens the sample vault.</p></div>`;
    lockEl.hidden = false; view.setAttribute("aria-hidden", "true");
    document.getElementById("pass").focus();
    document.getElementById("unlockForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const p = document.getElementById("pass").value;
      if (!p) { const er = document.getElementById("passErr"); er.hidden = false; er.textContent = "That passphrase did not open the vault."; return; }
      S.locked = false; lockEl.hidden = true; lockEl.innerHTML = ""; view.removeAttribute("aria-hidden"); toast("Vault unlocked");
    });
    document.getElementById("useRecovery").addEventListener("click", () => needsApi("Opening the vault with the recovery key"));
  }

  render();
  checkApi();
})();
