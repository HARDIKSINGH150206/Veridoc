/* Mock data: the made-up fixtures from packages/contracts/fixtures (clean, ambiguous, contradictory),
   copied as-is so every screen is built against the real contract shapes. Regenerate when the contracts change. */
window.VD_FIXTURES = {
 "clean": {
  "description": "Made-up clean deal: every term stated and acknowledged, recap confirmed by both. The recap hash, echo code, leaves, root, version link and receipt hash are computed with packages/integrity.",
  "playbook": {
   "key": "supply_order",
   "version": 1
  },
  "participants": [
   {
    "id": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "display_name": "Asha",
    "role": "party",
    "is_me": true
   },
   {
    "id": "a40e184e-be75-5618-9f60-b2d421cf8120",
    "display_name": "Bilal",
    "role": "party",
    "is_me": false
   }
  ],
  "messages": [
   {
    "id": "8716ba37-5823-532c-a664-fded086e1ef3",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 1,
    "sender_id": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "ts": "2026-09-01T14:00:00+05:30",
    "text": "Hi Bilal, 50 mugs at 120 each, total 6000. OK?",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "031fe443-9239-5879-8fdc-685fb542c639",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 2,
    "sender_id": "a40e184e-be75-5618-9f60-b2d421cf8120",
    "ts": "2026-09-01T14:03:00+05:30",
    "text": "Yes, done. 50 mugs, 120 each.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "129179a4-77dd-5bef-a939-9dc64f2a59ae",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 3,
    "sender_id": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "ts": "2026-09-01T14:05:00+05:30",
    "text": "I will pay 3000 today and 3000 on delivery.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "8e90cc9e-6247-528d-937f-caefe7ead372",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 4,
    "sender_id": "a40e184e-be75-5618-9f60-b2d421cf8120",
    "ts": "2026-09-01T14:06:00+05:30",
    "text": "Agreed. Delivery on 20 Sept.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "49badaf8-7fab-53d7-8e41-d41e64a2ea5f",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 5,
    "sender_id": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "ts": "2026-09-01T14:10:00+05:30",
    "text": "If late by more than 3 days, 5 percent off the balance.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "2f0fc51a-5f2f-5706-ad18-7b058a9cb060",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 6,
    "sender_id": "a40e184e-be75-5618-9f60-b2d421cf8120",
    "ts": "2026-09-01T14:11:00+05:30",
    "text": "Fine, agreed. White ceramic mugs as shown.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "351ac0e3-aeaa-5c19-86c7-03c1cc620d91",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "seq": 7,
    "sender_id": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "ts": "2026-09-01T14:20:00+05:30",
    "text": "Sent 3000.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   }
  ],
  "terms": [
   {
    "id": "1d7782a5-f77d-5a13-8fc6-87d7b7873d9b",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "buyer",
    "value": {
     "kind": "text",
     "text": "Asha"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
      "quote": "Asha"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "f0de2aac-67dc-5e18-a78e-afcbe80ca53b",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "seller",
    "value": {
     "kind": "text",
     "text": "Bilal"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
      "quote": "Bilal"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "e93829ba-38bd-55a0-9f5f-a694cba0b9e9",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "item",
    "value": {
     "kind": "text",
     "text": "mugs"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
      "quote": "mugs"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "53e0b338-4039-5ac3-9974-39816307b2ec",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "quantity",
    "value": {
     "kind": "quantity",
     "amount": "50",
     "unit": "mugs"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "031fe443-9239-5879-8fdc-685fb542c639",
      "quote": "50 mugs"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "c545e987-d985-5f91-ad05-d2b10cb39bd5",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "unit_price",
    "value": {
     "kind": "money",
     "paise": "12000"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "031fe443-9239-5879-8fdc-685fb542c639",
      "quote": "120 each"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "c8871d4c-7c98-5c3f-a015-af628e5d9349",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "total_amount",
    "value": {
     "kind": "money",
     "paise": "600000"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
      "quote": "total 6000"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "572bbfad-5980-5a2b-9823-f9b4ef7dded7",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "advance_amount",
    "value": {
     "kind": "money",
     "paise": "300000"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "129179a4-77dd-5bef-a939-9dc64f2a59ae",
      "quote": "3000 today"
     },
     {
      "kind": "message",
      "message_id": "351ac0e3-aeaa-5c19-86c7-03c1cc620d91",
      "quote": "Sent 3000"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "4e8eb4a9-ac1e-54f4-bb71-db910f38f031",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "delivery_date",
    "value": {
     "kind": "date",
     "date": "2026-09-20"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "user",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "8e90cc9e-6247-528d-937f-caefe7ead372",
      "quote": "Delivery on 20 Sept"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "ba5acf92-bf5b-5368-8cce-e3d8c581af9c",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "balance_payment_date",
    "value": {
     "kind": "event",
     "event": "on_delivery"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "129179a4-77dd-5bef-a939-9dc64f2a59ae",
      "quote": "3000 on delivery"
     },
     {
      "kind": "message",
      "message_id": "8e90cc9e-6247-528d-937f-caefe7ead372",
      "quote": "Agreed"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "ba70c154-655b-5ada-9a66-656a4cb67d7a",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "late_penalty",
    "value": {
     "kind": "text",
     "text": "5 percent off the balance after 3 days"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "49badaf8-7fab-53d7-8e41-d41e64a2ea5f",
      "quote": "5 percent off the balance"
     },
     {
      "kind": "message",
      "message_id": "2f0fc51a-5f2f-5706-ad18-7b058a9cb060",
      "quote": "Fine, agreed"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   },
   {
    "id": "2dd7f3e2-f995-5305-9a08-72584a39416f",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "key": "quality_spec",
    "value": {
     "kind": "text",
     "text": "white ceramic"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "2f0fc51a-5f2f-5706-ad18-7b058a9cb060",
      "quote": "White ceramic mugs"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-09-01T14:30:00+05:30",
    "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "acknowledged_by_other": true
   }
  ],
  "score": {
   "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
   "ts": "2026-09-01T14:30:00+05:30",
   "total": 100,
   "breakdown": [
    {
     "term_key": "buyer",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "seller",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "item",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "quantity",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "unit_price",
     "weight": 15,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 15.0
    },
    {
     "term_key": "total_amount",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "advance_amount",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "delivery_date",
     "weight": 15,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 15.0
    },
    {
     "term_key": "balance_payment_date",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "late_penalty",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "quality_spec",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    }
   ],
   "trigger": "recap_confirmed"
  },
  "voice_notes": [],
  "transcripts": [],
  "flags": [],
  "suggestions": [],
  "handshake_questions": [],
  "sealed_answers": [],
  "handshake_reveals": [],
  "recaps": [
   {
    "id": "7fb58a91-3201-5fd6-bb5a-9ab3423a9d38",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "version_n": 1,
    "language": "en",
    "lines": [
     {
      "term_key": "buyer",
      "text": "Hi Bilal, just confirming what we discussed:",
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": null
       }
      ]
     },
     {
      "term_key": "quantity",
      "text": "50 mugs at 120 = 6,000",
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": null
       }
      ]
     },
     {
      "term_key": "advance_amount",
      "text": "3,000 advance received",
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": null
       }
      ]
     },
     {
      "term_key": "delivery_date",
      "text": "Delivery by 20 Sept",
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": null
       }
      ]
     },
     {
      "term_key": "balance_payment_date",
      "text": "Balance 3,000 on delivery",
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": null
       }
      ]
     },
     {
      "term_key": "late_penalty",
      "text": "If late by more than 3 days: 5 percent off the balance",
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": null
       }
      ]
     }
    ],
    "body_text": "Hi Bilal, just confirming what we discussed:\n50 mugs at 120 = 6,000\n3,000 advance received\nDelivery by 20 Sept\nBalance 3,000 on delivery\nIf late by more than 3 days: 5 percent off the balance",
    "text": "Hi Bilal, just confirming what we discussed:\n50 mugs at 120 = 6,000\n3,000 advance received\nDelivery by 20 Sept\nBalance 3,000 on delivery\nIf late by more than 3 days: 5 percent off the balance\nIf all correct, reply: CONFIRM BKZ7",
    "recap_hash": "59e4d7aa962e5ade3c0dd3e9378c00cf380eba604117aa4f402438db39776166",
    "echo_code": {
     "code": "BKZ7",
     "recap_hash": "59e4d7aa962e5ade3c0dd3e9378c00cf380eba604117aa4f402438db39776166",
     "version_n": 1
    },
    "created_at": "2026-09-01T14:35:00+05:30"
   }
  ],
  "confirmations": [
   {
    "id": "2134792b-3a24-5246-8463-5ab0438e8417",
    "recap_id": "7fb58a91-3201-5fd6-bb5a-9ab3423a9d38",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "version_n": 1,
    "party_id": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
    "state": "confirmed",
    "reply_text": null,
    "reply_ts": null,
    "code": null,
    "sender_entered_by_user": false,
    "failure": null,
    "checked_at": "2026-09-01T14:36:00+05:30"
   },
   {
    "id": "8f9a86b4-dd43-5bb5-8743-3d58ffc868d0",
    "recap_id": "7fb58a91-3201-5fd6-bb5a-9ab3423a9d38",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "version_n": 1,
    "party_id": "a40e184e-be75-5618-9f60-b2d421cf8120",
    "state": "confirmed",
    "reply_text": "CONFIRM BKZ7",
    "reply_ts": "2026-09-01T14:41:00+05:30",
    "code": "BKZ7",
    "sender_entered_by_user": false,
    "failure": null,
    "checked_at": "2026-09-01T14:42:00+05:30"
   }
  ],
  "versions": [
   {
    "id": "e0bfb65d-3014-59c2-98c0-19fd60de6884",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "version_n": 1,
    "playbook": {
     "key": "supply_order",
     "version": 1
    },
    "terms": [
     {
      "key": "advance_amount",
      "value": {
       "kind": "money",
       "paise": "300000"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "129179a4-77dd-5bef-a939-9dc64f2a59ae",
        "quote": "3000 today"
       },
       {
        "kind": "message",
        "message_id": "351ac0e3-aeaa-5c19-86c7-03c1cc620d91",
        "quote": "Sent 3000"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "balance_payment_date",
      "value": {
       "kind": "event",
       "event": "on_delivery"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "129179a4-77dd-5bef-a939-9dc64f2a59ae",
        "quote": "3000 on delivery"
       },
       {
        "kind": "message",
        "message_id": "8e90cc9e-6247-528d-937f-caefe7ead372",
        "quote": "Agreed"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "buyer",
      "value": {
       "kind": "text",
       "text": "Asha"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": "Asha"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "delivery_date",
      "value": {
       "kind": "date",
       "date": "2026-09-20"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "8e90cc9e-6247-528d-937f-caefe7ead372",
        "quote": "Delivery on 20 Sept"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "item",
      "value": {
       "kind": "text",
       "text": "mugs"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": "mugs"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "late_penalty",
      "value": {
       "kind": "text",
       "text": "5 percent off the balance after 3 days"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "49badaf8-7fab-53d7-8e41-d41e64a2ea5f",
        "quote": "5 percent off the balance"
       },
       {
        "kind": "message",
        "message_id": "2f0fc51a-5f2f-5706-ad18-7b058a9cb060",
        "quote": "Fine, agreed"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "quality_spec",
      "value": {
       "kind": "text",
       "text": "white ceramic"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "2f0fc51a-5f2f-5706-ad18-7b058a9cb060",
        "quote": "White ceramic mugs"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "quantity",
      "value": {
       "kind": "quantity",
       "amount": "50",
       "unit": "mugs"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "031fe443-9239-5879-8fdc-685fb542c639",
        "quote": "50 mugs"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "seller",
      "value": {
       "kind": "text",
       "text": "Bilal"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": "Bilal"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "total_amount",
      "value": {
       "kind": "money",
       "paise": "600000"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "8716ba37-5823-532c-a664-fded086e1ef3",
        "quote": "total 6000"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     },
     {
      "key": "unit_price",
      "value": {
       "kind": "money",
       "paise": "12000"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "031fe443-9239-5879-8fdc-685fb542c639",
        "quote": "120 each"
       }
      ],
      "confirmed_by": "eec0a003-b75c-5dba-a9de-0476770a9cbe",
      "confirmed_at": "2026-09-01T14:30:00+05:30"
     }
    ],
    "terms_digest": "49347fb28ddea52a0cd71cb36f37beb8e6cc57ca57b6c40ce332ba2408160012",
    "root": "da5d13fb1707e1accb9d17fd3228c91bb009de7f2ab1cee8153de51b59884cea",
    "link": "07924ee4abf869137316190fe378d1dc7a534c9c6fded91ecdeed666d73a63d0",
    "prev_link": null,
    "reason_message_id": null,
    "created_at": "2026-09-01T14:36:00+05:30"
   }
  ],
  "version_diffs": [],
  "receipts": [
   {
    "body": {
     "spec_version": "0.1-draft",
     "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
     "leaf_count": 7,
     "root": "da5d13fb1707e1accb9d17fd3228c91bb009de7f2ab1cee8153de51b59884cea",
     "chain": [
      {
       "version_n": 1,
       "terms_digest": "49347fb28ddea52a0cd71cb36f37beb8e6cc57ca57b6c40ce332ba2408160012",
       "root": "da5d13fb1707e1accb9d17fd3228c91bb009de7f2ab1cee8153de51b59884cea",
       "link": "07924ee4abf869137316190fe378d1dc7a534c9c6fded91ecdeed666d73a63d0"
      }
     ],
     "recorded_at": "2026-09-01T14:42:00+05:30",
     "anchor": null
    },
    "receipt_hash": "26ad87aeeb1408bdc498fdd683857da5100450502fa9886b5852742b2989ff37"
   }
  ],
  "verify_results": [
   {
    "verdict": "unchanged",
    "spec_version": "0.1-draft",
    "checks": [
     {
      "name": "chain",
      "status": "pass",
      "detail": "all links match"
     },
     {
      "name": "merkle_root",
      "status": "pass",
      "detail": "root matches the receipt"
     },
     {
      "name": "timestamp_order",
      "status": "pass",
      "detail": null
     },
     {
      "name": "anchor",
      "status": "not_anchored",
      "detail": "device clock only"
     }
    ],
    "first_difference": null
   }
  ],
  "dispute_packs": [
   {
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "parts": [
     {
      "name": "timeline",
      "included": true
     },
     {
      "name": "evidence_index",
      "included": true
     },
     {
      "name": "terms_all_versions",
      "included": true
     },
     {
      "name": "certificate_draft",
      "included": true
     },
     {
      "name": "verification_guide",
      "included": true
     },
     {
      "name": "receipt_bundle",
      "included": true
     }
    ],
    "certificate_status": "unsigned_draft",
    "disclaimer_shown": true,
    "masked": false,
    "page_count": 14,
    "size_bytes": 1258291,
    "file_digest": null,
    "created_at": "2026-09-02T10:00:00+05:30"
   }
  ],
  "import_records": [
   {
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "export_digest": "38f39656a2e2d619ef3fe19df7c3d4528314a8512fb8070ba332f960389fd9ab",
    "file_name": "WhatsApp Chat - Bilal.txt",
    "message_count": 7,
    "imported_at": "2026-09-01T14:25:00+05:30"
   }
  ],
  "leaf_rows": [
   {
    "seq": 1,
    "leaf_type": "message",
    "leaf_hash": "6a6c3dc488ce9320771455b6537e26b1cc6c12c566d42f9712256dce7feed753",
    "salt": "02020202020202020202020202020202",
    "payload_digest": "1e79fdbf7e84badc0ca94ce61ce992f4d61b3aa22f2f99f4cfe2cac404a721db",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"8716ba37-5823-532c-a664-fded086e1ef3\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"eec0a003-b75c-5dba-a9de-0476770a9cbe\",\"seq\":1,\"text\":\"Hi Bilal, 50 mugs at 120 each, total 6000. OK?\",\"ts\":\"2026-09-01T14:00:00+05:30\"}"
   },
   {
    "seq": 2,
    "leaf_type": "message",
    "leaf_hash": "77b36b645b5648cfde08c87662983da06adb1d04ffda5618e0b6238d782dcd4e",
    "salt": "03030303030303030303030303030303",
    "payload_digest": "913762c69057b6d532ec0def6a595d8327411a70fb412f1655c8b0734eda9578",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"031fe443-9239-5879-8fdc-685fb542c639\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"a40e184e-be75-5618-9f60-b2d421cf8120\",\"seq\":2,\"text\":\"Yes, done. 50 mugs, 120 each.\",\"ts\":\"2026-09-01T14:03:00+05:30\"}"
   },
   {
    "seq": 3,
    "leaf_type": "message",
    "leaf_hash": "3d881c68900d0af0671ac1fd910cb929fe3eafebc6f5640ec97cf1bf7cdfde88",
    "salt": "04040404040404040404040404040404",
    "payload_digest": "555b05e9a7215aceb3debfc015bda65a904b49b567a6d163957b0b6403beeee7",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"129179a4-77dd-5bef-a939-9dc64f2a59ae\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"eec0a003-b75c-5dba-a9de-0476770a9cbe\",\"seq\":3,\"text\":\"I will pay 3000 today and 3000 on delivery.\",\"ts\":\"2026-09-01T14:05:00+05:30\"}"
   },
   {
    "seq": 4,
    "leaf_type": "message",
    "leaf_hash": "a2b438ac21f639d57c77e38f68b6a161478b891563f8a4f2f2bbd4c2a30c5c29",
    "salt": "05050505050505050505050505050505",
    "payload_digest": "a1570c51747ad67af2fb2abbf689e64f8de72bb3ef55efe58d230cb73fa75bba",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"8e90cc9e-6247-528d-937f-caefe7ead372\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"a40e184e-be75-5618-9f60-b2d421cf8120\",\"seq\":4,\"text\":\"Agreed. Delivery on 20 Sept.\",\"ts\":\"2026-09-01T14:06:00+05:30\"}"
   },
   {
    "seq": 5,
    "leaf_type": "message",
    "leaf_hash": "538fac433a0f6239e15331cafe96a87e7205715d7c42d446ccc317f991db9e17",
    "salt": "06060606060606060606060606060606",
    "payload_digest": "d95089424d234fc169b3e4b85e38206d249845b3b2283cd8faf5f51dbb30b871",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"49badaf8-7fab-53d7-8e41-d41e64a2ea5f\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"eec0a003-b75c-5dba-a9de-0476770a9cbe\",\"seq\":5,\"text\":\"If late by more than 3 days, 5 percent off the balance.\",\"ts\":\"2026-09-01T14:10:00+05:30\"}"
   },
   {
    "seq": 6,
    "leaf_type": "message",
    "leaf_hash": "608b683b9c65fa9a0c40e6812ea3570c4891be28b4b8fc76acfa034544dd7002",
    "salt": "07070707070707070707070707070707",
    "payload_digest": "c2ed6e4fe38c19290be46c4d0ffb7badd0a36a9cbc763f2a50115c2ee6561759",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"2f0fc51a-5f2f-5706-ad18-7b058a9cb060\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"a40e184e-be75-5618-9f60-b2d421cf8120\",\"seq\":6,\"text\":\"Fine, agreed. White ceramic mugs as shown.\",\"ts\":\"2026-09-01T14:11:00+05:30\"}"
   },
   {
    "seq": 7,
    "leaf_type": "message",
    "leaf_hash": "a1cab678a84d2d632a02a26a5813226a685cde71a043c393d105018c7a47f37a",
    "salt": "08080808080808080808080808080808",
    "payload_digest": "e17891c2f4595ca222d2187db6b6132acbee4beb42b072892b2bfcc9834c15b0",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"0c05f159-dbd8-5cfa-b235-584b4bd4d67d\",\"id\":\"351ac0e3-aeaa-5c19-86c7-03c1cc620d91\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"eec0a003-b75c-5dba-a9de-0476770a9cbe\",\"seq\":7,\"text\":\"Sent 3000.\",\"ts\":\"2026-09-01T14:20:00+05:30\"}"
   }
  ],
  "bundles": [
   {
    "spec_version": "0.1-draft",
    "deal_id": "0c05f159-dbd8-5cfa-b235-584b4bd4d67d",
    "files": [
     {
      "path": "receipt.json",
      "role": "receipt",
      "sha256": "d84199a863b709e6114748fc4b72e2135451231f73c433d8b21316d7eddff55b"
     },
     {
      "path": "leaves.jsonl",
      "role": "leaves",
      "sha256": "6b4668f8098f61759318e9aa5f9e1cd6a811fd5653e89d2659c830d6ebeb9c14"
     },
     {
      "path": "chain.json",
      "role": "chain",
      "sha256": "5a0ea85f32534e4a11b222d4caf8105d68a4040d0f8434b14e925f1ce1c6afe0"
     },
     {
      "path": "README.txt",
      "role": "readme",
      "sha256": "5a6dafe6daa34cbfde09d879f9336398094f7b0d147b9e44e8ffe2973d0db50a"
     }
    ],
    "created_at": "2026-09-02T10:00:00+05:30"
   }
  ]
 },
 "ambiguous": {
  "description": "Made-up ambiguous deal: delivery is unclear, final payment and late penalty are missing, the unconfirmed delivery term earns nothing. Hashes are computed with packages/integrity from the fixture data.",
  "playbook": {
   "key": "supply_order",
   "version": 1
  },
  "participants": [
   {
    "id": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "display_name": "Raju",
    "role": "party",
    "is_me": true
   },
   {
    "id": "d45984b4-4aa3-5e87-8280-6f97100714a9",
    "display_name": "Meena",
    "role": "party",
    "is_me": false
   }
  ],
  "messages": [
   {
    "id": "e8739171-daba-539b-a799-e0948c4fcb6f",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "seq": 1,
    "sender_id": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "ts": "2026-10-12T10:02:00+05:30",
    "text": "200 shirts, 480 each ok?",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "89fbe45e-a173-52a5-bc76-607776217801",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "seq": 2,
    "sender_id": "d45984b4-4aa3-5e87-8280-6f97100714a9",
    "ts": "2026-10-12T10:04:00+05:30",
    "text": "ok. delivery next week",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "b574ba83-827b-57a1-8812-d69ce2e7486a",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "seq": 3,
    "sender_id": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "ts": "2026-10-12T10:05:00+05:30",
    "text": "advance half now",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "150cc0fe-c4ff-50d1-b532-a9d7f81ee9e0",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "seq": 4,
    "sender_id": "d45984b4-4aa3-5e87-8280-6f97100714a9",
    "ts": "2026-10-12T10:21:00+05:30",
    "text": "done sent 48000",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "8582c6a8-13ba-5937-9152-52d1a3ec86ba",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "seq": 5,
    "sender_id": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "ts": "2026-10-13T09:15:00+05:30",
    "text": "received. will message when ready",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   }
  ],
  "terms": [
   {
    "id": "66ea8751-35f8-5656-bf83-3a787349564f",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "buyer",
    "value": {
     "kind": "text",
     "text": "Raju"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "e8739171-daba-539b-a799-e0948c4fcb6f",
      "quote": "Raju"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-10-13T09:30:00+05:30",
    "confirmed_by": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "acknowledged_by_other": true
   },
   {
    "id": "1a5494d8-1b36-5b60-98dd-842a56bcfaaf",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "seller",
    "value": {
     "kind": "text",
     "text": "Meena"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "89fbe45e-a173-52a5-bc76-607776217801",
      "quote": "Meena"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-10-13T09:30:00+05:30",
    "confirmed_by": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "acknowledged_by_other": true
   },
   {
    "id": "d100f57f-de93-5202-bb4a-397bd2225308",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "item",
    "value": {
     "kind": "text",
     "text": "shirts"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "e8739171-daba-539b-a799-e0948c4fcb6f",
      "quote": "shirts"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-10-13T09:30:00+05:30",
    "confirmed_by": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "acknowledged_by_other": true
   },
   {
    "id": "7a352b66-4e44-5c27-9acd-ff57c17c5906",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "quantity",
    "value": {
     "kind": "quantity",
     "amount": "200",
     "unit": "shirts"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "e8739171-daba-539b-a799-e0948c4fcb6f",
      "quote": "200 shirts"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-10-13T09:30:00+05:30",
    "confirmed_by": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "acknowledged_by_other": true
   },
   {
    "id": "7e4050e1-3ac3-5c17-9726-d1a33e04e121",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "unit_price",
    "value": {
     "kind": "money",
     "paise": "48000"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "e8739171-daba-539b-a799-e0948c4fcb6f",
      "quote": "480 each"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-10-13T09:30:00+05:30",
    "confirmed_by": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "acknowledged_by_other": true
   },
   {
    "id": "88acd4e8-5e0c-59e8-a293-18d8c2591a61",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "total_amount",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "5a41a681-5d39-54f5-84d4-7741ba446348",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "advance_amount",
    "value": {
     "kind": "money",
     "paise": "4800000"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "both",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "b574ba83-827b-57a1-8812-d69ce2e7486a",
      "quote": "advance half now"
     },
     {
      "kind": "message",
      "message_id": "150cc0fe-c4ff-50d1-b532-a9d7f81ee9e0",
      "quote": "sent 48000"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-10-13T09:30:00+05:30",
    "confirmed_by": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "acknowledged_by_other": true
   },
   {
    "id": "a2f94708-78b9-509e-9c51-e011edbd1d39",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "delivery_date",
    "value": null,
    "raw": "next week",
    "state": "unclear",
    "unclear_reason": "relative_date",
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "89fbe45e-a173-52a5-bc76-607776217801",
      "quote": "delivery next week"
     }
    ],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "658439eb-4fd4-51e0-9de4-40d854a37fa8",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "balance_payment_date",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "05aa0f28-aed8-5c15-8dba-673c6e91489a",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "late_penalty",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "560ac21c-309f-524b-8a6d-d360dee60e4b",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "key": "quality_spec",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   }
  ],
  "score": {
   "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
   "ts": "2026-10-13T09:30:00+05:30",
   "total": 55,
   "breakdown": [
    {
     "term_key": "buyer",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "seller",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "item",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "quantity",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "unit_price",
     "weight": 15,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 15.0
    },
    {
     "term_key": "total_amount",
     "weight": 5,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "advance_amount",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "delivery_date",
     "weight": 15,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "balance_payment_date",
     "weight": 10,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "late_penalty",
     "weight": 10,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "quality_spec",
     "weight": 5,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    }
   ],
   "trigger": "confirm_term"
  },
  "voice_notes": [],
  "transcripts": [],
  "flags": [
   {
    "id": "b84347f3-72f6-569e-bb9c-c15d0a6c244f",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "kind": "ambiguous",
    "rule_id": "rel_date",
    "term_key": "delivery_date",
    "reason_code": "relative_date",
    "reason_params": {
     "phrase": "next week",
     "message": "2"
    },
    "sources": [
     {
      "kind": "message",
      "message_id": "89fbe45e-a173-52a5-bc76-607776217801",
      "quote": "delivery next week"
     }
    ],
    "created_at": "2026-10-13T09:30:00+05:30",
    "resolved_at": null
   },
   {
    "id": "8f12977f-8c2d-5934-ba4c-14870b9576de",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "kind": "missing",
    "rule_id": "required_term",
    "term_key": "balance_payment_date",
    "reason_code": "term_missing",
    "reason_params": {
     "term": "balance_payment_date"
    },
    "sources": [],
    "created_at": "2026-10-13T09:30:00+05:30",
    "resolved_at": null
   },
   {
    "id": "1810a88a-8016-5d9f-a2b1-dceda9a34fe8",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "kind": "missing",
    "rule_id": "required_term",
    "term_key": "late_penalty",
    "reason_code": "term_missing",
    "reason_params": {
     "term": "late_penalty"
    },
    "sources": [],
    "created_at": "2026-10-13T09:30:00+05:30",
    "resolved_at": null
   }
  ],
  "suggestions": [
   {
    "id": "f8298033-3fbf-5109-a9db-0da8122c30df",
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "target_term_keys": [
     "delivery_date",
     "balance_payment_date"
    ],
    "tone": "polite",
    "language": "en",
    "text": "Just to confirm, delivery by 15 Nov and the balance on delivery, right?",
    "created_at": "2026-10-13T09:30:00+05:30",
    "copied_at": null
   }
  ],
  "handshake_questions": [
   {
    "term_key": "delivery_date",
    "prompt": "What is the delivery date?",
    "language": "en",
    "value_kind": "date"
   },
   {
    "term_key": "balance_payment_date",
    "prompt": "When is the balance due?",
    "language": "en",
    "value_kind": "event"
   },
   {
    "term_key": "late_penalty",
    "prompt": "What happens if delivery is late?",
    "language": "en",
    "value_kind": "text"
   },
   {
    "term_key": "unit_price",
    "prompt": "What is the price for each shirt?",
    "language": "en",
    "value_kind": "money"
   }
  ],
  "sealed_answers": [
   {
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "party_id": "646970f5-1dbf-5a40-a21a-94a64c4574a6",
    "order": 1,
    "mode": "handover",
    "seal_hash": "e4fcc7ebae4d06c329c5b84076f1a62c8a071e89fc71ca79a9d463dd6c34e3f3",
    "sealed_at": "2026-10-24T11:02:00+05:30",
    "revealed_at": "2026-10-24T11:15:00+05:30",
    "answers": [
     {
      "term_key": "delivery_date",
      "value": {
       "kind": "date",
       "date": "2026-11-15"
      },
      "raw": "15 Nov"
     },
     {
      "term_key": "balance_payment_date",
      "value": {
       "kind": "event",
       "event": "on_delivery"
      },
      "raw": "on delivery"
     },
     {
      "term_key": "late_penalty",
      "value": {
       "kind": "text",
       "text": "none"
      },
      "raw": "none"
     },
     {
      "term_key": "unit_price",
      "value": {
       "kind": "money",
       "paise": "48000"
      },
      "raw": "480"
     }
    ]
   },
   {
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "party_id": "d45984b4-4aa3-5e87-8280-6f97100714a9",
    "order": 2,
    "mode": "reply",
    "seal_hash": "c72a40a39f33ddb1b22b8da689e4cb7bf2bdade29b0c15f4ce1dcad16c96e751",
    "sealed_at": "2026-10-24T11:09:00+05:30",
    "revealed_at": "2026-10-24T11:15:00+05:30",
    "answers": [
     {
      "term_key": "delivery_date",
      "value": {
       "kind": "date",
       "date": "2026-11-22"
      },
      "raw": "22 Nov"
     },
     {
      "term_key": "balance_payment_date",
      "value": {
       "kind": "duration",
       "amount": 30,
       "unit": "days"
      },
      "raw": "30 days after delivery"
     },
     {
      "term_key": "late_penalty",
      "value": {
       "kind": "text",
       "text": "none"
      },
      "raw": "none"
     },
     {
      "term_key": "unit_price",
      "value": {
       "kind": "money",
       "paise": "48000"
      },
      "raw": "480"
     }
    ]
   }
  ],
  "handshake_reveals": [
   {
    "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
    "revealed_at": "2026-10-24T11:15:00+05:30",
    "rows": [
     {
      "term_key": "delivery_date",
      "first": {
       "term_key": "delivery_date",
       "value": {
        "kind": "date",
        "date": "2026-11-15"
       },
       "raw": "15 Nov"
      },
      "second": {
       "term_key": "delivery_date",
       "value": {
        "kind": "date",
        "date": "2026-11-22"
       },
       "raw": "22 Nov"
      },
      "result": "mismatch",
      "difference_code": "days_apart",
      "difference_params": {
       "days": "7"
      }
     },
     {
      "term_key": "balance_payment_date",
      "first": {
       "term_key": "balance_payment_date",
       "value": {
        "kind": "event",
        "event": "on_delivery"
       },
       "raw": "on delivery"
      },
      "second": {
       "term_key": "balance_payment_date",
       "value": {
        "kind": "duration",
        "amount": 30,
        "unit": "days"
       },
       "raw": "30 days after delivery"
      },
      "result": "mismatch",
      "difference_code": "different_terms",
      "difference_params": {}
     },
     {
      "term_key": "late_penalty",
      "first": {
       "term_key": "late_penalty",
       "value": {
        "kind": "text",
        "text": "none"
       },
       "raw": "none"
      },
      "second": {
       "term_key": "late_penalty",
       "value": {
        "kind": "text",
        "text": "none"
       },
       "raw": "none"
      },
      "result": "match",
      "difference_code": null,
      "difference_params": {}
     },
     {
      "term_key": "unit_price",
      "first": {
       "term_key": "unit_price",
       "value": {
        "kind": "money",
        "paise": "48000"
       },
       "raw": "480"
      },
      "second": {
       "term_key": "unit_price",
       "value": {
        "kind": "money",
        "paise": "48000"
       },
       "raw": "480"
      },
      "result": "match",
      "difference_code": null,
      "difference_params": {}
     }
    ]
   }
  ],
  "recaps": [],
  "confirmations": [],
  "versions": [],
  "version_diffs": [],
  "receipts": [
   {
    "body": {
     "spec_version": "0.1-draft",
     "deal_id": "235a0b73-6715-595c-a0b0-e22e53b9fac6",
     "leaf_count": 5,
     "root": "94c3ba25b5c8010ac484ba3fae6d84258982526aacfc2b137e6c371adb6fce66",
     "chain": [],
     "recorded_at": "2026-10-13T09:31:00+05:30",
     "anchor": null
    },
    "receipt_hash": "d895b20d24d78c810d5018b9998cb779da204937a58ee8a531a9e6b4195ea941"
   }
  ],
  "verify_results": [
   {
    "verdict": "unchanged",
    "spec_version": "0.1-draft",
    "checks": [
     {
      "name": "chain",
      "status": "pass",
      "detail": "all links match"
     },
     {
      "name": "merkle_root",
      "status": "pass",
      "detail": "root matches the receipt"
     },
     {
      "name": "timestamp_order",
      "status": "pass",
      "detail": null
     },
     {
      "name": "anchor",
      "status": "not_anchored",
      "detail": "device clock only"
     }
    ],
    "first_difference": null
   }
  ],
  "dispute_packs": [],
  "import_records": [],
  "leaf_rows": [
   {
    "seq": 1,
    "leaf_type": "message",
    "leaf_hash": "01af4bc834fa5aa70d1d75a36c3bfafca900c643baea61cf5ae61edbea9cd85d",
    "salt": "02020202020202020202020202020202",
    "payload_digest": "9db0c052ba27ff541e5fffd3750ddb7f96e3344d823020e048e565404e9be0fe",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"235a0b73-6715-595c-a0b0-e22e53b9fac6\",\"id\":\"e8739171-daba-539b-a799-e0948c4fcb6f\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"646970f5-1dbf-5a40-a21a-94a64c4574a6\",\"seq\":1,\"text\":\"200 shirts, 480 each ok?\",\"ts\":\"2026-10-12T10:02:00+05:30\"}"
   },
   {
    "seq": 2,
    "leaf_type": "message",
    "leaf_hash": "0b8ce1ce9053676d2cb5a78c18ec065477111c5e7a4f92c279dae1c130d6bec4",
    "salt": "03030303030303030303030303030303",
    "payload_digest": "356fe196037b020514d23b3389f43149b638f2273ddc162fc0143b15f3ee6ab3",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"235a0b73-6715-595c-a0b0-e22e53b9fac6\",\"id\":\"89fbe45e-a173-52a5-bc76-607776217801\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"d45984b4-4aa3-5e87-8280-6f97100714a9\",\"seq\":2,\"text\":\"ok. delivery next week\",\"ts\":\"2026-10-12T10:04:00+05:30\"}"
   },
   {
    "seq": 3,
    "leaf_type": "message",
    "leaf_hash": "d7faee6ca227d0ebf087b0148bf712fe2d70deb6b60af67b075891f93065bb5f",
    "salt": "04040404040404040404040404040404",
    "payload_digest": "c06d04e7edca05e8200bcdbefb537475550b9b617b4afbe9c5e0f20cb3526fec",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"235a0b73-6715-595c-a0b0-e22e53b9fac6\",\"id\":\"b574ba83-827b-57a1-8812-d69ce2e7486a\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"646970f5-1dbf-5a40-a21a-94a64c4574a6\",\"seq\":3,\"text\":\"advance half now\",\"ts\":\"2026-10-12T10:05:00+05:30\"}"
   },
   {
    "seq": 4,
    "leaf_type": "message",
    "leaf_hash": "0d9330487a3a4b1773da456edb677b8c3e0001915f26408fe7a8250d97714cfe",
    "salt": "05050505050505050505050505050505",
    "payload_digest": "16600cb62b6023d88db4bfedef9a5f81ae71dcc4d3e99f14857ec3aaa47b3d4a",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"235a0b73-6715-595c-a0b0-e22e53b9fac6\",\"id\":\"150cc0fe-c4ff-50d1-b532-a9d7f81ee9e0\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"d45984b4-4aa3-5e87-8280-6f97100714a9\",\"seq\":4,\"text\":\"done sent 48000\",\"ts\":\"2026-10-12T10:21:00+05:30\"}"
   },
   {
    "seq": 5,
    "leaf_type": "message",
    "leaf_hash": "223381be9b0a765285eb936d92e5150fe0da7e3d04847d642790191413e400b3",
    "salt": "06060606060606060606060606060606",
    "payload_digest": "bd4dfa11a722d34d94c7ce550760f519f3c641bd3147b8839824d2dbd80583ec",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"235a0b73-6715-595c-a0b0-e22e53b9fac6\",\"id\":\"8582c6a8-13ba-5937-9152-52d1a3ec86ba\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"646970f5-1dbf-5a40-a21a-94a64c4574a6\",\"seq\":5,\"text\":\"received. will message when ready\",\"ts\":\"2026-10-13T09:15:00+05:30\"}"
   }
  ],
  "bundles": []
 },
 "contradictory": {
  "description": "Made-up contradictory deal: the amount changes between messages and a voice note disagrees with the text about delivery. Includes a transcript in milliseconds, two versions, a diff and an ALTERED verify result.",
  "playbook": {
   "key": "supply_order",
   "version": 1
  },
  "participants": [
   {
    "id": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "display_name": "Chetan",
    "role": "party",
    "is_me": true
   },
   {
    "id": "fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a",
    "display_name": "Divya",
    "role": "party",
    "is_me": false
   }
  ],
  "messages": [
   {
    "id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 1,
    "sender_id": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "ts": "2026-08-10T11:00:00+05:30",
    "text": "Banner set for the fair, 30 banners. 50000 total ok?",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 2,
    "sender_id": "fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a",
    "ts": "2026-08-10T11:02:00+05:30",
    "text": "ok 30 banners. delivery 15 Nov?",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "87c28ad9-4388-5a4d-b653-14c74782be91",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 3,
    "sender_id": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "ts": "2026-08-10T11:04:00+05:30",
    "text": "yes 15 Nov. I will send 10000 advance now.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "c8c3e5cd-c99c-5569-ad2e-becac5a31a14",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 4,
    "sender_id": "fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a",
    "ts": "2026-08-10T11:30:00+05:30",
    "text": "[voice note 0:41]",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "55ee2c94-c76e-587a-9d8d-ee812ca8a3d8",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 5,
    "sender_id": "fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a",
    "ts": "2026-08-11T09:00:00+05:30",
    "text": "ok then 45000 final price, I checked the cost.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   },
   {
    "id": "102be5c2-7456-50bd-934e-a44677029f54",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 6,
    "sender_id": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "ts": "2026-08-11T09:10:00+05:30",
    "text": "Fine, move delivery to 22 Nov then.",
    "attachment_hash": null,
    "is_system": false,
    "origin": "export"
   }
  ],
  "terms": [
   {
    "id": "633b4a2f-d097-50f4-bdad-94f05d542196",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "buyer",
    "value": {
     "kind": "text",
     "text": "Chetan"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
      "quote": "Chetan"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-08-11T09:30:00+05:30",
    "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "acknowledged_by_other": true
   },
   {
    "id": "e02b6478-214d-5601-bb9a-a2027a404834",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "seller",
    "value": {
     "kind": "text",
     "text": "Divya"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
      "quote": "Divya"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-08-11T09:30:00+05:30",
    "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "acknowledged_by_other": true
   },
   {
    "id": "8e7b623c-51c1-5cd3-99ce-350fba70b2cb",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "item",
    "value": {
     "kind": "text",
     "text": "banners"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
      "quote": "banner set"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-08-11T09:30:00+05:30",
    "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "acknowledged_by_other": true
   },
   {
    "id": "a01a234c-4452-58cd-8be2-dae6ddbdaac8",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "quantity",
    "value": {
     "kind": "quantity",
     "amount": "30",
     "unit": "banners"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
      "quote": "30 banners"
     },
     {
      "kind": "message",
      "message_id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
      "quote": "30 banners"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-08-11T09:30:00+05:30",
    "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "acknowledged_by_other": true
   },
   {
    "id": "38417416-e44f-54c0-9ffc-436a0c5aa186",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "unit_price",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "74bc324a-9482-5750-a145-cae35c288e61",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "total_amount",
    "value": null,
    "raw": null,
    "state": "contradicted",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": true,
    "sources": [
     {
      "kind": "message",
      "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
      "quote": "50000 total"
     },
     {
      "kind": "message",
      "message_id": "55ee2c94-c76e-587a-9d8d-ee812ca8a3d8",
      "quote": "45000 final price"
     }
    ],
    "alternatives": [
     {
      "value": {
       "kind": "money",
       "paise": "5000000"
      },
      "origin": "rules",
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "50000 total"
       }
      ]
     },
     {
      "value": {
       "kind": "money",
       "paise": "4500000"
      },
      "origin": "rules",
      "sources": [
       {
        "kind": "message",
        "message_id": "55ee2c94-c76e-587a-9d8d-ee812ca8a3d8",
        "quote": "45000 final price"
       }
      ]
     }
    ],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "0c812ed7-83b4-521b-a2a1-d24b6e201f44",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "advance_amount",
    "value": {
     "kind": "money",
     "paise": "1000000"
    },
    "raw": null,
    "state": "stated",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [
     {
      "kind": "message",
      "message_id": "87c28ad9-4388-5a4d-b653-14c74782be91",
      "quote": "10000 advance"
     }
    ],
    "alternatives": [],
    "confirmed_at": "2026-08-11T09:30:00+05:30",
    "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
    "acknowledged_by_other": false
   },
   {
    "id": "ceddaaf7-bd0c-5ef5-bd32-8214b2b11980",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "delivery_date",
    "value": null,
    "raw": null,
    "state": "contradicted",
    "unclear_reason": null,
    "origin": "both",
    "confidence": "medium",
    "needs_review": true,
    "sources": [
     {
      "kind": "message",
      "message_id": "87c28ad9-4388-5a4d-b653-14c74782be91",
      "quote": "15 Nov"
     },
     {
      "kind": "voice",
      "voice_note_id": "46d04afb-a526-59fa-aea4-f1d9ac7044d2",
      "start_ms": 12000,
      "end_ms": 18000,
      "quote": "delivery will be on twenty second November"
     }
    ],
    "alternatives": [
     {
      "value": {
       "kind": "partial_date",
       "month_day": "--11-15"
      },
      "origin": "rules",
      "sources": [
       {
        "kind": "message",
        "message_id": "87c28ad9-4388-5a4d-b653-14c74782be91",
        "quote": "15 Nov"
       }
      ]
     },
     {
      "value": {
       "kind": "partial_date",
       "month_day": "--11-22"
      },
      "origin": "ai",
      "sources": [
       {
        "kind": "voice",
        "voice_note_id": "46d04afb-a526-59fa-aea4-f1d9ac7044d2",
        "start_ms": 12000,
        "end_ms": 18000,
        "quote": "delivery will be on twenty second November"
       }
      ]
     }
    ],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "6e170cb6-9dfe-5666-9aac-e57ab15386c4",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "balance_payment_date",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "310fbbd5-70c1-5f45-8e14-19532f9ba81c",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "late_penalty",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   },
   {
    "id": "6731c2f9-a544-5414-ad29-e6e59ed8f797",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "key": "quality_spec",
    "value": null,
    "raw": null,
    "state": "missing",
    "unclear_reason": null,
    "origin": "rules",
    "confidence": "high",
    "needs_review": false,
    "sources": [],
    "alternatives": [],
    "confirmed_at": null,
    "confirmed_by": null,
    "acknowledged_by_other": false
   }
  ],
  "score": {
   "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
   "ts": "2026-08-11T09:30:00+05:30",
   "total": 37,
   "breakdown": [
    {
     "term_key": "buyer",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "seller",
     "weight": 5,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 5.0
    },
    {
     "term_key": "item",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "quantity",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": true,
     "points": 10.0
    },
    {
     "term_key": "unit_price",
     "weight": 15,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "total_amount",
     "weight": 5,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "advance_amount",
     "weight": 10,
     "present": true,
     "clear": true,
     "acknowledged": false,
     "points": 7.0
    },
    {
     "term_key": "delivery_date",
     "weight": 15,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "balance_payment_date",
     "weight": 10,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "late_penalty",
     "weight": 10,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    },
    {
     "term_key": "quality_spec",
     "weight": 5,
     "present": false,
     "clear": false,
     "acknowledged": false,
     "points": 0.0
    }
   ],
   "trigger": "flags_updated"
  },
  "voice_notes": [
   {
    "id": "46d04afb-a526-59fa-aea4-f1d9ac7044d2",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "seq": 1,
    "message_id": "c8c3e5cd-c99c-5569-ad2e-becac5a31a14",
    "sender_id": "fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a",
    "ts": "2026-08-10T11:30:00+05:30",
    "audio_hash": "9f2d2461c54a93051268823dbbd54e7160d76b2daacb971d75c3160247eebc27",
    "duration_ms": 41000,
    "status": "transcribed",
    "transcript_id": "27c288fe-1b86-5f8a-bd6a-463088cbc983"
   }
  ],
  "transcripts": [
   {
    "id": "27c288fe-1b86-5f8a-bd6a-463088cbc983",
    "voice_note_id": "46d04afb-a526-59fa-aea4-f1d9ac7044d2",
    "model": "speech-model-placeholder",
    "model_version": "0",
    "language": "hi",
    "spans": [
     {
      "start_ms": 0,
      "end_ms": 11500,
      "text": "About the banners, the cloth supplier is slow this week.",
      "confidence": 0.91
     },
     {
      "start_ms": 12000,
      "end_ms": 18000,
      "text": "Actually delivery will be on twenty second November.",
      "confidence": 0.62
     }
    ],
    "supersedes_id": null,
    "created_at": "2026-08-10T11:31:00+05:30"
   }
  ],
  "flags": [
   {
    "id": "63840cf9-e801-5a44-a9c1-16285633e56d",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "kind": "contradiction",
    "rule_id": "value_changed",
    "term_key": "total_amount",
    "reason_code": "value_changed",
    "reason_params": {
     "first": "1",
     "second": "5"
    },
    "sources": [
     {
      "kind": "message",
      "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
      "quote": "50000 total"
     },
     {
      "kind": "message",
      "message_id": "55ee2c94-c76e-587a-9d8d-ee812ca8a3d8",
      "quote": "45000 final price"
     }
    ],
    "created_at": "2026-08-11T09:30:00+05:30",
    "resolved_at": null
   },
   {
    "id": "bb30fedb-14d1-520f-9f72-e72fe0cef790",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "kind": "contradiction",
    "rule_id": "text_vs_voice",
    "term_key": "delivery_date",
    "reason_code": "text_vs_voice",
    "reason_params": {
     "message": "3",
     "from": "12000",
     "to": "18000"
    },
    "sources": [
     {
      "kind": "message",
      "message_id": "87c28ad9-4388-5a4d-b653-14c74782be91",
      "quote": "15 Nov"
     },
     {
      "kind": "voice",
      "voice_note_id": "46d04afb-a526-59fa-aea4-f1d9ac7044d2",
      "start_ms": 12000,
      "end_ms": 18000,
      "quote": "delivery will be on twenty second November"
     }
    ],
    "created_at": "2026-08-11T09:30:00+05:30",
    "resolved_at": null
   },
   {
    "id": "dbfd089b-eb73-5b65-bd67-9f078c15fe52",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "kind": "needs_review",
    "rule_id": "low_voice_confidence",
    "term_key": "delivery_date",
    "reason_code": "low_voice_confidence",
    "reason_params": {},
    "sources": [
     {
      "kind": "voice",
      "voice_note_id": "46d04afb-a526-59fa-aea4-f1d9ac7044d2",
      "start_ms": 12000,
      "end_ms": 18000,
      "quote": "delivery will be on twenty second November"
     }
    ],
    "created_at": "2026-08-11T09:30:00+05:30",
    "resolved_at": null
   },
   {
    "id": "573d5594-e927-555e-bbf9-95147fc1c7da",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "kind": "missing",
    "rule_id": "required_term",
    "term_key": "balance_payment_date",
    "reason_code": "term_missing",
    "reason_params": {
     "term": "balance_payment_date"
    },
    "sources": [],
    "created_at": "2026-08-11T09:30:00+05:30",
    "resolved_at": null
   }
  ],
  "suggestions": [],
  "handshake_questions": [],
  "sealed_answers": [],
  "handshake_reveals": [],
  "recaps": [],
  "confirmations": [],
  "versions": [
   {
    "id": "add8d661-db00-501d-b57e-42ed9f915022",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "version_n": 1,
    "playbook": {
     "key": "supply_order",
     "version": 1
    },
    "terms": [
     {
      "key": "buyer",
      "value": {
       "kind": "text",
       "text": "Chetan"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "Chetan"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     },
     {
      "key": "delivery_date",
      "value": {
       "kind": "date",
       "date": "2026-11-15"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "87c28ad9-4388-5a4d-b653-14c74782be91",
        "quote": null
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-10T11:08:00+05:30"
     },
     {
      "key": "item",
      "value": {
       "kind": "text",
       "text": "banners"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "banner set"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     },
     {
      "key": "quantity",
      "value": {
       "kind": "quantity",
       "amount": "30",
       "unit": "banners"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "30 banners"
       },
       {
        "kind": "message",
        "message_id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
        "quote": "30 banners"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     },
     {
      "key": "seller",
      "value": {
       "kind": "text",
       "text": "Divya"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
        "quote": "Divya"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     }
    ],
    "terms_digest": "0386943df3b1f68499f0f553fc8e2543b077b5158c1e4f2191c67a4fe79de2e8",
    "root": "9837988d0169e036ac3a775461dbb09c22bc5747c6e4a366edc026accbf47006",
    "link": "a206db793e020dfa38121f07553f47fcea017ebf537da9b43c08f77c0b4006b5",
    "prev_link": null,
    "reason_message_id": null,
    "created_at": "2026-08-10T11:10:00+05:30"
   },
   {
    "id": "d6f3cf23-6c65-5d2d-b9f1-a2b6f47e17e9",
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "version_n": 2,
    "playbook": {
     "key": "supply_order",
     "version": 1
    },
    "terms": [
     {
      "key": "buyer",
      "value": {
       "kind": "text",
       "text": "Chetan"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "Chetan"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     },
     {
      "key": "delivery_date",
      "value": {
       "kind": "date",
       "date": "2026-11-22"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "102be5c2-7456-50bd-934e-a44677029f54",
        "quote": null
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:45:00+05:30"
     },
     {
      "key": "item",
      "value": {
       "kind": "text",
       "text": "banners"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "banner set"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     },
     {
      "key": "quantity",
      "value": {
       "kind": "quantity",
       "amount": "30",
       "unit": "banners"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4",
        "quote": "30 banners"
       },
       {
        "kind": "message",
        "message_id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
        "quote": "30 banners"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     },
     {
      "key": "seller",
      "value": {
       "kind": "text",
       "text": "Divya"
      },
      "sources": [
       {
        "kind": "message",
        "message_id": "0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae",
        "quote": "Divya"
       }
      ],
      "confirmed_by": "a9705889-8daa-5353-bf3b-fe2c7ca715ea",
      "confirmed_at": "2026-08-11T09:30:00+05:30"
     }
    ],
    "terms_digest": "358bb3d5e3b0d96665623d0c81ae12a5b78cbb8a3a84123a30d35e69c9e4efa7",
    "root": "9f98504d88af6e8bc4a10205427e23e7f9ad47656bf8eeb8c65915e73a07d969",
    "link": "9bcb643eeef12b6101a26f203aa5e35035d6f25fca39235c595e7c3cfc38dca5",
    "prev_link": "a206db793e020dfa38121f07553f47fcea017ebf537da9b43c08f77c0b4006b5",
    "reason_message_id": "102be5c2-7456-50bd-934e-a44677029f54",
    "created_at": "2026-08-11T09:50:00+05:30"
   }
  ],
  "version_diffs": [
   {
    "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
    "from_version_n": 1,
    "to_version_n": 2,
    "rows": [
     {
      "term_key": "buyer",
      "before": {
       "kind": "text",
       "text": "Chetan"
      },
      "after": {
       "kind": "text",
       "text": "Chetan"
      },
      "change": "no_change"
     },
     {
      "term_key": "delivery_date",
      "before": {
       "kind": "date",
       "date": "2026-11-15"
      },
      "after": {
       "kind": "date",
       "date": "2026-11-22"
      },
      "change": "changed"
     },
     {
      "term_key": "item",
      "before": {
       "kind": "text",
       "text": "banners"
      },
      "after": {
       "kind": "text",
       "text": "banners"
      },
      "change": "no_change"
     },
     {
      "term_key": "quantity",
      "before": {
       "kind": "quantity",
       "amount": "30",
       "unit": "banners"
      },
      "after": {
       "kind": "quantity",
       "amount": "30",
       "unit": "banners"
      },
      "change": "no_change"
     },
     {
      "term_key": "seller",
      "before": {
       "kind": "text",
       "text": "Divya"
      },
      "after": {
       "kind": "text",
       "text": "Divya"
      },
      "change": "no_change"
     }
    ],
    "reason_message_id": "102be5c2-7456-50bd-934e-a44677029f54"
   }
  ],
  "receipts": [
   {
    "body": {
     "spec_version": "0.1-draft",
     "deal_id": "5af0afe0-e090-57fa-a977-3439660d9045",
     "leaf_count": 6,
     "root": "9f98504d88af6e8bc4a10205427e23e7f9ad47656bf8eeb8c65915e73a07d969",
     "chain": [
      {
       "version_n": 1,
       "terms_digest": "0386943df3b1f68499f0f553fc8e2543b077b5158c1e4f2191c67a4fe79de2e8",
       "root": "9837988d0169e036ac3a775461dbb09c22bc5747c6e4a366edc026accbf47006",
       "link": "a206db793e020dfa38121f07553f47fcea017ebf537da9b43c08f77c0b4006b5"
      },
      {
       "version_n": 2,
       "terms_digest": "358bb3d5e3b0d96665623d0c81ae12a5b78cbb8a3a84123a30d35e69c9e4efa7",
       "root": "9f98504d88af6e8bc4a10205427e23e7f9ad47656bf8eeb8c65915e73a07d969",
       "link": "9bcb643eeef12b6101a26f203aa5e35035d6f25fca39235c595e7c3cfc38dca5"
      }
     ],
     "recorded_at": "2026-08-11T09:51:00+05:30",
     "anchor": null
    },
    "receipt_hash": "cb35350c164288dcafe62ceab2fc63cd7e955a877c07aedfadb9c52933c73792"
   }
  ],
  "verify_results": [
   {
    "verdict": "altered",
    "spec_version": "0.1-draft",
    "checks": [
     {
      "name": "chain",
      "status": "fail",
      "detail": "chain breaks at link 2 of 2"
     },
     {
      "name": "merkle_root",
      "status": "fail",
      "detail": "root does not match the receipt"
     },
     {
      "name": "timestamp_order",
      "status": "pass",
      "detail": null
     },
     {
      "name": "anchor",
      "status": "not_anchored",
      "detail": "device clock only"
     }
    ],
    "first_difference": {
     "kind": "message",
     "ref": "4"
    }
   }
  ],
  "dispute_packs": [],
  "import_records": [],
  "leaf_rows": [
   {
    "seq": 1,
    "leaf_type": "message",
    "leaf_hash": "36c64ba99fe8156fe9c6eaf824bb96062c0192a867e76ea87747683dae552bbb",
    "salt": "02020202020202020202020202020202",
    "payload_digest": "9c57668ca292564cc67b92fd2471fac36f80d9dbe23ca094f73dcb82b6eaa37a",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"5af0afe0-e090-57fa-a977-3439660d9045\",\"id\":\"0a1c53ff-c5ca-5dfc-b740-bb9ca4f964a4\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"a9705889-8daa-5353-bf3b-fe2c7ca715ea\",\"seq\":1,\"text\":\"Banner set for the fair, 30 banners. 50000 total ok?\",\"ts\":\"2026-08-10T11:00:00+05:30\"}"
   },
   {
    "seq": 2,
    "leaf_type": "message",
    "leaf_hash": "9258e5ee0b927613c7aed8973eb22585bd57ec71d00abcaba56761a47354ce5c",
    "salt": "03030303030303030303030303030303",
    "payload_digest": "bbc7cf2ab166073d911cfa69144afda2e2bbd27d49b9fe84e62633e005c50a87",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"5af0afe0-e090-57fa-a977-3439660d9045\",\"id\":\"0acf3e82-cc5e-5d4a-a7f7-f387d97a32ae\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a\",\"seq\":2,\"text\":\"ok 30 banners. delivery 15 Nov?\",\"ts\":\"2026-08-10T11:02:00+05:30\"}"
   },
   {
    "seq": 3,
    "leaf_type": "message",
    "leaf_hash": "643a29ee210e1fcc7695c2b6ec2ea69c293a2ea3f3deb4815d67247b9b5b1c4f",
    "salt": "04040404040404040404040404040404",
    "payload_digest": "ca64dd69f45f02653d69cbd613a9f946a8d120905b5c53f6660260ab1ae803ff",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"5af0afe0-e090-57fa-a977-3439660d9045\",\"id\":\"87c28ad9-4388-5a4d-b653-14c74782be91\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"a9705889-8daa-5353-bf3b-fe2c7ca715ea\",\"seq\":3,\"text\":\"yes 15 Nov. I will send 10000 advance now.\",\"ts\":\"2026-08-10T11:04:00+05:30\"}"
   },
   {
    "seq": 4,
    "leaf_type": "message",
    "leaf_hash": "ecdb5343a0b812a84f0b0e7b171015688d758c67a83a935fb594b84505dca082",
    "salt": "05050505050505050505050505050505",
    "payload_digest": "caba931089a4e420cd407c7005339a75c1fada648b5e53a538944d675a07df1e",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"5af0afe0-e090-57fa-a977-3439660d9045\",\"id\":\"c8c3e5cd-c99c-5569-ad2e-becac5a31a14\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a\",\"seq\":4,\"text\":\"[voice note 0:41]\",\"ts\":\"2026-08-10T11:30:00+05:30\"}"
   },
   {
    "seq": 5,
    "leaf_type": "message",
    "leaf_hash": "08cd54cc6732a6c2f557b3c581c703e5e24aeacc444ec982e5a2462c0e643f5b",
    "salt": "06060606060606060606060606060606",
    "payload_digest": "82672b84dd8266914fb90e5306cec025533b4dd3b97217e5cd3e9405b6110eea",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"5af0afe0-e090-57fa-a977-3439660d9045\",\"id\":\"55ee2c94-c76e-587a-9d8d-ee812ca8a3d8\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"fcef7eb4-f7a5-5edd-9d31-fa57260d4c1a\",\"seq\":5,\"text\":\"ok then 45000 final price, I checked the cost.\",\"ts\":\"2026-08-11T09:00:00+05:30\"}"
   },
   {
    "seq": 6,
    "leaf_type": "message",
    "leaf_hash": "39eaf258fbf8004209ca0387f69948a4cf7145d1b8a28eac00317d01868ebe49",
    "salt": "07070707070707070707070707070707",
    "payload_digest": "6a47c9a2ec1f318e78e8b669b748f1a2dc6930cab0ed99267ca98c69af38b5ba",
    "payload": "{\"attachment_hash\":null,\"deal_id\":\"5af0afe0-e090-57fa-a977-3439660d9045\",\"id\":\"102be5c2-7456-50bd-934e-a44677029f54\",\"is_system\":false,\"origin\":\"export\",\"sender_id\":\"a9705889-8daa-5353-bf3b-fe2c7ca715ea\",\"seq\":6,\"text\":\"Fine, move delivery to 22 Nov then.\",\"ts\":\"2026-08-11T09:10:00+05:30\"}"
   }
  ],
  "bundles": []
 }
};
